package org.apache.commons.vfs.provider.https;

import org.apache.commons.vfs.provider.http.HttpFileProvider;

/**
 * An HTTPS provider that uses commons-httpclient.
 *
 * @author <a href="mailto:adammurdoch@apache.org">Adam Murdoch</a>
 * @version $Revision: 452599 $ $Date: 2006-10-03 21:21:17 +0200 (Tue, 03 Oct 2006) $
 */
public class HttpsFileProvider
    extends HttpFileProvider
{
	public HttpsFileProvider()
    {
        super();
        setFileNameParser(HttpsFileNameParser.getInstance());
    }
}
