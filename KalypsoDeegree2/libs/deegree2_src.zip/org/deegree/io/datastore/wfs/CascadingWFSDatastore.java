//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/io/datastore/wfs/CascadingWFSDatastore.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 ---------------------------------------------------------------------------*/
package org.deegree.io.datastore.wfs;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.deegree.enterprise.WebUtils;
import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.framework.util.CharsetUtils;
import org.deegree.framework.xml.XMLFragment;
import org.deegree.framework.xml.XMLParsingException;
import org.deegree.i18n.Messages;
import org.deegree.io.datastore.Datastore;
import org.deegree.io.datastore.DatastoreException;
import org.deegree.io.datastore.DatastoreTransaction;
import org.deegree.io.datastore.schema.MappedFeatureType;
import org.deegree.model.crs.UnknownCRSException;
import org.deegree.model.feature.FeatureCollection;
import org.deegree.model.feature.GMLFeatureCollectionDocument;
import org.deegree.ogcwebservices.OWSUtils;
import org.deegree.ogcwebservices.getcapabilities.InvalidCapabilitiesException;
import org.deegree.ogcwebservices.wfs.XMLFactory;
import org.deegree.ogcwebservices.wfs.capabilities.WFSCapabilities;
import org.deegree.ogcwebservices.wfs.capabilities.WFSCapabilitiesDocument;
import org.deegree.ogcwebservices.wfs.operation.GetFeature;
import org.deegree.ogcwebservices.wfs.operation.Query;
import org.deegree.ogcwebservices.wfs.operation.GetFeature.RESULT_TYPE;
import org.xml.sax.SAXException;

/**
 * 
 * 
 * 
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: mschneider $
 * 
 * @version $Revision: 7468 $, $Date: 2007-06-05 16:33:13 +0200 (Di, 05 Jun 2007) $
 */
public class CascadingWFSDatastore extends Datastore {

    private ILogger LOG = LoggerFactory.getLogger( CascadingWFSDatastore.class );

    private static Map<URL, WFSCapabilities> wfsCapabilities;
    static {
        if ( wfsCapabilities == null ) {
            wfsCapabilities = new HashMap<URL, WFSCapabilities>();
        }
    }

    @Override
    public CascadingWFSAnnotationDocument getAnnotationParser() {
        return new CascadingWFSAnnotationDocument ();
    }    
    
    @Override
    public void close()
                            throws DatastoreException {
    }

    @Override
    public FeatureCollection performQuery( Query query, MappedFeatureType[] rootFts, DatastoreTransaction context )
                            throws DatastoreException, UnknownCRSException {
        return performQuery( query, rootFts );
    }

    @Override
    public FeatureCollection performQuery( Query query, MappedFeatureType[] rootFts )
                            throws DatastoreException, UnknownCRSException {

        GetFeature getFeature = GetFeature.create( "1.1.0", "ID", RESULT_TYPE.RESULTS, "text/xml; subtype=gml/3.1.1",
                                                   "", query.getMaxFeatures(), query.getStartPosition(), -1, -1,
                                                   new Query[] { query } );
        XMLFragment gfXML = null;
        try {
            gfXML = XMLFactory.export( getFeature );
        } catch ( IOException e ) {
            LOG.logError( e.getMessage(), e );
            throw new DatastoreException( e.getMessage() );
        } catch ( XMLParsingException e ) {
            LOG.logError( e.getMessage(), e );
            throw new DatastoreException( e.getMessage() );
        }

        FeatureCollection allFc = null;

        // get URL that is target of a GetFeature request
        CascadingWFSDatastoreConfiguration config = (CascadingWFSDatastoreConfiguration) this.getConfiguration();
        URL[] urls = config.getWfsURL();
        for ( int i = 0; i < urls.length; i++ ) {

            URL url = getTargetURL( GetFeature.class, urls[i] );

            InputStream is = null;
            try {
                // perform GetFeature request against cascaded WFS
                HttpClient client = new HttpClient();
                client = WebUtils.enableProxyUsage( client, url );
                PostMethod post = new PostMethod( url.toExternalForm() );
                StringRequestEntity se = new StringRequestEntity( gfXML.getAsString(), "text/xml",
                                                                  CharsetUtils.getSystemCharset() );
                post.setRequestEntity( se );
                client.executeMethod( post );
                is = post.getResponseBodyAsStream();
            } catch ( Exception e ) {
                throw new DatastoreException( Messages.getMessage( "DATASTORE_WFS_ACCESS", url ) );
            }

            // read result as GMLFeatureColllection
            GMLFeatureCollectionDocument fcd = new GMLFeatureCollectionDocument();
            try {
                fcd.load( is, url.toExternalForm() );
            } catch ( Exception e ) {
                LOG.logError( e.getMessage(), e );
                throw new DatastoreException( e.getMessage() );
            } finally {
                try {
                    is.close();
                } catch ( IOException shouldNeverHappen ) {
                }
            }

            FeatureCollection fc = null;
            try {
                fc = fcd.parse();
            } catch ( XMLParsingException e ) {
                LOG.logError( e.getMessage(), e );
                throw new DatastoreException( e.getMessage() );
            }
            if ( allFc == null ) {
                allFc = fc;
            } else {
                allFc.addAll( fc );
            }

        }

        return allFc;
    }

    private URL getTargetURL( Class clss, URL url )
                            throws DatastoreException {

        String href = OWSUtils.validateHTTPGetBaseURL( url.toExternalForm() );
        href = href + "request=GetCapabilities&version=1.1.0&service=WFS";

        LOG.logDebug( "requested capabilities: ", href );

        try {
            url = new URL( href );
        } catch ( MalformedURLException e1 ) {
            e1.printStackTrace();
        }

        WFSCapabilities caps = wfsCapabilities.get( url );
        if ( caps == null ) {
            // access capabilities if not already has been loaded
            WFSCapabilitiesDocument cd = new WFSCapabilitiesDocument();
            try {
                cd.load( url );
            } catch ( IOException e ) {
                LOG.logError( e.getMessage(), e );
                throw new DatastoreException( e.getMessage() );
            } catch ( SAXException e ) {
                LOG.logError( e.getMessage(), e );
                throw new DatastoreException( e.getMessage() );
            }
            try {
                caps = (WFSCapabilities) cd.parseCapabilities();
            } catch ( InvalidCapabilitiesException e ) {
                LOG.logError( e.getMessage(), e );
                throw new DatastoreException( e.getMessage() );
            }
            wfsCapabilities.put( url, caps );
        }

        // get GetFeature target URL from capabilities
        return OWSUtils.getHTTPPostOperationURL( caps, clss );
    }
}