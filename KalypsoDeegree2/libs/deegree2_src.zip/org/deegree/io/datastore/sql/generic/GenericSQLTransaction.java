//$HeadURL: svn+ssh://mschneider@svn.wald.intevation.org/deegree/base/trunk/resources/eclipse/svn_classfile_header_template.xml $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.io.datastore.sql.generic;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.io.DBConnectionPool;
import org.deegree.io.JDBCConnection;
import org.deegree.io.datastore.DatastoreException;
import org.deegree.io.datastore.FeatureId;
import org.deegree.io.datastore.schema.MappedFeatureType;
import org.deegree.io.datastore.sql.AbstractSQLDatastore;
import org.deegree.io.datastore.sql.SQLDatastoreConfiguration;
import org.deegree.io.datastore.sql.TableAliasGenerator;
import org.deegree.io.datastore.sql.transaction.SQLTransaction;
import org.deegree.io.quadtree.DBQuadtree;
import org.deegree.io.quadtree.IndexException;
import org.deegree.model.feature.Feature;
import org.deegree.model.feature.FeatureProperty;
import org.deegree.model.filterencoding.Filter;
import org.deegree.model.spatialschema.Envelope;
import org.deegree.model.spatialschema.GeometryException;
import org.deegree.ogcbase.PropertyPath;

/**
 * Special transaction implementation for the {@link GenericSQLDatastore}.
 * <p>
 * Updates the quadtree after successful transactions.
 * 
 * @see org.deegree.io.quadtree
 * 
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth </a>
 * @author <a href="mailto:schneider@lat-lon.de">Markus Schneider </a>
 * @author last edited by: $Author:$
 * 
 * @version $Revision:$, $Date:$
 */
public class GenericSQLTransaction extends SQLTransaction {

    private static final ILogger LOG = LoggerFactory.getLogger( GenericSQLTransaction.class );

    private String indexName;

    /**
     * 
     * @param ds
     * @param aliasGenerator
     * @param conn
     * @throws DatastoreException
     */
    GenericSQLTransaction( AbstractSQLDatastore ds, TableAliasGenerator aliasGenerator, Connection conn )
                            throws DatastoreException {
        super( ds, aliasGenerator, conn );
    }

    @Override
    public int performDelete( MappedFeatureType mappedFeatureType, Filter filter, String lockId )
                            throws DatastoreException {
        int cnt = super.performDelete( mappedFeatureType, filter, lockId );

        // update index

        return cnt;
    }

    @Override
    public List<FeatureId> performInsert( List<Feature> features )
                            throws DatastoreException {
        List<FeatureId> fids = super.performInsert( features );

        // update index
        try {
            for ( int i = 0; i < features.size(); i++ ) {
                Envelope env = features.get( i ).getBoundedBy();
                if ( env != null ) {
                    MappedFeatureType mft = datastore.getFeatureType( features.get( i ).getFeatureType().getName() );
                    Integer id = (Integer) FeatureId.removeFIDPrefix( fids.get( i ).getAsString(), mft.getGMLId() );
                    SQLDatastoreConfiguration config = (SQLDatastoreConfiguration) getDatastore().getConfiguration();
                    String table = mft.getTable();
                    JDBCConnection jdbc = config.getJDBCConnection();
                    int fk_index = loadIndexMetadata( jdbc, table );
                    DBQuadtree qt = new DBQuadtree( fk_index, indexName, jdbc );
                    qt.insert( id, env );
                }
            }
        } catch ( IndexException e ) {
            LOG.logError( e.getMessage(), e );
            throw new DatastoreException( e.getMessage(), e );
        } catch ( GeometryException e ) {
            LOG.logError( e.getMessage(), e );
            throw new DatastoreException( e.getMessage(), e );
        }

        return fids;
    }

    @Override
    public int performUpdate( MappedFeatureType mappedFeatureType, Feature replacementFeature, Filter filter,
                              String lockId )
                            throws DatastoreException {
        int cnt = super.performUpdate( mappedFeatureType, replacementFeature, filter, lockId );

        // update index

        return cnt;
    }

    @Override
    public int performUpdate( MappedFeatureType mappedFeatureType, Map<PropertyPath, FeatureProperty> replacementProps,
                              Filter filter, String lockId )
                            throws DatastoreException {

        int cnt = super.performUpdate( mappedFeatureType, replacementProps, filter, lockId );

        // update index

        return cnt;
    }

    /**
     * loads the metadata of a Index from the TAB_DEEGREE_IDX table
     * 
     * @param jdbc
     *            database connection information
     * @param table
     *            name of the table containing a featuretypes data
     * 
     * @return FK to the index
     * @throws IndexException
     */
    private int loadIndexMetadata( JDBCConnection jdbc, String table )
                            throws IndexException {
        int fk_indexTree = -1;
        Connection con = null;
        DBConnectionPool pool = null;
        try {
            pool = DBConnectionPool.getInstance();
            con = pool.acquireConnection( jdbc.getDriver(), jdbc.getURL(), jdbc.getUser(), jdbc.getPassword() );

            StringBuffer sb = new StringBuffer( 200 );
            sb.append( "Select INDEX_NAME, FK_INDEXTREE from TAB_DEEGREE_IDX where " );
            sb.append( "column_name = 'geometry' AND " );
            sb.append( "table_name = '" ).append( table.toLowerCase() ).append( "'" );

            LOG.logDebug( "Get Index Metadata: ", sb );

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery( sb.toString() );

            if ( rs.next() ) {
                indexName = rs.getString( "INDEX_NAME" );
                fk_indexTree = rs.getInt( "FK_INDEXTREE" );
            } else {
                throw new IndexException( "could not read index metadata" );
            }
            rs.close();
            stmt.close();
        } catch ( Exception e ) {
            LOG.logError( e.getMessage(), e );
            throw new IndexException( "could not load quadtree definition from database", e );
        } finally {
            try {
                pool.releaseConnection( con, jdbc.getDriver(), jdbc.getURL(), jdbc.getUser(), jdbc.getPassword() );
            } catch ( Exception e1 ) {
                e1.printStackTrace();
            }
        }
        return fk_indexTree;
    }
}
