//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/datatypes/parameter/ParameterNotFoundException.java $
/*$************************************************************************************************
 **
 ** $Id: ParameterNotFoundException.java 6259 2007-03-20 09:15:15Z bezema $
 **
 ** $Source$
 **
 ** Copyright (C) 2003 Open GIS Consortium, Inc. All Rights Reserved. http://www.opengis.org/Legal/
 **
 *************************************************************************************************/
package org.deegree.datatypes.parameter;

/**
 * Thrown when a required parameter was not found in a
 * {@linkplain OperationParameterGroupIm parameter group}.
 * 
 * @author <A HREF="http://www.opengis.org">OpenGIS&reg; consortium</A>
 * @author last edited by: $Author: bezema $
 * 
 * @version $Revision: 6259 $, $Date: 2007-03-20 10:15:15 +0100 (Di, 20 Mrz 2007) $
 */
public class ParameterNotFoundException extends IllegalArgumentException {
    /**
     * Serial number for interoperability with different versions.
     */
    private static final long serialVersionUID = -8074834945993975175L;

    /**
     * The invalid parameter name.
     */
    private final String parameterName;

    /**
     * Creates an exception with the specified message and parameter name.
     * 
     * @param message
     *            The detail message. The detail message is saved for later retrieval by the
     *            {@link #getMessage()} method.
     * @param parameterName
     *            The required parameter name.
     */
    public ParameterNotFoundException( String message, String parameterName ) {
        super( message );
        this.parameterName = parameterName;
    }

    /**
     * Returns the required parameter name.
     * 
     * @return the required parameter name.
     */
    public String getParameterName() {
        return parameterName;
    }
}
/***************************************************************************************************
 * <code>
 Changes to this class. What the people have been up to:
 
 $Log$
 Revision 1.2  2007/03/06 09:18:30  wanhoff
 Fixed Javadoc (@link, @return)

 Revision 1.1  2007/02/09 17:26:53  poth
 *** empty log message ***

 Revision 1.2  2006/07/13 06:28:31  poth
 comment footer added

 </code>
 **************************************************************************************************/
