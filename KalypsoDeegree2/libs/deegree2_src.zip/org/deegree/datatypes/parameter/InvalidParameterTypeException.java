//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/datatypes/parameter/InvalidParameterTypeException.java $
/*$************************************************************************************************
 **
 ** $Id: InvalidParameterTypeException.java 6259 2007-03-20 09:15:15Z bezema $
 **
 ** $Source$
 **
 ** Copyright (C) 2003 Open GIS Consortium, Inc. All Rights Reserved. http://www.opengis.org/Legal/
 **
 *************************************************************************************************/
package org.deegree.datatypes.parameter;

/**
 * Thrown when a parameter can't be cast to the requested type. For example this exception is thrown
 * when {@link ParameterValueIm#doubleValue} is invoked but the value is not convertible to a
 * <code>double</code>.
 * 
 * @author <A HREF="http://www.opengis.org">OpenGIS&reg; consortium</A>
 * @author last edited by: $Author: bezema $
 * 
 * @version $Revision: 6259 $, $Date: 2007-03-20 10:15:15 +0100 (Di, 20 Mrz 2007) $
 * 
 * @see ParameterValueIm#intValue
 * @see ParameterValueIm#doubleValue
 * 
 */
public class InvalidParameterTypeException extends IllegalStateException {
    /**
     * Serial number for interoperability with different versions.
     */
    private static final long serialVersionUID = 2740762597003093176L;

    /**
     * The invalid parameter name.
     */
    private final String parameterName;

    /**
     * Creates an exception with the specified message and parameter name.
     * 
     * @param message
     *            The detail message. The detail message is saved for later retrieval by the
     *            {@link #getMessage()} method.
     * @param parameterName
     *            The parameter name.
     */
    public InvalidParameterTypeException( String message, String parameterName ) {
        super( message );
        this.parameterName = parameterName;
    }

    /**
     * Returns the parameter name.
     * 
     * @return the parameter name.
     */
    public String getParameterName() {
        return parameterName;
    }
}
/***************************************************************************************************
 * <code>
 Changes to this class. What the people have been up to:
 
 $Log$
 Revision 1.2  2007/03/06 09:03:46  wanhoff
 Fixed Javadoc (@see, @link, @return)

 Revision 1.1  2007/02/09 17:26:53  poth
 *** empty log message ***

 Revision 1.2  2006/07/13 06:28:31  poth
 comment footer added

 </code>
 **************************************************************************************************/
