//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/framework/jndi/ServiceLocator.java $
/*
 * Created on 20.02.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package org.deegree.framework.jndi;

/**
 * ServiceLocator
 * 
 * @author Administrator
 * 
 * @author last edited by: $Author: apoth $
 * 
 * @version 2.0, $Revision: 6696 $, $Date: 2007-04-25 21:57:05 +0200 (Mi, 25 Apr 2007) $
 *  
 * @since 2.0
 * 
 * @see <a href="http://java.sun.com/blueprints/corej2eepatterns/Patterns/ServiceLocator.html">CapabilitiesService Locator</a>
 */

public final class ServiceLocator {

    /**
     * 
     */
    private static final ServiceLocator singleton = new ServiceLocator();

    /**
     * @return
     */
    public static final ServiceLocator getInstance() {
        return singleton;
    }
    
    /**
     * 
     */
    private ServiceLocator(){
        
    }
}
