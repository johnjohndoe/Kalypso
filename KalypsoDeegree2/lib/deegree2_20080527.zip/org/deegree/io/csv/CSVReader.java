//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/io/csv/CSVReader.java $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.io.csv;

import static java.io.StreamTokenizer.TT_EOF;
import static java.io.StreamTokenizer.TT_EOL;
import static java.lang.Double.parseDouble;
import static org.deegree.io.mapinfoapi.MapInfoReader.whitespaceChars;
import static org.deegree.io.mapinfoapi.MapInfoReader.wordChars;
import static org.deegree.model.feature.FeatureFactory.createFeature;
import static org.deegree.model.feature.FeatureFactory.createFeatureCollection;
import static org.deegree.model.feature.FeatureFactory.createFeatureProperty;
import static org.deegree.model.feature.FeatureFactory.createGeometryPropertyType;
import static org.deegree.model.feature.FeatureFactory.createSimplePropertyType;
import static org.deegree.model.spatialschema.GeometryFactory.createPoint;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;

import org.deegree.datatypes.QualifiedName;
import org.deegree.datatypes.Types;
import org.deegree.model.feature.FeatureCollection;
import org.deegree.model.feature.FeatureFactory;
import org.deegree.model.feature.FeatureProperty;
import org.deegree.model.feature.schema.FeatureType;
import org.deegree.model.feature.schema.PropertyType;

/**
 * <code>CSVReader</code>
 * 
 * @author <a href="mailto:schmitz@lat-lon.de">Andreas Schmitz</a>
 * @author last edited by: $Author: aschmitz $
 * 
 * @version $Revision: 11901 $, $Date: 2008-05-26 17:32:04 +0200 (Mon, 26 May 2008) $
 */
public class CSVReader {

    private String name;

    private int xcol = 0, ycol = 1;

    private StreamTokenizer tokenizer;

    private static URI APPNS;

    static {
        try {
            APPNS = new URI( "http://www.deegree.org/app" );
        } catch ( URISyntaxException e ) {
            // yes, cannot happen
        }
    }

    /**
     * @param delimiter
     * @param name
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
    public CSVReader( char delimiter, String name ) throws FileNotFoundException, UnsupportedEncodingException {
        this.name = name;
        tokenizer = getCSVTokenizer( null );
        tokenizer.whitespaceChars( delimiter, delimiter );
    }

    /**
     * @param x
     * @param y
     */
    public void setPointColumns( int x, int y ) {
        xcol = x;
        ycol = y;
    }

    /**
     * @param charset
     *            or null to use file.encoding
     * @return a new tokenizer
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException
     */
    public StreamTokenizer getCSVTokenizer( String charset )
                            throws FileNotFoundException, UnsupportedEncodingException {
        StreamTokenizer tok = charset == null ? new StreamTokenizer(
                                                                     new InputStreamReader( new FileInputStream( name ) ) )
                                             : new StreamTokenizer( new InputStreamReader( new FileInputStream( name ),
                                                                                           charset ) );

        tok.resetSyntax();
        tok.eolIsSignificant( true );
        tok.lowerCaseMode( true );
        tok.slashSlashComments( false );
        tok.slashStarComments( false );
        tok.wordChars( 'a', 'z' );
        tok.wordChars( 'A', 'Z' );
        tok.wordChars( '\u00a0', '\u00ff' );
        tok.wordChars( '0', '9' );
        wordChars( tok, '.', '-', '_' );
        tok.quoteChar( '"' );
        whitespaceChars( tok, ' ', '\n', '\r', '\f', '\t', '(', ')', ',' );

        return tok;
    }

    /**
     * @return a new feature collection
     * @throws IOException
     */
    public FeatureCollection parseFeatureCollection()
                            throws IOException {
        FeatureCollection fc = createFeatureCollection( "uniquemy_", 512 );
        QualifiedName geomName = new QualifiedName( "app:geometry", APPNS );
        QualifiedName featureName = new QualifiedName( "app:feature", APPNS );

        int counter = 0;

        while ( tokenizer.ttype != TT_EOF ) {
            tokenizer.nextToken();
            if ( tokenizer.ttype == TT_EOF ) {
                break;
            }
            ArrayList<String> vals = new ArrayList<String>();
            while ( tokenizer.ttype != TT_EOL ) {
                vals.add( tokenizer.sval );
                tokenizer.nextToken();
            }

            double x = 0, y = 0;
            LinkedList<FeatureProperty> fps = new LinkedList<FeatureProperty>();
            LinkedList<PropertyType> fpt = new LinkedList<PropertyType>();

            for ( int i = 0; i < vals.size(); ++i ) {

                if ( i == xcol ) {
                    x = parseDouble( vals.get( i ) );
                    continue;
                }
                if ( i == ycol ) {
                    y = parseDouble( vals.get( i ) );
                    continue;
                }

                QualifiedName name = new QualifiedName( "app:property" + i, APPNS );
                fps.add( createFeatureProperty( name, vals.get( i ) ) );
                fpt.add( createSimplePropertyType( name, Types.VARCHAR, true ) );
            }

            fps.add( createFeatureProperty( geomName, createPoint( x, y, null ) ) );
            fpt.add( createGeometryPropertyType( geomName, null, 1, 1 ) );
            FeatureType tp = FeatureFactory.createFeatureType( featureName, false,
                                                               fpt.toArray( new PropertyType[fpt.size()] ) );
            fc.add( createFeature( ++counter + "", tp, fps ) );
        }

        return fc;
    }
}
