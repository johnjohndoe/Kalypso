//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/crs/coordinatesystems/GeographicCRS.java $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.crs.coordinatesystems;

import java.util.List;

import org.deegree.crs.Identifiable;
import org.deegree.crs.components.Axis;
import org.deegree.crs.components.GeodeticDatum;
import org.deegree.crs.components.Unit;
import org.deegree.crs.transformations.polynomial.PolynomialTransformation;
import org.deegree.i18n.Messages;

/**
 * The <code>GeographicCoordinateSystem</code> (in epsg aka Geodetic CRS) is a two dimensional crs
 * with axis of lat-lon.
 * 
 * @author <a href="mailto:bezema@lat-lon.de">Rutger Bezema</a>
 * 
 * @author last edited by: $Author: rbezema $
 * 
 * @version $Revision: 10995 $, $Date: 2008-04-09 16:58:30 +0200 (Wed, 09 Apr 2008) $
 * 
 */

public class GeographicCRS extends CoordinateSystem {

    /**
     * A geographic coordinate system using WGS84 datum. This coordinate system use <var>longitude</var>/<var>latitude</var>
     * axis with latitude values increasing north and longitude values increasing east. Angular
     * units are degrees and prime meridian is Greenwich.
     */
    public static final GeographicCRS WGS84 = new GeographicCRS(
                                                                 GeodeticDatum.WGS84,
                                                                 new Axis[] {
                                                                             new Axis( Unit.DEGREE, "lon", Axis.AO_EAST ),
                                                                             new Axis( Unit.DEGREE, "lat",
                                                                                       Axis.AO_NORTH ) }, "EPSG:4326",
                                                                 "WGS 84" );

    /**
     * @param datum
     * @param axisOrder
     * @param identity
     * @throws IllegalArgumentException
     *             if the axisOrder.length != 2.
     */
    public GeographicCRS( GeodeticDatum datum, Axis[] axisOrder, Identifiable identity )
                            throws IllegalArgumentException {
        this( null, datum, axisOrder, identity );
    }

    /**
     * @param datum
     * @param axisOrder
     * @param identifiers
     * @param names
     * @param versions
     * @param descriptions
     * @param areasOfUse
     * @throws IllegalArgumentException
     *             if the axisOrder.length != 2.
     */
    public GeographicCRS( GeodeticDatum datum, Axis[] axisOrder, String[] identifiers, String[] names,
                          String[] versions, String[] descriptions, String[] areasOfUse )
                            throws IllegalArgumentException {
        super( datum, axisOrder, identifiers, names, versions, descriptions, areasOfUse );
        if ( axisOrder.length != 2 ) {
            throw new IllegalArgumentException( Messages.getMessage( "CRS_COORDINATESYSTEMS_WRONG_AXIS_DIM",
                                                                     "Geographic", "2" ) );
        }
    }

    /**
     * @param datum
     * @param axisOrder
     * @param identifiers
     */
    public GeographicCRS( GeodeticDatum datum, Axis[] axisOrder, String[] identifiers ) {
        this( datum, axisOrder, identifiers, null, null, null, null );
    }

    /**
     * @param datum
     * @param axisOrder
     * @param identifier
     * @param name
     * @param version
     * @param description
     * @param areaOfUse
     */
    public GeographicCRS( GeodeticDatum datum, Axis[] axisOrder, String identifier, String name, String version,
                          String description, String areaOfUse ) {
        this( datum, axisOrder, new String[] { identifier }, new String[] { name }, new String[] { version },
              new String[] { description }, new String[] { areaOfUse } );
    }

    /**
     * @param datum
     * @param axisOrder
     * @param identifier
     * @param name
     */
    public GeographicCRS( GeodeticDatum datum, Axis[] axisOrder, String identifier, String name ) {
        this( datum, axisOrder, new String[] { identifier }, new String[] { name }, null, null, null );
    }

    /**
     * @param transformations
     * @param usedDatum
     * @param axisOrder
     * @param id
     */
    public GeographicCRS( List<PolynomialTransformation> transformations, GeodeticDatum usedDatum, Axis[] axisOrder,
                          Identifiable id ) {
        super( transformations, usedDatum, axisOrder, id );
        if ( axisOrder.length != 2 ) {
            throw new IllegalArgumentException( Messages.getMessage( "CRS_COORDINATESYSTEMS_WRONG_AXIS_DIM",
                                                                     "Geographic", "2" ) );
        }
    }

    @Override
    public int getDimension() {
        return 2;
    }

    @Override
    public int getType() {
        return GEOGRAPHIC_CRS;
    }

}
