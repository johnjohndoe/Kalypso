//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/crs/transformations/polynomial/LeastSquareApproximation.java $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.crs.transformations.polynomial;

import static org.deegree.crs.projections.ProjectionUtils.EPS11;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import javax.media.jai.WarpCubic;
import javax.media.jai.WarpGeneralPolynomial;
import javax.media.jai.WarpPolynomial;
import javax.media.jai.WarpQuadratic;
import javax.vecmath.Point3d;

import org.deegree.crs.coordinatesystems.CoordinateSystem;
import org.deegree.crs.exceptions.TransformationException;
import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.i18n.Messages;

/**
 * <code>LeastSquareApproximation</code> is a polynomial transformation which uses the least square method to
 * approximate a function given by some measured values.
 * 
 * @author <a href="mailto:bezema@lat-lon.de">Rutger Bezema</a>
 * 
 * @author last edited by: $Author: rbezema $
 * 
 * @version $Revision: 10997 $, $Date: 2008-04-09 17:00:34 +0200 (Wed, 09 Apr 2008) $
 * 
 */
public class LeastSquareApproximation extends PolynomialTransformation {
    private static ILogger LOG = LoggerFactory.getLogger( LeastSquareApproximation.class );

    private WarpPolynomial leastSquarePolynomial;

    private final int order;

    private final float scaleX;

    private final float scaleY;

    /**
     * @param firstParameters
     *            of the polynomial
     * @param secondParameters
     *            of the polynomial
     * @param targetCRS
     *            of this transformation
     * @param scaleX
     *            to apply to incoming data's x value, if 1 (or 0) no scale will be applied.
     * @param scaleY
     *            to apply to incoming data's y value, if 1 (or 0) no scale will be applied.
     */
    public LeastSquareApproximation( List<Double> firstParameters, List<Double> secondParameters,
                                     CoordinateSystem targetCRS, float scaleX, float scaleY ) {
        super( firstParameters, secondParameters, targetCRS );
        if ( getSecondParams().size() != getFirstParams().size() ) {
            throw new IllegalArgumentException( "The given parameter lists do not have equal length" );
        }
        // calc from (n+1)*(n+2) = 2*size;
        order = (int) Math.floor( ( -3 + Math.sqrt( 9 + ( 4 * ( getFirstParams().size() * 2 ) - 2 ) ) ) * 0.5 );
        float[] aParams = new float[getFirstParams().size()];
        for ( int i = 0; i < firstParameters.size(); ++i ) {
            aParams[i] = firstParameters.get( i ).floatValue();
        }
        float[] bParams = new float[getSecondParams().size()];
        for ( int i = 0; i < secondParameters.size(); ++i ) {
            bParams[i] = secondParameters.get( i ).floatValue();
        }
        if ( Float.isNaN( scaleX ) || Math.abs( scaleX ) < EPS11 ) {
            scaleX = 1;
        }
        this.scaleX = scaleX;

        if ( Float.isNaN( scaleY ) || Math.abs( scaleY ) < EPS11 ) {
            scaleY = 1;
        }
        this.scaleY = scaleY;
        switch ( order ) {
        case 2:
            leastSquarePolynomial = new WarpQuadratic( aParams, bParams, this.scaleX, this.scaleY, 1f / this.scaleX,
                                                       1f / this.scaleY );
            break;
        case 3:

            leastSquarePolynomial = new WarpCubic( aParams, bParams, this.scaleX, this.scaleY, 1f / this.scaleX,
                                                   1f / this.scaleY );
            break;
        default:
            leastSquarePolynomial = new WarpGeneralPolynomial( aParams, bParams, this.scaleX, this.scaleY,
                                                               1f / this.scaleX, 1f / this.scaleY );
            break;
        }
    }

    @Override
    public List<Point3d> applyPolynomial( List<Point3d> srcPts )
                            throws TransformationException {
        if ( srcPts == null || srcPts.size() == 0 ) {
            return srcPts;
        }
        List<Point3d> result = new ArrayList<Point3d>( srcPts.size() );
        for ( Point3d p : srcPts ) {
            Point2D r = leastSquarePolynomial.mapDestPoint( new Point2D.Double( p.x, p.y ) );
            if ( r != null ) {
                result.add( new Point3d( r.getX(), r.getY(), p.z ) );
            } else {
                throw new TransformationException( Messages.getMessage( "CRS_POLYNOMIAL_TRANSFORM_ERROR", p.toString() ) );
            }
        }
        return result;
    }

    @Override
    public String getName() {
        return "leastsquare";
    }

    @Override
    public float[][] createVariables( List<Point3d> originalPoints, List<Point3d> projectedPoints, int polynomalOrder ) {
        float[] sourceCoords = new float[originalPoints.size() * 2];
        int count = 0;
        double minX = Double.MAX_VALUE;
        double minY = Double.MAX_VALUE;

        double maxX = Double.MIN_VALUE;
        double maxY = Double.MIN_VALUE;

        for ( Point3d coord : originalPoints ) {
            if ( minX > coord.x ) {
                minX = coord.x;
            }
            if ( maxX < coord.x ) {
                maxX = coord.x;
            }
            if ( minY > coord.y ) {
                minY = coord.y;
            }
            if ( maxY < coord.y ) {
                maxY = coord.y;
            }
            sourceCoords[count++] = (float) coord.x;
            sourceCoords[count++] = (float) coord.y;
        }

        float scaleX = Math.abs( ( maxX - minX ) ) > EPS11 ? (float) ( 1. / ( maxX - minX ) ) : 1;
        float scaleY = Math.abs( ( maxY - minY ) ) > EPS11 ? (float) ( 1. / ( maxY - minY ) ) : 1;
        float[] targetCoords = new float[projectedPoints.size() * 2];

        count = 0;
        for ( Point3d coord : projectedPoints ) {
            targetCoords[count++] = (float) coord.x;
            targetCoords[count++] = (float) coord.y;
        }



        StringBuilder sb = new StringBuilder( "\nCalculated scales are:\n" );
        sb.append( "<crs:scaleX>" ).append( scaleX ).append( "</crs:scaleX>\n" );
        sb.append( "<crs:scaleY>" ).append( scaleY ).append( "</crs:scaleY>\n" );
        LOG.logInfo( sb.toString() );

        /**
         * create warp object from reference points and desired interpolation, Because jai only implements the
         * mapDestPoint function, we must calculate the polynomial variables by using the target coordinates as the
         * source.
         */
        WarpPolynomial warp = WarpPolynomial.createWarp( targetCoords, 0, sourceCoords, 0, sourceCoords.length, scaleX,
                                                         scaleY, 1f / scaleX, 1f / scaleY, polynomalOrder );
        return warp.getCoeffs();
    }

    @Override
    public int getOrder() {
        return order;
    }

    /**
     * @return the scale which will be applied to the x value of all incoming data
     */
    public final float getScaleX() {
        return scaleX;
    }

    /**
     * @return the scale which will be applied to the y value of all incoming data
     */
    public final float getScaleY() {
        return scaleY;
    }

}
