//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/enterprise/servlet/WFSRequestMapping.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 ---------------------------------------------------------------------------*/
package org.deegree.enterprise.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Properties;

import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.framework.util.StringTools;
import org.deegree.framework.xml.NamespaceContext;
import org.deegree.framework.xml.XMLTools;
import org.deegree.ogcbase.CommonNamespaces;
import org.w3c.dom.Node;

/**
 * This class respectively its method {@link #mapPropertyValue(Node)} can be used by XSLT scripts to map a node value
 * (key) to another, corresponding value (value). The mappings are taken from the properties file
 * <code>org.deegree.enterprise.servlet.wfsrequestmapping.properties</code>. If no matching value for a key is
 * defined in the properties file, the returned <code>String</code> is null.
 * <p>
 * The node reference passed to this method must point to an element that contains a single text node, e.g.
 * &lt;PropertyName&gt;/MyProperty/value&lt;/PropertyName&gt;
 * </p>
 * <p>
 * If a special behavior is needed by a deegree WFS instance and/or you do not want to edit the default properties and
 * use your own one you should write a class that extends this or it as pattern.
 * 
 * @see #mapPropertyValue(Node)
 * @see java.util.Properties
 * 
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: apoth $
 * 
 * @version $Revision: 11884 $, $Date: 2008-05-22 15:26:16 +0200 (Thu, 22 May 2008) $
 */
public class WFSRequestMapping {

    private static ILogger LOG = LoggerFactory.getLogger( WFSRequestMapping.class );

    /** TODO why is this here and ununused? */
    protected static String propertiesFile = "wfsrequestmapping.properties";

    private static Properties mapping = null;
    static {
        mapping = new Properties();
        try {
            URL url = WFSRequestMapping.class.getResource( "/wfsrequestmapping.properties" );
            InputStream is = null;
            if ( url != null ) {
                is = url.openStream();
            } else {
                is = WFSRequestMapping.class.getResourceAsStream( "wfsrequestmapping.properties" );
            }
            InputStreamReader isr = new InputStreamReader( is );
            BufferedReader br = new BufferedReader( isr );
            String line = null;
            while ( ( line = br.readLine() ) != null ) {
                if ( !line.trim().startsWith( "#" ) ) {
                    String[] tmp = StringTools.toArray( line, "=", false );
                    mapping.put( tmp[0], tmp[1] );
                }
            }
        } catch ( IOException e ) {
            e.printStackTrace();
        }
    }

    private static NamespaceContext nsc = CommonNamespaces.getNamespaceContext();

    /**
     * This method can be used by XSLT scripts to map a node value (key) to another, corresponding value (value). The
     * mappings are taken from the properties file
     * <code>org.deegree.enterprise.servlet.wfsrequestmapping.properties</code>. If no matching value for a key is
     * defined in the properties file, the returned <code>String</code> is null.
     * <p>
     * The node reference passed to this method must point to an element that contains a single text node, e.g.
     * &lt;PropertyName&gt;/MyProperty/value&lt;/PropertyName&gt;
     * </p>
     * 
     * @param node
     *            node that will be mapped
     * @return mapping for the node as an XPath, null if no mapping is defined
     */
    public static String mapPropertyValue( Node node ) {

        String nde = null;
        String key = null;
        try {
            nde = XMLTools.getNodeAsString( node, ".", nsc, null );
            if ( nde.startsWith( "/" ) ) {
                key = '.' + nde;
            } else if ( nde.startsWith( "." ) ) {
                key = nde;
            } else {
                key = "./" + nde;
            }
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        if ( mapping.getProperty( key ) != null ) {
            nde = mapping.getProperty( key );
        }
        LOG.logDebug( "mapped property: " + nde );
        return nde;
    }
}