/*----------------    FILE HEADER  ------------------------------------------

This file is part of deegree.
Copyright (C) 2001 by:
EXSE, Department of Geography, University of Bonn
http://www.giub.uni-bonn.de/exse/
lat/lon Fitzke/Fretter/Poth GbR
http://www.lat-lon.de

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Contact:

Andreas Poth
lat/lon Fitzke/Fretter/Poth GbR
Meckenheimer Allee 176
53115 Bonn
Germany
E-Mail: poth@lat-lon.de

Jens Fitzke
Department of Geography
University of Bonn
Meckenheimer Allee 166
53115 Bonn
Germany
E-Mail: jens.fitzke@uni-bonn.de

                 
 ---------------------------------------------------------------------------*/
package org.deegree_impl.clients.context;

import java.awt.Color;

import java.util.ArrayList;
import java.util.Iterator;

import org.deegree.clients.context.*;
import org.deegree.model.geometry.GM_Envelope;
import org.deegree.model.geometry.GM_Point;
import org.deegree.services.wms.protocol.WMSGetMapRequest;
import org.deegree.tools.Parameter;
import org.deegree.tools.ParameterList;

import org.deegree_impl.model.geometry.GeometryFactory;
import org.deegree_impl.services.wms.protocol.WMSProtocolFactory;
import org.deegree_impl.tools.NetWorker;

import org.opengis.cs.CS_CoordinateSystem;


/**
 * This class offers methods for creating JSP and JavaSript fragments depending
 * on the Map context document used as configuration for the deegree web map
 * client.<p/>
 * The created fragments partially uses javascript calls as defined in the 
 * deegree integrated client. if somebody needs other javascript methods he/she
 * must write its own creator methods or must directly use an instance of a
 * <tt>ViewContext</tt> in a JSP page.
 *
 * @version $Revision: 1.1 $
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 */
public class JSPCreator {
    /**
     * creates JSP import statement for the modules being part of an area of the
     * GUI/page. Known areas are GUIArea.WEST, GUIArea.EAST, GUIArea.NORTH, 
     * GUIArea.SOUTH and GUIArea.CENTER 
     *
     * @param viewContext 
     * @param area area to create import statements for
     *
     * @return JSP import fragment
     */
    public static String getArea( ViewContext viewContext, int area ) {
        GeneralExtension ge = (GeneralExtension)viewContext.getGeneral().getExtension();
        StringBuffer sb = new StringBuffer( 5000 );

        if ( ge != null ) {
            Frontend frontend = ge.getFrontend();
            GUIArea guiarea = null;

            switch ( area ) {
                case GUIArea.WEST:
                    guiarea = frontend.getWest();
                    break;
                case GUIArea.EAST:
                    guiarea = frontend.getEast();
                    break;
                case GUIArea.SOUTH:
                    guiarea = frontend.getSouth();
                    break;
                case GUIArea.NORTH:
                    guiarea = frontend.getNorth();
                    break;
                case GUIArea.CENTER:
                    guiarea = frontend.getCenter();
                    break;
            }

            if ( guiarea != null ) {
                Module[] module = guiarea.getModules();

                for ( int i = 0; i < module.length; i++ ) {
                    if ( !module[i].isHidden() ) {
                        sb.append( "<jsp:include page=\"" ).append( module[i].getContent() )
                          .append( "\" flush=\"true\" />\n" );
                    }
                }
            }
        }

        return sb.toString();
    }

    /**
     * creates a set of constructor calls that are requierd to initialize the
     * GUI. Each module that is registered will be represented by a JavaScript
     * object. For each of these objects one instance will be created and 
     * registered by the central controller which also is a JavaScript object.
     *
     * @param viewContext web map context
     *
     * @return javascript fragment
     */
    public static String createJSInitSection( ViewContext viewContext ) {
        GeneralExtension ge = (GeneralExtension)viewContext.getGeneral().getExtension();
        StringBuffer sb = new StringBuffer( 5000 );

        // init central javascript controller to be able to establish 
        // communication between the inculded JS/JSP modules
        sb.append( "controller = new Controller();\n" );

        if ( ge != null ) {
            // init objects for each defined area of the JSP page
            Frontend frontend = ge.getFrontend();
            GUIArea guiarea = frontend.getWest();

            if ( guiarea != null ) {
                sb.append( createInitCalls( guiarea ) );
            }

            guiarea = frontend.getEast();

            if ( guiarea != null ) {
                sb.append( createInitCalls( guiarea ) );
            }

            guiarea = frontend.getSouth();

            if ( guiarea != null ) {
                sb.append( createInitCalls( guiarea ) );
            }

            guiarea = frontend.getNorth();

            if ( guiarea != null ) {
                sb.append( createInitCalls( guiarea ) );
            }

            guiarea = frontend.getCenter();

            if ( guiarea != null ) {
                sb.append( createInitCalls( guiarea ) );
            }
        }

        return sb.toString();
    }

    /**
     *
     *
     * @param guiarea 
     *
     * @return 
     */
    private static StringBuffer createInitCalls( GUIArea guiarea ) {
        StringBuffer sb = new StringBuffer( 1000 );
        Module[] module = guiarea.getModules();

        for ( int i = 0; i < module.length; i++ ) {
            sb.append( "var " ).append( module[i].getName().toLowerCase() ).append( " = new " )
              .append( module[i].getName() ).append( '(' );
            // add parameter to constructor call if defined
            ParameterList pList = module[i].getParameter();

            if ( pList != null ) {
                Object[] values = pList.getParameterValues();

                for ( int k = 0; k < values.length; k++ ) {
                    sb.append( values[k] );

                    if ( k < ( values.length - 1 ) ) {
                        sb.append( ',' );
                    }
                }
            }

            sb.append( ");\n" );
            sb.append( "controller.registerModule( " ).append( module[i].getName().toLowerCase() )
              .append( ");\n" );
        }

        return sb;
    }

    /**
     * returns an matrix containing an array of layer for each server defined
     * in the map context. the matrix is ordered in that way that in the first
     * row and first field you find the server in the second field you find an
     * array of layers served by the server. In the next row the same is done
     * for another server. In the third row you find another server or the same
     * server as in the first row because the layer order as defined in the
     * map context requiers asking one server two or more times.
     *
     * @param viewContext 
     *
     * @return 
     */
    public static Object[][] getLayersGroupedByService( ViewContext viewContext ) {
        ArrayList servers = new ArrayList( 50 );
        ArrayList ll = new ArrayList( 50 );

        LayerList layerList = viewContext.getLayerList();
        Layer[] layers = layerList.getLayers();
        int i = 0;
        Server key = layers[0].getServer();
        Server tmp = key;

        while ( i < layers.length ) {
            servers.add( key );
            ArrayList list = new ArrayList();

            while ( key.equals( tmp ) && ( i < layers.length ) ) {
                list.add( layers[i] );
                tmp = layers[i++].getServer();
            }

            ll.add( (Layer[])list.toArray( new Layer[list.size()] ) );
            key = tmp;
        }

        Object[][] o = new Object[servers.size()][2];

        for ( i = 0; i < servers.size(); i++ ) {
            o[i][0] = servers.get( i );
            o[i][1] = ll.get( i );
        }

        return o;
    }

    /**
     * creates a list of servers and GetMap requests assigned to them from a
     * <tt>ViewContext</tt>. The requests/servers are order like they appears
     * in the underlying web map context document. The requests are presented in 
     * a bottom to top approach.
     * TODO:
     * the method currently doesn't deal with layers using SLD for style
     * description and services others than WMS
     *
     * @param viewContext 
     *
     * @return 
     */
    public static String[][] getSeriveRequests( ViewContext viewContext ) throws ContextException {
        int width = viewContext.getGeneral().getWindow().width;
        int height = viewContext.getGeneral().getWindow().height;
        GM_Point[] bbox = viewContext.getGeneral().getBoundingBox();
        GeometryFactory gf = new GeometryFactory();
        GM_Envelope env = gf.createGM_Envelope( bbox[0].getX(), bbox[0].getY(), bbox[1].getX(), 
                                                bbox[1].getY() );
        String crs = null;

        try {
            crs = bbox[0].getCoordinateSystem().getName();
        } catch ( Exception e ) {
        }

        org.deegree.services.wms.protocol.WMSGetMapRequest.Layer[] reqLay = null;
        String format = null;

        Object[][] serv = getLayersGroupedByService( viewContext );
        String[][] initGMR = new String[serv.length][2];

        for ( int i = 0; i < serv.length; i++ ) {
            Server server = (Server)serv[i][0];
            Layer[] layers = (Layer[])serv[i][1];

            if ( usesSLD( layers ) ) {
                // TODO
                // create GetMap Request is at least one layer uses SLD
            } else {
                // create requiered layer, style and format attributes if a
                // convetional KVP without SLD should be used
                reqLay = new org.deegree.services.wms.protocol.WMSGetMapRequest.Layer[layers.length];

                for ( int k = 0; k < layers.length; k++ ) {
                    if ( !layers[i].isHidden() ) {
                        String sName = layers[k].getStyleList().getCurrentStyle().getName();
                        String lName = layers[k].getName();
                        reqLay[k] = org.deegree_impl.services.wms.protocol.WMSGetMapRequest_Impl.createLayer( 
                                            lName, sName );
                        format = layers[k].getFormatList().getCurrentFormat().getName();
                    }
                }
            }

            WMSGetMapRequest gmr = null;

            try {
                gmr = WMSProtocolFactory.createGetMapRequest( server.getVersion(), "" + i, reqLay, 
                                                              null, null, format, width, height, 
                                                              crs, env, true, Color.WHITE, 
                                                              "application/vnd.ogc.se_xml", null, 
                                                              null, null, null );
                initGMR[i][0] = NetWorker.url2String( server.getOnlineResource() );
                initGMR[i][1] = gmr.getRequestParameter();
            } catch ( Exception e ) {
                e.printStackTrace();
                throw new ContextException( "couldn't create initial GetMap requests", e );
            }
        }

        return initGMR;
    }

    /**
     * returns true if one of the passed layers uses SLD instead of named styles
     */
    private static boolean usesSLD( Layer[] layers ) {
        boolean sld = false;

        for ( int k = 0; k < layers.length; k++ ) {
            StyleList styleList = layers[k].getStyleList();
            Style style = styleList.getCurrentStyle();

            if ( style != null ) {
                if ( style.getSld() != null ) {
                    sld = true;
                    break;
                }
            }
        }

        return sld;
    }

    /**
     * returns the layers contained in the passed <tt>ViewContext</tt> as a
     * HTML table with a Checkbox for visibility and a Radiobutton for
     * query (featureInfo). The method assues that the deegree integrated 
     * client or Map client will be used so the corresponding JavaScript calls
     * will be created.
     *
     * @param viewContext 
     *
     * @return 
     */
    public static String getLayerAsHTMLTable( ViewContext viewContext ) {
        StringBuffer sb = new StringBuffer( 15000 );
        sb.append(  getLayerAsHTMLTableJS() );
        sb.append( "<table id='LayerList' border='0' cellspacing='0' cellpadding='0'>\n" );
        sb.append( "<form name='layerform'>\n" );

        Object[][] serv = getLayersGroupedByService( viewContext );

        int c = 0;
        for ( int i = serv.length-1; i >= 0; i-- ) {
            Layer[] layers = (Layer[])serv[i][1];
            for ( int k = layers.length-1; k >= 0; k-- ) {
                sb.append( "<tr>\n" );
                // checkbox section
                sb.append( "<td id =' r" ).append( c )
                  .append( "c0'/><input type='checkbox' name='check' ");
                if ( !layers[k].isHidden() ) {
                    sb.append( "checked " );
                }
                sb.append( "value='").append( layers[k].getName() ).append( "'/></td>\n" );
                // title section 
                sb.append( "<td id =' r").append( c ).append( "c1' onclick=\"change('row" )
                  .append( c ).append("');\"/>" );
                sb.append( layers[k].getTitle() ).append( "</td>\n" );
                // radiobutton section
                sb.append( "<td id =' r" ).append( c )
                  .append( "c2'/><input type='radio' name='radiocheck' ");
                if ( !layers[k].isQueryable() ) {
                    sb.append( "checked " );
                }
                sb.append( "value='").append( layers[k].getName() ).append( "'/></td>\n" );
                
                sb.append( "</tr>\n" );
                c++;
            }
        }

        sb.append( "</form></table>" );

        return sb.toString();
    }

    /**
     *
     *
     * @return 
     */
    private static StringBuffer getLayerAsHTMLTableJS() {
        StringBuffer sb = new StringBuffer( 10000 );
        sb.append( "var selectedRow = 0; \n" );
        sb.append( "function up() { \n" );
        sb.append( " var radiocheck = false; \n" );
        sb.append( " var check = false; \n" );
        sb.append( " if(selectedRow != 0) {  \n" );
        sb.append( " var row = document.getElementById(selectedRow);  \n" );
        sb.append( " var zeile = row.rowIndex; \n" );
        sb.append( " if(zeile != 0) {  \n" );
        sb.append( " if( document.forms['layerform'].check[zeile].checked == true) { \n" );
        sb.append( " check = true; } \n" );
        sb.append( " if( document.forms['layerform'].radiocheck[zeile].checked == true) { \n" );
        sb.append( " radiocheck = true; } \n" );
        sb.append( " document.getElementById('Tabelle').moveRow(zeile,zeile-1); \n" );
        sb.append( " if(check) {  \n" );
        sb.append( " document.forms['layerform'].check[zeile-1].checked = true; \n" );
        sb.append( " } else { \n" );
        sb.append( " document.forms['layerform'].check[zeile-1].checked = false; }\n" );
        sb.append( " if(radiocheck) { \n" );
        sb.append( " document.forms['layerform'].radiocheck[zeile-1].checked = true; \n" );
        sb.append( " } else { \n" );
        sb.append( " document.forms['layerform'].radiocheck[zeile-1].checked = false; \n" );
        sb.append( " } } } } \n" );
        sb.append( "function down() { \n" );
        sb.append( " var radiocheck = false; \n" );
        sb.append( " var check = false; \n" );
        sb.append( " if(selectedRow != 0) {  \n" );
        sb.append( " var row = document.getElementById(selectedRow); \n" );
        sb.append( " var zeile = row.rowIndex; \n" );
        sb.append( " if( zeile < ( document.getElementsByTagName('tr').length - 1 ) ) {  \n" );
        sb.append( " if(document.forms['layerform'].check[zeile].checked == true) { \n" );
        sb.append( " check = true; }\n" );
        sb.append( " if(document.forms['layerform'].radiocheck[zeile].checked == true) { \n" );
        sb.append( " radiocheck = true; }\n" );
        sb.append( " document.getElementById('Tabelle').moveRow(zeile,zeile+1); \n" );
        sb.append( " if(check) {  \n" );
        sb.append( " document.forms['layerform'].check[zeile+1].checked = true; \n" );
        sb.append( " } else { \n" );
        sb.append( " document.forms['layerform'].check[zeile+1].checked = false; } \n" );
        sb.append( " if(radiocheck) { \n" );
        sb.append( " document.forms['layerform'].radiocheck[zeile+1].checked = true; \n" );
        sb.append( " } else { \n" );
        sb.append( " document.forms['layerform'].radiocheck[zeile+1].checked = false; \n" );
        sb.append( " } } \n" );
        sb.append( " check = false;	 \n" );
        sb.append( " } } \n" );
        sb.append( "function change(rowID) { \n" );
        sb.append( " if (selectedRow != 0) { \n" );
        sb.append( " document.getElementById(selectedRow).bgColor='#BBBED4'; }\n" );
        sb.append( " selectedRow = rowID; \n" );
        sb.append( " var row = document.getElementById(rowID); \n" );
        sb.append( " row.bgColor='#AAFFFF'; }\n" );
        return sb;
    }

    /**
     *
     *
     * @param viewContext 
     *
     * @return 
     */
    public static String getVisibleLayersAsHTMLList( ViewContext viewContext ) {
        return null;
    }

    /**
     *
     *
     * @param viewContext 
     *
     * @return 
     */
    public static String getAvailableLayersAsHTMLList( ViewContext viewContext ) {
        return null;
    }

    /**
     *
     *
     * @param viewContext 
     *
     * @return 
     */
    public static String getAvailableLayersAsComboBox( ViewContext viewContext ) {
        return null;
    }

    /**
     *
     *
     * @param viewContext 
     *
     * @return 
     */
    public static String getControlBarContent( ViewContext viewContext ) {
        return null;
    }

    /**
     *
     *
     * @param args 
     *
     * @throws Exception 
     */
    public static void main( String[] args ) throws Exception {
        ViewContext vc = WebMapContextFactory.createViewContext( 
                                 "C:/java/projekte/huis/produktionssystem/fachschalen/mapcontext_entwurf.xml" );
        System.out.println(JSPCreator.getLayerAsHTMLTable( vc ));
    }
}