/*----------------    FILE HEADER  ------------------------------------------

This file is part of deegree.
Copyright (C) 2001 by:
EXSE, Department of Geography, University of Bonn
http://www.giub.uni-bonn.de/exse/
lat/lon Fitzke/Fretter/Poth GbR
http://www.lat-lon.de

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Contact:

Andreas Poth
lat/lon Fitzke/Fretter/Poth GbR
Meckenheimer Allee 176
53115 Bonn
Germany
E-Mail: poth@lat-lon.de

Jens Fitzke
Department of Geography
University of Bonn
Meckenheimer Allee 166
53115 Bonn
Germany
E-Mail: jens.fitzke@uni-bonn.de

                 
 ---------------------------------------------------------------------------*/
package org.deegree_impl.services.wts;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.media.j3d.Appearance;
import javax.media.j3d.Geometry;
import javax.media.j3d.Group;
import javax.media.j3d.Material;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Texture;
import javax.media.j3d.TextureAttributes;
import javax.media.j3d.Transform3D;
import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import org.deegree.gml.GMLFeature;
import org.deegree.gml.GMLFeatureCollection;
import org.deegree.gml.GMLProperty;
import org.deegree.model.feature.FeatureCollection;
import org.deegree.model.geometry.GM_Envelope;
import org.deegree.model.geometry.GM_Exception;
import org.deegree.model.geometry.GM_Position;
import org.deegree.model.geometry.GM_Surface;
import org.deegree.services.OGCWebServiceClient;
import org.deegree.services.OGCWebServiceEvent;
import org.deegree.services.OGCWebServiceException;
import org.deegree.services.OGCWebServiceRequest;
import org.deegree.services.OGCWebServiceResponse;
import org.deegree.services.WebServiceException;
import org.deegree.services.wcs.protocol.WCSGetCoverageRequest;
import org.deegree.services.wcs.protocol.WCSGetCoverageResponse;
import org.deegree.services.wfs.protocol.WFSGetFeatureResponse;
import org.deegree.services.wms.protocol.WMSGetMapResponse;
import org.deegree.services.wts.ViewPoint;
import org.deegree.services.wts.WTSScene;
import org.deegree.services.wts.capabilities.WTSCapabilities;
import org.deegree.services.wts.configuration.WTSConfiguration;
import org.deegree.services.wts.protocol.WTSGetCapabilitiesRequest;
import org.deegree.services.wts.protocol.WTSGetViewRequest;
import org.deegree.xml.Marshallable;
import org.deegree_impl.model.cs.Adapters;
import org.deegree_impl.model.cs.ConvenienceCSFactory;
import org.deegree_impl.model.cs.CoordinateSystem;
import org.deegree_impl.model.geometry.GeometryFactory;
import org.deegree_impl.services.OGCWebServiceEvent_Impl;
import org.deegree_impl.services.OGCWebServiceException_Impl;
import org.deegree_impl.services.OGCWebService_Impl;
import org.deegree_impl.services.wcs.WCService_Impl;
import org.deegree_impl.services.wcs.protocol.WCSProtocolFactory;
import org.deegree_impl.services.wfs.protocol.WFSProtocolFactory;
import org.deegree_impl.services.wts.configuration.WTSConfiguration_Impl;
import org.deegree_impl.services.wts.protocol.WTSProtocolFactory;
import org.deegree_impl.services.wts.util.Converter;
import org.deegree_impl.tools.Debug;
import org.opengis.cs.CS_CoordinateSystem;
import org.w3c.dom.Document;

import com.sun.media.jai.codec.ByteArraySeekableStream;
import com.sun.media.jai.codec.SeekableStream;


/**
 *
 * <p>-----------------------------------------------------------------------</p>
 *
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @version $Revision: 1.18 $ $Date: 2004/02/09 08:00:39 $
 */
public class WTService_Impl extends OGCWebService_Impl implements OGCWebServiceClient {
    private OGCWebServiceClient client = null;
    private WTSCapabilities capabilities = null;
    private GM_Surface[][] boxes = null;
    private Object[][] demTiles = null;
    private Object[][][] textureTiles = null;
    private ArrayList feature = null;
    private OGCWebServiceRequest request = null;    
    private int count = 0;
    private OffScreenWTSRenderer renderer = null;

    /**
     *
     *
     * @param event 
     *
     * @throws WebServiceException 
     */
    public void doService(OGCWebServiceEvent event) throws WebServiceException {
        Debug.debugMethodBegin(this, "doService");
        
        feature = new ArrayList(1000);
        request = event.getRequest();
        client = event.getDestination();

        if (request instanceof WTSGetCapabilitiesRequest) {
            handleGetCapabilities((WTSGetCapabilitiesRequest) request);
        } else if (request instanceof WTSGetViewRequest) {
            try {
                handleGetView((WTSGetViewRequest) request);
            } catch (Exception e) {
                // TODO
                // create error message
                System.out.println(e);
            }
        } else {
            // TODO
            // create error message
        }

        Debug.debugMethodEnd();
    }
    
    /**
     * the method performs the handling of the passed OGCWebServiceEvent directly 
     * and returns the result to the calling class/method
     *
     * @param request request (WMS, WCS, WFS, WCAS, WCTS, WTS, Gazetter) to perform
     *
     * @throws WebServiceException 
     */
    public OGCWebServiceResponse doService( OGCWebServiceRequest request ) throws WebServiceException {
        Debug.debugMethodBegin();        
        Debug.debugMethodEnd();
        throw new NoSuchMethodError( "doService(OGCWebServiceRequest)" );
    }

    /**
     * performs a get capabilities request by writing an XML representation
     * of the capabilities to the receiver (destination) of the response of
     * the request.
     */
    private void handleGetCapabilities(WTSGetCapabilitiesRequest request) {
        Debug.debugMethodBegin(this, "handleGetCapabilitiesRequest");
        client.write(capabilities.exportAsXML());
        Debug.debugMethodEnd();
    }

    /**
     * performs a get view request by initializing a <tt>WTSScene</tt>, forcing
     * an offscreen rendering of the scene and writing the resulting image
     * encapsulated into a <tt>GetViewResponse</tt> object to the receiver of
     * the response.
     */
    private void handleGetView(WTSGetViewRequest request) throws Exception {
        Debug.debugMethodBegin(this, "handleGetView");

        // create viewpoint object
        ViewPoint vp = createViewPoint(request);

        // get footprint of the view
        Point3d[] footprint = vp.getFootprint();

        // split the footprint into several boxes that can be handled independly
        // to retrieve higher terrain resolutions for the boxes in front ...
        Splitter sp = new Splitter(request, vp);
        GM_Surface[] sur = sp.makeStripes(9);
        boxes = new GM_Surface[sur.length][];

        for (int i = 0; i < sur.length; i++) {
            boxes[i] = sp.makeBoxes(sur[i], 3);
        }
                
        int textCnt = request.getLayers().length;

        WTSConfiguration conf = WTSConfiguration_Impl.getInstance();
        textureTiles = new Object[textCnt][boxes.length][boxes[0].length];

        demTiles = new Object[boxes.length][boxes[0].length];
        
        count = request.getElevationModels().length;
        count += request.getLayers().length;
        count *= (boxes.length * boxes[0].length);
        if ( request.getFeatureCollections() != null && 
             request.getFeatureCollections().length > 0 ) {
            count++;
        }
     
        // perform dem requests in a seperate thread
        DEMLoader dl = new DEMLoader( request, this );
        dl.start();

        for (int i = 0; i < textCnt; i++) {
            // perform texture requests in a seperate thread
            TextureLoader tl = new TextureLoader( request, i, this );
            tl.start();
        }
        
        // perform request for getting features superimposed onto the dem
        // in a seperate thread
        FeatureLoader fl = new FeatureLoader( request, this );
        fl.start();
        
        Debug.debugMethodEnd();
    }       

    /**
     * creates a <tt>ViewPoint</tt> from a <tt>WTSGetViewRequest</tt>
     */
    private static ViewPoint createViewPoint(WTSGetViewRequest request) {
        Debug.debugMethodBegin("WTSService_Impl", "handleGetView");

        GM_Position poi = request.getPointOfInterest();
        Point3d poi_ = new Point3d(poi.getX(), poi.getY(), poi.getZ());

        ViewPoint vp = new ViewPoint_Impl(request.getYAW(), request.getPitch(), 
                                          request.getDistance(), poi_, 
                                          request.getAOV());

        Debug.debugMethodEnd();
        return vp;
    }

    /**
     * receives the results from the service calls and fills the texture and
     * tiles matrices
     * @param result result of a service call
     */
    public synchronized void write(Object result) {
        Debug.debugMethodBegin(this, "write");

        count--;

        if (result instanceof String) {
            handleException((String) result);
        } else {
            OGCWebServiceResponse response = null;

            if (result instanceof OGCWebServiceEvent) {
                response = ((OGCWebServiceEvent) result).getResponse();
            } else {
                response = (OGCWebServiceResponse) result;
            }

            Document doc = response.getException();

            if (doc == null) {
                try {
                    if (response instanceof WCSGetCoverageResponse) {
                        // handle WCS response; could be dem or texture
                        handleWCSResponse((WCSGetCoverageResponse) response);
                    } else if (response instanceof WFSGetFeatureResponse) {
                        // handle WFS response; could be dem or feature superimpose
                        // on the dem
                        handleWFSResponse((WFSGetFeatureResponse) response);
                    } else if (response instanceof WMSGetMapResponse) {
                        // handle WMS response; could onl be texture
                        handleWMSResponse((WMSGetMapResponse) response);
                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            } else {
                handleException(doc);
            }
        }

        // if count == 0 all sub-requests has been performed
        if (count == 0) {
            forceGetViewResponseToClient();
        }

        Debug.debugMethodEnd();
    }

    /**
     * handles the case when the result returned to the <tt>WTService</tt> through
     * the write-method contains a error message string
     * @param error error message
     */
    private void handleException(String error) {
        Debug.debugMethodBegin(this, "handleException(String)");
        Debug.debugMethodEnd();
    }

    /**
     * handles the case when the result returned to the <tt>WTService</tt> through
     * the write-method contains a error message DOM object
     * @param error error message containing Document
     */
    private void handleException(Document error) {
        Debug.debugMethodBegin(this, "handleException(Document)");        
        Debug.debugMethodEnd();
    }

    /**
     * handles the response(s) from a WCS
     *
     * @param response response to a GetCoverage request
     */
    private void handleWCSResponse(WCSGetCoverageResponse response) throws Exception {
        Debug.debugMethodBegin(this, "handleWCSResponse");

        WCSGetCoverageRequest req = (WCSGetCoverageRequest) response.getRequest();
        String id = req.getId();
        // extracs the index position of the result from its ID
        int[] index = getIndexFromId(id);

        if (req.getFormat().equalsIgnoreCase("IMG")) {
            // it's a dem tile            
            ByteArrayInputStream bis = new ByteArrayInputStream(response.getResponse());
            ObjectInputStream ois = new ObjectInputStream(bis);            
            float[][] values = (float[][]) ois.readObject();
           
            if ( values.length > 0 && values[0].length > 0) {
                Converter converter = new Converter();
                Geometry geom = converter.convertToArray(values, true, boxes[index[0]][index[1]], 
                                                         (float)((WTSGetViewRequest)request).getScale() );
                Shape3D shape = new Shape3D();
                shape.setCapability(Shape3D.ALLOW_GEOMETRY_WRITE);
                shape.setGeometry(geom);
                demTiles[index[0]][index[1]] = shape;
            } else {
                demTiles[index[0]][index[1]] = null;
            }
        } else if (req.getFormat().equalsIgnoreCase("GIF") || 
                   req.getFormat().equalsIgnoreCase("PNG") || 
                   req.getFormat().equalsIgnoreCase("JPG") || 
                   req.getFormat().equalsIgnoreCase("JPEG") || 
                   req.getFormat().equalsIgnoreCase("TIF") || 
                   req.getFormat().equalsIgnoreCase("TIFF") || 
                   req.getFormat().equalsIgnoreCase("BMP")) {
            // it's a texture tile
            try {
                SeekableStream sst = new ByteArraySeekableStream(response.getResponse());
                RenderedOp rop = JAI.create("stream", sst);                
                textureTiles[index[0]][index[1]][index[2]] = rop.getAsBufferedImage();                
                sst.close();     
            } catch(Exception e) {
                textureTiles[index[0]][index[1]][index[2]] = new BufferedImage( 2,2,BufferedImage.TYPE_INT_ARGB );
                System.out.println(e);	
            }
        }

        Debug.debugMethodEnd();
    }
    
    /**
     * handles the response(s) from a WFS
     *
     * @param response response to a GetFeature request
     */
    private void handleWFSResponse(WFSGetFeatureResponse response) throws Exception {
        Debug.debugMethodBegin(this, "handleWFSResponse");
        
        double scale = ((WTSGetViewRequest)request).getScale();
        
        if ( response.getException() != null ) {
            handleException( response.getException() );            
        } else {
            Object o = response.getResponse();
            WTSConfiguration conf = WTSConfiguration_Impl.getInstance();
            double x = 0;
            double y = 0;
            double width = 0;
            double depth = 0;
            double height = 0;
            double direction = 0;
            double baseHeight = 0;
            if ( o instanceof GMLFeatureCollection ) {
                GMLFeatureCollection gmlFc = (GMLFeatureCollection)o;
                GMLFeature[] feat = gmlFc.getFeatures();                
                for (int i = 0; i < feat.length; i++) {
                   GMLProperty prop = feat[i].getProperty( "TAB_BUILDING.X" );
                   x = Double.parseDouble( prop.getPropertyValue().toString() );
                   prop = feat[i].getProperty( "TAB_BUILDING.Y" );
                   y = Double.parseDouble( prop.getPropertyValue().toString() );
                   prop = feat[i].getProperty( "TAB_BUILDING.WIDTH" );
                   width = Double.parseDouble( prop.getPropertyValue().toString() );
                   prop = feat[i].getProperty( "TAB_BUILDING.DEPTH" );
                   depth = Double.parseDouble( prop.getPropertyValue().toString() );
                   prop = feat[i].getProperty( "TAB_BUILDING.HEIGHT" );
                   height = Double.parseDouble( prop.getPropertyValue().toString() );
                   prop = feat[i].getProperty( "TAB_BUILDING.DIRECTION" );
                   direction = Double.parseDouble( prop.getPropertyValue().toString() );
                   prop = feat[i].getProperty( "TAB_BUILDING.BASE_HEIGHT" );
                   baseHeight = Double.parseDouble( prop.getPropertyValue().toString() );
                   prop = feat[i].getProperty( "TAB_BUILDING.NAME" );
                   String name = prop.getPropertyValue().toString();
                   prop = feat[i].getProperty( "TAB_BUILDING.TEXTURE" );
                   String textureSource = prop.getPropertyValue().toString();
                   BufferedImage bi= conf.getFeatureTexture( textureSource );
                   if ( bi == null ) {
                       bi= conf.getFeatureTexture( "DEFAULT" );
                   }
                   Group block = new Block((int)-x, (int)y, (int)width/2, (int)depth/2,  
                                           (int)(baseHeight*scale), (int)(height*scale),
                                           (int)direction, bi ); 
                   feature.add( block );
                }
            } else {
                FeatureCollection fc = (FeatureCollection)o;
            }
        }
        
        Debug.debugMethodEnd();
    }

    /**
     * handles the response(s) from a WMS
     *
     * @param response response to a GetMap request
     */
    private void handleWMSResponse(WMSGetMapResponse response) {
        Debug.debugMethodBegin(this, "handleWMSResponse");
        Debug.debugMethodEnd();
    }

    /**
     *
     *
     * @param id 
     *
     * @return 
     */
    private int[] getIndexFromId(String id) {
        StringTokenizer st = new StringTokenizer(id, "-");
        int[] res = new int[st.countTokens()];
        for (int i = 0; i < res.length; i++) {
            res[i] = Integer.parseInt(st.nextToken());
        }        
        return res;
    }

    /**
     * creates a response object and calls the write-method of the 
     * <tt>OGCWebServiceClient</tt> that is registered as receiver of the 
     * WTS-request.
     */
    private void forceGetViewResponseToClient() {
        Debug.debugMethodBegin( this, "forceResponseToClient") ;
        
        WTSGetViewRequest req = (WTSGetViewRequest)request;
        OGCWebServiceResponse response = null;    
        try {

            ArrayList list = new ArrayList( 100 );
            // assign appearence/texture to the shapes
            for (int i = 0; i < boxes.length; i++) {
                for (int j = 0; j < boxes[0].length; j++) {
                    if (  demTiles[i][j] != null ) {
                        if ( textureTiles.length > 1 ) {
                            if ( textureTiles[0][i][j] != null ) {
                                Graphics g = ((BufferedImage)textureTiles[0][i][j]).getGraphics();
                                for (int k = 1; k < textureTiles.length; k++) {
                                    if ( textureTiles[k][i][j] != null ) {
                                        g.drawImage( (BufferedImage)textureTiles[k][i][j], 0, 0, null );
                                    }
                                }
                                g.dispose();
                            } else {
                                textureTiles[0][i][j] = new BufferedImage( 2, 2, BufferedImage.TYPE_INT_ARGB );
                            }
                        }

                        Appearance app = createAppearance( (BufferedImage)textureTiles[0][i][j] );
                        ((Shape3D)demTiles[i][j]).setAppearance( app );
                        list.add( (Shape3D)demTiles[i][j] );
                        demTiles[i][j] = null;
                        for (int k = 0; k < textureTiles.length; k++) {
                            //textureTiles[k][i][j] = null;
                        }
                    }
                }
            }

            Shape3D[] shapes = (Shape3D[])list.toArray( new Shape3D[list.size()] );
            Group[] blocks = (Group[])feature.toArray( new Group[ feature.size() ] );

            ViewPoint vp = createViewPoint( req );
                        
            // create 3D scene            
            WTSScene scene = WTSFactory.createWTSScene( shapes, blocks, vp, 
                                                        req.getDate(), null, 
                                                        null, req.getBackground() );

            if ( renderer == null ) {
                renderer = new OffScreenWTSRenderer( scene );
            }           

            renderer.setWidth( req.getWidth() );
            renderer.setHeight( req.getHeight() );
            renderer.setScene(scene); 
            BufferedImage image = (BufferedImage)renderer.renderScene();
            //renderer = null; 

            // create response object with rendered scene
            response = 
                WTSProtocolFactory.createGetViewResponse( image, req );
            System.gc();
        } catch(Exception e) {
System.out.println(e);            
            // create response object with error message
            OGCWebServiceException exc = 
                new OGCWebServiceException_Impl( this.getClass().getName(), e.toString() );
            response = 
                WTSProtocolFactory.createGetViewResponse( ((Marshallable)exc).exportAsXML(), req );            
        }
        
        // create event and write it back to the client
        OGCWebServiceEvent event = new OGCWebServiceEvent_Impl( this, response, "" );
        client.write( event );
        
        Debug.debugMethodEnd();
    }
    
    /**
     * creates the appearence for the scenes material/dem
     */
    private Appearance createAppearance(BufferedImage image) {
        Material material = new Material();

        Color3f white = new Color3f(0.7f, 0.7f, 0.7f );

        //The Material object defines the appearance of an object under illumination. 
        //If the Material object in an Appearance object is null, lighting is disabled for all nodes 
        //  that use that Appearance object.         
        material.setAmbientColor(white);
        material.setDiffuseColor(white);
        material.setSpecularColor(white);
        material.setShininess(1f);
        material.setLightingEnable(true);
        material.setEmissiveColor( 0.2f, 0.2f, 0.2f );
        
        Texture texture = new com.sun.j3d.utils.image.TextureLoader( image ).getTexture();
        
        //The Appearance object defines all rendering state that can be set as a component object of a Shape3D node. 
        Appearance app = new Appearance();
        app.setTexture( texture );
        app.setMaterial( material );        
        //ALLOW_TEXTURE_WRITE: Specifies that this Appearance object allows writing its texture component information.
        app.setCapability( Appearance.ALLOW_TEXTURE_WRITE );
        //TextureAttributes object defines attributes that apply to texture mapping.
        TextureAttributes texAttr = new TextureAttributes();
        //MODULATE: Modulate the object color with the texture color.
        texAttr.setTextureMode(TextureAttributes.MODULATE);
        app.setTextureAttributes(texAttr);                
        
        PolygonAttributes pa = new PolygonAttributes();
        pa.setBackFaceNormalFlip(true);
        //pa.setPolygonMode( PolygonAttributes.POLYGON_LINE );
        app.setPolygonAttributes( pa );
        
        return app; 
    }    

    
    ///////////////////////////////////////////////////////////////////////////
    //                            inner classes                              //
    ///////////////////////////////////////////////////////////////////////////

    /**
     * private inner class for calculating and splitting a views footprint into
     * boxes and/or stripes
     */
    private class Splitter implements OGCWebServiceClient {

        private ViewPoint vp    = null;
        private double heightOverGround = -9999;
        private double observerHeight = 0;
        private WTSGetViewRequest request = null;

        /** Creates a new instance of MakeStripes */
        public Splitter(WTSGetViewRequest request, ViewPoint vp) throws Exception {            
            this.request = request;
            this.vp = vp;            
            Point3d ob = vp.getObserverPosition();
            observerHeight = ob.y;
            
            // create and perform a request against the service that provides 
            // the DEM to determine to observers height above ground
            GeometryFactory fact = new GeometryFactory();
            GM_Envelope bbox = fact.createGM_Envelope( ob.x-2, ob.z-2, ob.x+2, ob.z+2 );
            WTSConfiguration conf = WTSConfiguration_Impl.getInstance();
            String layer = request.getElevationModels()[0];        
            WCSGetCoverageRequest wcsReq = WCSProtocolFactory.createWCSGetCoverageRequest(
                                                   "1.0.0", this.toString(), null, layer, 
                                                   request.getSrs(), request.getSrs(), 
                                                   bbox, null,
                                                   4, 4, -1, conf.getFormatName(layer), null, 
                                                   "application/vnd.ogc.se_xml");
            OGCWebServiceEvent event = new OGCWebServiceEvent_Impl(this, wcsReq, "", this);
            conf.getResponsibleService(layer).doService(event);
        }        
        
        /**
         * will be called by to WCService with the response to determine the 
         * observers height above ground
         */
        public void write(Object result) {

            try {
                if (result instanceof String) {
                    handleException((String) result);
                } else {
                    OGCWebServiceResponse response = null;

                    if (result instanceof OGCWebServiceEvent) {
                        response = ((OGCWebServiceEvent) result).getResponse();
                    } else {
                        response = (OGCWebServiceResponse) result;
                    }

                    Document doc = response.getException();

                    if (doc == null) {

                        if (response instanceof WCSGetCoverageResponse) {
                            handleWCSResponse((WCSGetCoverageResponse) response);
                        }  else if (response instanceof WFSGetFeatureResponse) {
                            // TODO
                            //handleWFSResponse((WFSGetFeatureResponse) response);
                        }
                    } else {
                        handleException(doc);
                    }
                }
            } catch(Exception e) {
                System.out.println(e);	
            }
        }
        
        private void handleWCSResponse(WCSGetCoverageResponse response) throws Exception {
            ByteArrayInputStream bis = new ByteArrayInputStream(response.getResponse());
            ObjectInputStream ois = new ObjectInputStream(bis);
            float[][] mat = (float[][]) ois.readObject();
            if ( mat != null && mat.length > 1 ) {
                double sum = 0;
                for (int i = 0; i < mat.length; i++) {
                    for (int j = 0; j < mat[0].length; j++) {
                        sum += mat[i][j];
                    }
                }
                sum = (sum/(double)(mat.length*mat[0].length));   
                heightOverGround = observerHeight-sum;
            } else heightOverGround = 50;
            while ( heightOverGround < 2 ) heightOverGround += 2;
System.out.println("heightOverGround: " + heightOverGround);            
        }
        
        
        /**
         * tiles the footprint trapez into count pralell stripes with an identical
         * view angle from the viewers position
         */
        public GM_Surface[] makeStripes(int count) throws InvalidArcException, GM_Exception, Exception {
            
            // wait until the observers height over ground has been determind
            int time = 0;
            while (heightOverGround < -99) {
                try {
                    Thread.sleep( 20 );
                } catch(Exception e) {
                    System.out.println(e);	
                }
                time += 20;
                if ( time > 5000 ) {
                    throw new Exception("couldn't determine obeserver's height above ground" );
                }
            }

            double maxDist = -15000;
            
            Point3d[] footprint = vp.getFootprint();
            ArrayList surfaces = new ArrayList();
            
            double height = heightOverGround;            
            
            GeometryFactory fac = new GeometryFactory();
            double maxdir = vp.getVDirection()+vp.getAoV()/2f;
            double mindir = vp.getVDirection()-vp.getAoV()/2f;           
            mindir *= 1.0;
            // calc maximum upper angle of view
            if ( maxdir > 0 ) maxdir = Math.toRadians(-0.01);
            while ( calcDist( height, maxdir ) < maxDist ) {
                double tmp = Math.toDegrees( maxdir );
                tmp -= -0.02;
                maxdir = Math.toRadians( tmp );
            }            
            // calculate delta direction (angle)
            double ddir = Math.abs(maxdir-mindir)/(double)count;            
            double mDist = calcDist( height, mindir )*0.9;
            double dDist = calcDist( height, mindir+ddir ) - mDist;  
            double dist = mDist;
            
            // start claculating stripes by adding delta directions to the
            // starting minimum angle until the maximum angle resp. the 
            // corresponding maximum distance is reached
            ConvenienceCSFactory csF = ConvenienceCSFactory.getInstance();
            CoordinateSystem crs = csF.getCSByName( request.getSrs() );
            CS_CoordinateSystem cs = Adapters.getDefault().export( crs );
            while ( dist > maxDist ) {   
                footprint = calcFootprint(height, dist+dDist, dist );
                dist += dDist;
                dDist *= 2;
                GM_Position[] pos = new GM_Position[5];
                pos[0] = fac.createGM_Position(footprint[0].x,footprint[0].z);
                pos[1] = fac.createGM_Position(footprint[1].x,footprint[1].z);
                pos[2] = fac.createGM_Position(footprint[3].x,footprint[3].z);
                pos[3] = fac.createGM_Position(footprint[2].x,footprint[2].z);                
                pos[4] = fac.createGM_Position(footprint[0].x,footprint[0].z);                
                surfaces.add( fac.createGM_Surface( pos, null, null, cs ) );
            } 
            footprint = calcFootprint(height, maxDist, dist );
            GM_Position[] pos = new GM_Position[5];
            pos[0] = fac.createGM_Position(footprint[0].x,footprint[0].z);
            pos[1] = fac.createGM_Position(footprint[1].x,footprint[1].z);
            pos[2] = fac.createGM_Position(footprint[3].x,footprint[3].z);
            pos[3] = fac.createGM_Position(footprint[2].x,footprint[2].z);                
            pos[4] = fac.createGM_Position(footprint[0].x,footprint[0].z);            
            surfaces.add( fac.createGM_Surface( pos, null, null, cs ) );

            return (GM_Surface[])surfaces.toArray( new GM_Surface[surfaces.size()] );
        }
        
        /**
         * calculates footprint
         */
        private Point3d[] calcFootprint(double height, double b1, double b2) {

            Point3d observerPosition = vp.getObserverPosition();

            Point3d[] fp = new Point3d[4];

            double h = height;
                                    
            // calc corners of the footprint back border
            double l = Math.sqrt( h*h + b1*b1 );
            double bc = Math.tan( vp.getAoV()/2 ) * l;
            bc *= 1.09;
            fp[0] = new Point3d( bc, 0, -b1 );
            fp[1] = new Point3d( -bc, 0, -b1 );
            
            // calc corners of the footprint front border
            l = Math.sqrt( h*h + b2*b2 );
            double fc = Math.tan( vp.getAoV()/2 ) * l;
            fc *= 1.09;
            fp[2] = new Point3d( fc, 0, -b2 );
            fp[3] = new Point3d( -fc, 0, -b2 );

            Transform3D rotTransform = new Transform3D();
            rotTransform.rotY( vp.getHDirection() );
            Transform3D translatTransform = new Transform3D();        
            Vector3d vec = new Vector3d( observerPosition.x, observerPosition.y - height, observerPosition.z );
            translatTransform.setTranslation( vec );

            for (int i = 0; i < fp.length; i++) {                
                rotTransform.transform( fp[i] );
                translatTransform.transform( fp[i] );
            }                

            return fp;
        }
        
        private double calcDist(double height, double dir) {
            double dist = height / Math.tan(dir);
            return dist;
        }

        /**
         * tiles a stripe into count boxes
         */
        public GM_Surface[] makeBoxes(GM_Surface stripe, int count) throws GM_Exception {

            GeometryFactory fac = new GeometryFactory();
            GM_Surface[] surfaces = new GM_Surface[count];

            GM_Position[] pos = stripe.getSurfacePatchAt(0).getExteriorRing();

            double m = (pos[1].getY()-pos[0].getY())/(pos[1].getX()-pos[0].getX());
            double b1 = pos[1].getY() - m * pos[1].getX();
            double b2 = pos[2].getY() - m * pos[2].getX();

            double tmp1 = (pos[1].getX()-pos[0].getX())/(double)count;
            double tmp2 = (pos[2].getX()-pos[3].getX())/(double)count;

            GM_Position[] box = new GM_Position[5];

            for (int i = 0; i < count; i++) {
                box = new GM_Position[5];
                double x1 = pos[0].getX() + (tmp1*i);
                double y1 = m * x1 + b1;
                box[0] = fac.createGM_Position( x1, y1 );

                x1 = pos[0].getX() + tmp1 * (i+1);
                y1 = m * x1 + b1;
                box[1] = fac.createGM_Position( x1, y1 );

                x1 = pos[3].getX() + tmp2*i;
                y1 = m * x1 + b2;
                box[3] = fac.createGM_Position( x1, y1 );

                x1 = pos[3].getX() + tmp2*(i+1);
                y1 = m * x1 + b2;
                box[2] = fac.createGM_Position( x1, y1 );
                box[4] = box[0];

                ConvenienceCSFactory csF = ConvenienceCSFactory.getInstance();
                CoordinateSystem crs = csF.getCSByName( request.getSrs() );
                CS_CoordinateSystem cs = Adapters.getDefault().export( crs );
                surfaces[i] = fac.createGM_Surface( box, null, null, cs );
            }

            return surfaces;
        }
        
    }
    
    /**
     * loader for DEM in a seperat thread
     */
    private class DEMLoader extends Thread {
        
        private WTSGetViewRequest request = null;
        private OGCWebServiceClient parent = null;
        
        DEMLoader(WTSGetViewRequest request, OGCWebServiceClient parent) {
            this.request = request;
            this.parent = parent;
        }
        
        public void run() {
           try {
                WTSConfiguration conf = WTSConfiguration_Impl.getInstance();
                // create and perform dem requests
                for (int i = 0; i < boxes.length; i++) {
                    for (int j = 0; j < boxes[0].length; j++) {
                        String layer = request.getElevationModels()[0];        
                        int sx = (int)boxes[i][j].getEnvelope().getWidth()/1;
                        int sy = (int)boxes[i][j].getEnvelope().getHeight()/1;
                        while (sx > 40 ) sx /= 2;                
                        if ( sx < 3 ) sx = 3;                
                        while (sy > 30 ) sy /= 2;
                        if ( sy < 3 ) sy = 3;
                        WCSGetCoverageRequest wcsReq = WCSProtocolFactory.createWCSGetCoverageRequest(
                                                               "1.0.0", i + "-" + j, null, layer,  
                                                               request.getSrs(), request.getSrs(), 
                                                               boxes[i][j].getEnvelope(), null,
                                                               sx, sy, -1, conf.getFormatName( layer ), null, 
                                                               request.getExceptions() );

                        OGCWebServiceEvent event = new OGCWebServiceEvent_Impl(this, wcsReq, "", parent);
                        WCService_Impl service = (WCService_Impl)conf.getResponsibleService(layer);
                        service = (WCService_Impl)service.clone();
                        service.doService(event);
                    }
                }            
            } catch(Exception e) {
                System.out.println(e);	
            }
        }
    }
    
    /**
     * loader for textures in a seperat thread
     */
    private class TextureLoader extends Thread {
        
        private WTSGetViewRequest request = null;
        private OGCWebServiceClient parent = null;        
        private int layerId = 0;
        
        TextureLoader(WTSGetViewRequest request, int layerId, OGCWebServiceClient parent) {
            this.request = request;
            this.parent = parent;            
            this.layerId = layerId;
        }
        
        public void run() {
           try {
                WTSConfiguration conf = WTSConfiguration_Impl.getInstance();
                for (int i = 0; i < boxes.length; i++) {
                    for (int j = 0; j < boxes[0].length; j++) {
                        WTSGetViewRequest.Layer layer = request.getLayers()[layerId];
                        WCSGetCoverageRequest wcsReq = WCSProtocolFactory.createWCSGetCoverageRequest(
                                                       "1.0.0", layerId + "-" + i + "-" + j, null, layer.getName(), 
                                                       request.getSrs(), request.getSrs(), 
                                                       boxes[i][j].getEnvelope(), null, 
                                                       conf.getTileWidth(layer.getName()), 
                                                       conf.getTileHeight(layer.getName()),                                                        
                                                       -1, conf.getFormatName(layer.getName()), null, 
                                                       "application/vnd.ogc.se_xml");                  
                        OGCWebServiceEvent event = new OGCWebServiceEvent_Impl(this, wcsReq, "", parent);
                        conf.getResponsibleService(layer.getName()).doService(event);
                    }
                }
            } catch(Exception e) {
                System.out.println(e);	
            }
        }
    }
    
    /**
     * loader for feature in a seperat thread
     */
    private class FeatureLoader extends Thread {
        
        private WTSGetViewRequest request = null;
        private OGCWebServiceClient parent = null;
        
        FeatureLoader(WTSGetViewRequest request, OGCWebServiceClient parent) {
            this.request = request;
            this.parent = parent;
        }
        
        public void run() {
           try {
                WTSConfiguration conf = WTSConfiguration_Impl.getInstance();
                if ( request.getFeatureCollections() != null && 
                     request.getFeatureCollections().length > 0 ) {
                    String feat = request.getFeatureCollections()[0].getName();                
                    StringBuffer sb = new StringBuffer();
                    sb.append( "<wfs:GetFeature outputFormat=\"GML2\" ");
                    sb.append( "xmlns:gml=\"http://www.opengis.net/gml\" " );
                    sb.append( "xmlns:wfs=\"http://www.opengis.net/namespaces/wfs\" >" );
                    sb.append( "<wfs:Query typeName=\"" + feat + "\">" );
                    sb.append( "</wfs:Query>" );
                    sb.append( "</wfs:GetFeature>" );     
                    StringReader sr = new StringReader( sb.toString() );
                    OGCWebServiceRequest wfsReq = WFSProtocolFactory.createRequest(this.toString(), sr);
                    sr.close();
                    OGCWebServiceEvent event = new OGCWebServiceEvent_Impl(this, wfsReq, "", parent);
                    conf.getResponsibleService(feat).doService(event);             
                }
            } catch(Exception e) {
                System.out.println(e);	
            }
        }
    }
    
}