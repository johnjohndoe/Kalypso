/*----------------    FILE HEADER  ------------------------------------------
 
This file is part of deegree.
Copyright (C) 2001 by:
EXSE, Department of Geography, University of Bonn
http://www.giub.uni-bonn.de/exse/
lat/lon Fitzke/Fretter/Poth GbR
http://www.lat-lon.de
 
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.
 
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
 
You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
Contact:
 
Andreas Poth
lat/lon Fitzke/Fretter/Poth GbR
Meckenheimer Allee 176
53115 Bonn
Germany
E-Mail: poth@lat-lon.de
 
Jens Fitzke
Department of Geography
University of Bonn
Meckenheimer Allee 166
53115 Bonn
Germany
E-Mail: jens.fitzke@uni-bonn.de
 
 
 ---------------------------------------------------------------------------*/
package org.deegree_impl.services.wts;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.media.j3d.Material;
import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;
import javax.vecmath.Color3f;

import org.deegree.graphics.sld.StyledLayerDescriptor;
import org.deegree.model.geometry.GM_Surface;
import org.deegree.services.wfs.filterencoding.Filter;
import org.deegree.services.wts.TextureLoader;

import com.sun.media.jai.codec.FileSeekableStream;


/**
 * enables the loading of textures (<tt>Appearance</tt>s) from image files
 * (JPEG, PNG, BMP, TIFF, GIF).
 * <p>----------------------------------------------------------------------</p>
 * @author  Andreas Poth
 * @version 1.1.2003
 */
public class FileTextureLoader implements TextureLoader {
    
    private Material material = null;
    
    /** Creates a new instance of FileTextureLoader  with default material */
    public FileTextureLoader() {
        material = new Material();
        
        Color3f white = new Color3f(0.7f, 0.7f, 0.7f );
        
        //The Material object defines the appearance of an object under illumination. 
        //If the Material object in an Appearance object is null, lighting is disabled for all nodes 
        //  that use that Appearance object.         
        material.setAmbientColor(white);
        material.setDiffuseColor(white);
        material.setSpecularColor(white);
        material.setShininess(1f);
        material.setLightingEnable(true);
    }
    
    /** Creates a new instance of FileTextureLoader user defined material */
    public FileTextureLoader(Material material) {
        this.material = material;
    }
    
    /** returns the Textures (<tt>Texture</tt>s) are identified by the submitted
     * filter expression. 
     *
     */
    public BufferedImage[] loadTextures(String name, Filter filter) throws IOException {
        
        BufferedImage[] bi = new BufferedImage[1];
        
        FileSeekableStream fss = new FileSeekableStream( name );         
        RenderedOp ro = JAI.create( "stream", fss );
        bi[0] = ro.getAsBufferedImage();
        fss.close();
        
        return bi; 
    }
    
    /** returns the Textures (<tt>Texture</tt>s) thats x/y coordinates are contained
     * within the submitted <tt>GM_Surface</tt>. 
     *
     */
    public BufferedImage[] loadTextures(String name, GM_Surface ring) throws IOException {
        return null;
    }
    
    /** returns the Textures (<tt>Texture</tt>s) are identified by the submitted
     * <tt>StyledLayerDescriptor</tt>
     *
     */
    public BufferedImage[] loadTextures(StyledLayerDescriptor sld) throws IOException {
        return null;
    }    
    
}
