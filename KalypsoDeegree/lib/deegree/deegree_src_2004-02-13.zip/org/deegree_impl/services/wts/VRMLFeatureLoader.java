/*----------------    FILE HEADER  ------------------------------------------
 
This file is part of deegree.
Copyright (C) 2001 by:
EXSE, Department of Geography, University of Bonn
http://www.giub.uni-bonn.de/exse/
lat/lon Fitzke/Fretter/Poth GbR
http://www.lat-lon.de
 
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.
 
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
 
You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
Contact:
 
Andreas Poth
lat/lon Fitzke/Fretter/Poth GbR
Meckenheimer Allee 176
53115 Bonn
Germany
E-Mail: poth@lat-lon.de
 
Jens Fitzke
Department of Geography
University of Bonn
Meckenheimer Allee 166
53115 Bonn
Germany
E-Mail: jens.fitzke@uni-bonn.de
 
 
 ---------------------------------------------------------------------------*/

package org.deegree_impl.services.wts;

import java.io.IOException;

import javax.media.j3d.Group;

import org.deegree.graphics.sld.StyledLayerDescriptor;
import org.deegree.model.geometry.GM_Surface;
import org.deegree.services.wfs.filterencoding.Filter;

/**
 *
 * @author  katharina
 */
public class VRMLFeatureLoader implements org.deegree.services.wts.FeatureLoader {
    
    /** Creates a new instance of FeatureLoader_Impl */
    public VRMLFeatureLoader() {       
    }
    
    /** returns the features (<tt>Shape3D</tt>s) are identified by the submitted
     * filter expression. the filter expression identifies the features
     * geometries as well as their texture (appearance).
     *
     */
    public Group[] loadFeatures(Filter filter) throws IOException {
        return null;
    }
    
    /** returns the features (<tt>Shape3D</tt>s) are identified by the submitted
     * <tt>StyledLayerDescriptor</tt>
     *
     */
    public Group[] loadFeatures(StyledLayerDescriptor sld) throws IOException {
        return null;
    }
    
    /** returns the features (<tt>Shape3D</tt>s) thats x/y coordinates are contained
     * within the submitted <tt>GM_Surface</tt>. the ring identifies the features
     * geometries as well as their texture (appearance).
     *
     */
    public Group[] loadFeatures(GM_Surface ring) throws IOException {
        return null;
    }    
}
