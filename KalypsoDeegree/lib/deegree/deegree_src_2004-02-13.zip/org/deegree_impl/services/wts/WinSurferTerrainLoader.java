/*----------------    FILE HEADER  ------------------------------------------
 
This file is part of deegree.
Copyright (C) 2001 by:
EXSE, Department of Geography, University of Bonn
http://www.giub.uni-bonn.de/exse/
lat/lon Fitzke/Fretter/Poth GbR
http://www.lat-lon.de
 
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.
 
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
 
You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
Contact:
 
Andreas Poth
lat/lon Fitzke/Fretter/Poth GbR
Meckenheimer Allee 176
53115 Bonn
Germany
E-Mail: poth@lat-lon.de
 
Jens Fitzke
Department of Geography
University of Bonn
Meckenheimer Allee 166
53115 Bonn
Germany
E-Mail: jens.fitzke@uni-bonn.de
 
 
 ---------------------------------------------------------------------------*/
package org.deegree_impl.services.wts;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.ArrayList;

import javax.media.j3d.Geometry;
import javax.media.j3d.TriangleArray;
import javax.media.j3d.GeometryArray;
import javax.vecmath.*;

import org.deegree.services.wts.TerrainLoader;
import org.deegree.model.geometry.GM_Surface;
import org.deegree.model.geometry.GM_Position;
import org.deegree_impl.model.geometry.GeometryFactory;
import org.deegree_impl.tools.*;


/**
 * class for loading terrain data from a WinSurfer GRD-export file.
 * <p>----------------------------------------------------------------------</p>
 * @author  Andreas Poth
 * @version 1.1.2003
 */
public class WinSurferTerrainLoader implements TerrainLoader {
        
    private GeometryFactory factory = null;
    
    /** Creates a new instance of TerrainLoader_Impl */
    public WinSurferTerrainLoader() {
        factory = new GeometryFactory();
    }
    
    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name. the minimum possible scale will be loaded. the usage of texture
     * isn't enabled
     *
     */ 
    public Geometry loadTerrain(String name, GM_Surface ring) throws IOException {
        return loadTerrain( name, ring, 1, false);        
    }
    
    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name. the minimum possible scale will be loaded. the usage of texture is
     * set by the submitted boolean parameter
     *
     */
    public Geometry loadTerrain(String name, GM_Surface ring, boolean enableTexture) throws IOException {
        return loadTerrain( name, ring, 1, enableTexture);        
    }
    
    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name with the defined scale. the usage of texture isn't enabled
     *
     */
    public Geometry loadTerrain(String name, GM_Surface ring, double scale) throws IOException {
        return loadTerrain( name, ring, scale, false);  
    }
    
    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name with the defined scale. the usage of texture is set by the submitted
     * boolean parameter
     *
     */
    public Geometry loadTerrain(String name, GM_Surface ring, double scale, boolean enableTexture) throws IOException {
        
        Debug.debugMethodBegin( this,  "loadTerrain" );
        
        // creates the BufferedReader for reading the string with the data
        BufferedReader bf = new BufferedReader(new FileReader(name));
        String grid = null;
        StringBuffer sb = new StringBuffer();
        while ((grid= bf.readLine()) != null ){
            sb.append(grid + " ");
        }
        String coord = sb.toString();
        bf.close();
                
        StringTokenizer st = new StringTokenizer(coord, " ");
        
        // reads the particular data
        int t = st.countTokens();
        String title = st.nextToken();
        int cols = Integer.parseInt(st.nextToken());
        int rows = Integer.parseInt(st.nextToken());
        float[][] mat = new float[rows][cols];
        float xmin = Float.parseFloat(st.nextToken());
        float xmax = Float.parseFloat(st.nextToken());
        float ymin = Float.parseFloat(st.nextToken());
        float ymax = Float.parseFloat(st.nextToken());
        float zmin = Float.parseFloat(st.nextToken());
        float zmax = Float.parseFloat(st.nextToken());

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                GM_Position position = getPosition( r, c, rows, cols, xmin, ymin, xmax, ymax );

                float d = Float.parseFloat( st.nextToken() );
                // scales the data
                if ( ring == null || ring.contains( position ) ) {
                    mat[r][cols-c-1] = d*(float)scale;
                } else {
                    mat[r][cols-c-1] = (float)-9E9;
                }
            }
        }
        
        Geometry geom = convertToArray( mat, rows, cols, xmin, ymin, xmax, ymax, enableTexture);
        
        Debug.debugMethodEnd();
        return geom;
    }
    
    /**
     *
     */
    private GM_Position getPosition(double r, double c, double rows, double cols, 
                                    double xmin, double ymin, double xmax, double ymax )
    {
        double qx = (xmax-xmin)/cols;
        double qy = (ymax-ymin)/rows;
        double x = c * qx + xmin;
        double y = (rows - r -1) * qy + ymin;
        
        return factory.createGM_Position( x, y );
    }
    
    /**
     * Convert heightmap values to triangle array, with textures, normals and everything..
     * The TriangleArray object draws the array of vertices as individual triangles. 
     * Each group of three vertices defines a triangle to be drawn. 
     * @param values heightmap values
     * @return created array
     */
    private TriangleArray convertToArray(float[][] values, double rows, double cols, 
                                    double xmin, double ymin, double xmax, double ymax,
                                    boolean enableTexture) {
               
        Debug.debugMethodBegin( this, "convertToArray" );
        
        if (values == null) return null;
        float w = values[0].length-1;
        float h = values.length-1;
        
        TriangleArray T = null;
        if ( enableTexture ) {
            T = new TriangleArray((int)(w * h * 6), GeometryArray.COORDINATES |GeometryArray.COLOR_4 |
                                             GeometryArray.TEXTURE_COORDINATE_2 | GeometryArray.NORMALS );
        } else {
            T = new TriangleArray((int)(w * h * 6), GeometryArray.COORDINATES |GeometryArray.COLOR_4 |
                                             GeometryArray.NORMALS );
        }
        
        float coord[] = new float[3];
        float texCoord[]= new float[2];        
        int coordNr = 0, normalNr = 0;
        Point3f v1 = null, v2 = null, v3 = null;
        
        double qx = (xmax-xmin)/cols;
        double qy = (ymax-ymin)/rows;        

        ArrayList list = new ArrayList( (int)(h*w*2) );
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {               
                                
/*
                3 -- 2         6
                |  /         / |
                | /	    /  |
                1         4 -- 5
 */
                // (1)   
                if ( values[j+1][i] > -9E9 &&
                     values[j][i+1] > -9E9 &&
                     values[j][i] > -9E9 ) {
                    coord[0] = (float)(i * qx + xmin);
                    coord[2] = (float)((j +1) * qy + ymin);
                    coord[1] = values[j+1][i] ;
                    T.setCoordinate(coordNr, coord);
                    if ( enableTexture ) {
                        texCoord[0] = 1-i/w;
                        texCoord[1] = (j+1)/h;
                        T.setTextureCoordinate(0, coordNr++, texCoord);
                    }
                    v1 = new Point3f(coord);
                    // (2)
                    coord[0] = (float)((i+1) * qx + xmin);
                    coord[2] = (float)((j ) * qy + ymin);
                    coord[1] = values[j][i+1];                
                    T.setCoordinate(coordNr, coord);
                    if ( enableTexture ) {
                        texCoord[0] = 1-(i+1)/w;
                        texCoord[1] = j/h;
                        T.setTextureCoordinate(0, coordNr++, texCoord);
                    }
                    v2 = new Point3f(coord);
                    // (3)
                    coord[0] = (float)(i * qx + xmin);
                    coord[2] = (float)((j ) * qy + ymin);
                    coord[1] = values[j][i];
                    T.setCoordinate(coordNr, coord);
                    if ( enableTexture ) {
                        texCoord[0] = 1-i/w;
                        texCoord[1] = j/h;
                        T.setTextureCoordinate(0, coordNr++, texCoord);
                    }
                    v3 = new Point3f(coord);
                    // Triangle ready - calculate normal
                    list.add( findNormal(v1,v2,v3) );
                } else list.add( new String("w") );
                if ( values[j+1][i] > -9E9 &&
                     values[j+1][i+1] > -9E9 &&
                     values[j][i+1] > -9E9 ) {
                    // (4)
                    coord[0] = (float)(i * qx + xmin);
                    coord[2] = (float)((j +1) * qy + ymin);
                    coord[1] = values[j+1][i] ;
                    T.setCoordinate(coordNr, coord);
                    if ( enableTexture ) {
                        texCoord[0] = 1-i/w;
                        texCoord[1] = (j+1)/h;
                        T.setTextureCoordinate(0, coordNr++, texCoord);
                    }
                    v1 = new Point3f(coord);
                    // (5)
                    coord[0] = (float)((i+1) * qx + xmin);
                    coord[2] = (float)((j + 1) * qy + ymin);
                    coord[1] = values[j+1][i+1] ;
                    T.setCoordinate(coordNr, coord);
                    if ( enableTexture ) {
                        texCoord[0] = 1-(i+1)/w;
                        texCoord[1] = (j+1)/h;
                        T.setTextureCoordinate(0, coordNr++, texCoord);
                    }
                    v2 = new Point3f(coord);
                    // (6)
                    coord[0] = (float)((i+1) * qx + xmin);
                    coord[2] = (float)((j ) * qy + ymin);
                    coord[1] = values[j][i+1] ;
                    T.setCoordinate(coordNr, coord);
                    if ( enableTexture ) {
                        texCoord[0] = 1-(i+1)/w;
                        texCoord[1] = j/h;
                        T.setTextureCoordinate(0, coordNr++, texCoord);
                    }
                    v3 = new Point3f(coord);
                    // Triangle ready - calculate normal
                    list.add( findNormal(v1,v2,v3) );
                } else list.add( new String("w") );
            }
        }      
                
        int p1, p2, p3, p4, p5, p6;
        Vector3f n1, n2, n3, n4;
        coordNr = 0;
        list.add( new Vector3f() );
        Object normals[] = list.toArray();
        
        normalNr = normals.length-1;
        for (int j = 0; j < h; j++)
            for (int i = 0; i < w; i++) {
                
                // Normal 1                
                p1 = (int)(((j-1) * w + (i-1)) * 2);
                if (p1 < 0 || p1 >= w * h * 2) p1 = normalNr;
                
                p2 = (int)(((j-1) * w + (i-1)) * 2) + 1;
                if (p2 < 0 || p2 >= w * h * 2) p2 = normalNr;
                
                p3 = (int)(((j-1) * w + (i)) * 2);
                if (p3 < 0 || p3 >= w * h * 2) p3 = normalNr;
                
                p4 = (int)(((j) * w + (i-1)) * 2) + 1;
                if (p4 < 0 || p4 >= w * h * 2) p4 = normalNr;
                
                p5 = (int)(((j) * w + (i)) * 2);
                if (p5 < 0 || p5 >= w * h * 2) p5 = normalNr;
                
                p6 = (int)(((j) * w + (i)) * 2) + 1;
                if (p6 < 0 || p6 >= w * h * 2) p6 = normalNr;
              
                if ( !(normals[p1] instanceof String) &&
                     !(normals[p2] instanceof String) &&
                     !(normals[p3] instanceof String) &&
                     !(normals[p4] instanceof String) &&
                     !(normals[p5] instanceof String) &&
                     !(normals[p6] instanceof String) ) {
                    n1 = normalAvg( (Vector3f)normals[p1], (Vector3f)normals[p2], 
                                    (Vector3f)normals[p3], (Vector3f)normals[p4], 
                                    (Vector3f)normals[p5], (Vector3f)normals[p6]);
                } else n1 = null;
                
                // Normal 2
                p1 = (int)(((j-1) * w + (i)) * 2);
                if (p1 < 0 || p1 >= w * h * 2) p1 = normalNr;
                
                p2 = (int)(((j-1) * w + (i)) * 2) + 1;
                if (p2 < 0 || p2 >= w * h * 2) p2 = normalNr;
                
                p3 = (int)(((j-1) * w + (i+1)) * 2);
                if (p3 < 0 || p3 >= w * h * 2) p3 = normalNr;
                
                p4 = (int)(((j) * w + (i)) * 2) + 1;
                if (p4 < 0 || p4 >= w * h * 2) p4 = normalNr;
                
                p5 = (int)(((j) * w + (i+1)) * 2);
                if (p5 < 0 || p5 >= w * h * 2) p5 = normalNr;
                
                p6 = (int)(((j) * w + (i+1)) * 2) + 1;
                if (p6 < 0 || p6 >= w * h * 2) p6 = normalNr;
                
                if ( !(normals[p1] instanceof String) &&
                     !(normals[p2] instanceof String) &&
                     !(normals[p3] instanceof String) &&
                     !(normals[p4] instanceof String) &&
                     !(normals[p5] instanceof String) &&
                     !(normals[p6] instanceof String) ) {
                    n2 = normalAvg( (Vector3f)normals[p1], (Vector3f)normals[p2], 
                                    (Vector3f)normals[p3], (Vector3f)normals[p4], 
                                    (Vector3f)normals[p5], (Vector3f)normals[p6] );
                } else n2 = null;
                
                // Normal 3
                p1 = (int)(((j) * w + (i-1)) * 2);
                if (p1 < 0 || p1 >= w * h * 2) p1 = normalNr;
                
                p2 = (int)(((j) * w + (i-1)) * 2) + 1;
                if (p2 < 0 || p2 >= w * h * 2) p2 = normalNr;
                
                p3 = (int)(((j) * w + (i)) * 2);
                if (p3 < 0 || p3 >= w * h * 2) p3 = normalNr;
                
                p4 = (int)(((j+1) * w + (i-1)) * 2) + 1;
                if (p4 < 0 || p4 >= w * h * 2) p4 = normalNr;
                
                p5 = (int)(((j+1) * w + (i)) * 2);
                if (p5 < 0 || p5 >= w * h * 2) p5 = normalNr;
                
                p6 = (int)(((j+1) * w + (i)) * 2) + 1;
                if (p6 < 0 || p6 >= w * h * 2) p6 = normalNr;
                
                if ( !(normals[p1] instanceof String) &&
                     !(normals[p2] instanceof String) &&
                     !(normals[p3] instanceof String) &&
                     !(normals[p4] instanceof String) &&
                     !(normals[p5] instanceof String) &&
                     !(normals[p6] instanceof String) ) {
                    n3 = normalAvg( (Vector3f)normals[p1], (Vector3f)normals[p2], 
                                    (Vector3f)normals[p3], (Vector3f)normals[p4], 
                                    (Vector3f)normals[p5], (Vector3f)normals[p6] );
                } else n3 = null;
                
                // Normal 4
                p1 = (int)(((j) * w + (i)) * 2);
                if (p1 < 0 || p1 >= w * h * 2) p1 = normalNr;
                
                p2 = (int)(((j) * w + (i)) * 2) + 1;
                if (p2 < 0 || p2 >= w * h * 2) p2 = normalNr;
                
                p3 = (int)(((j) * w + (i+1)) * 2);
                if (p3 < 0 || p3 >= w * h * 2) p3 = normalNr;
                
                p4 = (int)(((j+1) * w + (i)) * 2) + 1;
                if (p4 < 0 || p4 >= w * h * 2) p4 = normalNr;
                
                p5 = (int)(((j+1) * w + (i+1)) * 2);
                if (p5 < 0 || p5 >= w * h * 2) p5 = normalNr;
                
                p6 = (int)(((j+1) * w + (i+1)) * 2) + 1;
                if (p6 < 0 || p6 >= w * h * 2) p6 = normalNr;
                
                if ( !(normals[p1] instanceof String) &&
                     !(normals[p2] instanceof String) &&
                     !(normals[p3] instanceof String) &&
                     !(normals[p4] instanceof String) &&
                     !(normals[p5] instanceof String) &&
                     !(normals[p6] instanceof String) ) {
                    n4 = normalAvg( (Vector3f)normals[p1], (Vector3f)normals[p2], 
                                    (Vector3f)normals[p3], (Vector3f)normals[p4], 
                                    (Vector3f)normals[p5], (Vector3f)normals[p6] );
                } else n4 = null;
                
                // Set normals   
                if (n3 != null ) T.setNormal(coordNr++, n3); 
                if (n2 != null ) T.setNormal(coordNr++, n2);
                if (n1 != null ) T.setNormal(coordNr++, n1);
                
                if (n3 != null ) T.setNormal(coordNr++, n3);
                if (n4 != null ) T.setNormal(coordNr++, n4);
                if (n2 != null ) T.setNormal(coordNr++, n2);
                
            }
        
        Debug.debugMethodEnd();
        
        return T;
    }
    
    /**
     * Computes the normal vector of three vertice.
     * Red book: normal = [v1 - v2] x [v2 - v3]
     * @param v1 1st vertex
     * @param v2 2nd vertex
     * @param v3 3rd vertex
     * @return created normal
     */
    private Vector3f findNormal(Point3f v1, Point3f v2, Point3f v3) {
        Vector3f normal = new Vector3f();
        v1.sub(v2);
        v2.sub(v3);
        normal.cross(new Vector3f(v1),new Vector3f(v2));
        return normal;
    }
    
    /**
     * Calculate the average of six normals surrounding
     * a single point.
     * @param v1, 1st normal
     * @param v2, 2nd normal
     * @param v3, 3rd normal
     * @param v4, 4th normal
     * @param v5, 5th normal
     * @param v6, 6th normal
     * @return averaged normal
     */
    private Vector3f normalAvg(Vector3f v1, Vector3f v2, Vector3f v3,
                               Vector3f v4, Vector3f v5, Vector3f v6) {
        
        Vector3f normal = new Vector3f();
        normal.add(v1);
        normal.add(v2);
        normal.add(v3);
        normal.add(v4);
        normal.add(v5);
        normal.add(v6);
        normal.normalize();
        return normal;
    }      
}
