/*----------------    FILE HEADER  ------------------------------------------
 
This file is part of deegree.
Copyright (C) 2001 by:
EXSE, Department of Geography, University of Bonn
http://www.giub.uni-bonn.de/exse/
lat/lon Fitzke/Fretter/Poth GbR
http://www.lat-lon.de
 
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.
 
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
 
You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
Contact:
 
Andreas Poth
lat/lon Fitzke/Fretter/Poth GbR
Meckenheimer Allee 176
53115 Bonn
Germany
E-Mail: poth@lat-lon.de
 
Jens Fitzke
Department of Geography
University of Bonn
Meckenheimer Allee 166
53115 Bonn
Germany
E-Mail: jens.fitzke@uni-bonn.de
 
 
 ---------------------------------------------------------------------------*/

package org.deegree_impl.services.wts;

import java.io.IOException;

import javax.media.j3d.Geometry;

import org.deegree.model.geometry.GM_Surface;
import org.deegree.services.wts.TerrainLoader;

/**
 * class for loading terrain data from ArcGrid export files 
 * <p>----------------------------------------------------------------------</p>
 * @author  Andreas Poth
 * @version 1.1.2003
 */
public class ArcGridTerrainLoader implements TerrainLoader {
    
    /** Creates a new instance of TerrainLoader_Impl */
    public ArcGridTerrainLoader() {
    }
    
    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name. the minimum possible scale will be loaded. the usage of texture
     * isn't enabled
     *
     */
    public Geometry loadTerrain(String name, GM_Surface ring) throws IOException {
        return null;
    }
    
    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name. the minimum possible scale will be loaded. the usage of texture is
     * set by the submitted boolean parameter
     *
     */
    public Geometry loadTerrain(String name, GM_Surface ring, boolean enableTexture) throws IOException {
        return null;
    }
    
    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name with the defined scale. the usage of texture isn't enabled
     *
     */
    public Geometry loadTerrain(String name, GM_Surface ring, double scale) throws IOException {
        return null;
    }
    
    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name with the defined scale. the usage of texture is set by the submitted
     * boolean parameter
     *
     */
    public Geometry loadTerrain(String name, GM_Surface ring, double scale, boolean enableTexture) throws IOException {
        return null;
    }
    
      
}
