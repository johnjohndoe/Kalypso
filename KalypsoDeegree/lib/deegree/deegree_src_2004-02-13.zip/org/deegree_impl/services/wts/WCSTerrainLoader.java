/*----------------    FILE HEADER  ------------------------------------------

This file is part of deegree.
Copyright (C) 2001 by:
EXSE, Department of Geography, University of Bonn
http://www.giub.uni-bonn.de/exse/
lat/lon Fitzke/Fretter/Poth GbR
http://www.lat-lon.de

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Contact:

Andreas Poth
lat/lon Fitzke/Fretter/Poth GbR
Meckenheimer Allee 176
53115 Bonn
Germany
E-Mail: poth@lat-lon.de

Jens Fitzke
Department of Geography
University of Bonn
Meckenheimer Allee 166
53115 Bonn
Germany
E-Mail: jens.fitzke@uni-bonn.de

                 
 ---------------------------------------------------------------------------*/
package org.deegree_impl.services.wts;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;

import javax.media.j3d.Geometry;
import javax.media.j3d.GeometryArray;
import javax.media.j3d.PointArray;

import org.deegree.model.geometry.GM_Envelope;
import org.deegree.model.geometry.GM_Surface;
import org.deegree_impl.model.geometry.GeometryFactory;
import org.deegree_impl.services.wts.util.Converter;
import org.deegree_impl.tools.Debug;
import org.opengis.cs.CS_CoordinateSystem;


/**
 *
 * @author  <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 */
public class WCSTerrainLoader implements org.deegree.services.wts.TerrainLoader {
    private GeometryFactory factory = null;
    private String format = "jpg";
    private String url = null;
    private int height = 128;
    private int width = 128;

    /** Creates a new instance of TerrainLoader_Impl */
    public WCSTerrainLoader( String baseUrl, int width, int height, String format ) {
        this.url = baseUrl;
        this.width = width;
        this.height = height;
        this.format = format;
        factory = new GeometryFactory();
    }

    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name. the minimum possible scale will be loaded. the usage of texture
     * isn't enabled
     *
     */
    public Geometry loadTerrain( String name, GM_Surface ring ) throws IOException {
        return loadTerrain( name, ring, 1, false );
    }

    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name. the minimum possible scale will be loaded. the usage of texture is
     * set by the submitted boolean parameter
     *
     */
    public Geometry loadTerrain( String name, GM_Surface ring, boolean enableTexture )
                         throws IOException {
        return loadTerrain( name, ring, 1, enableTexture );
    }

    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name with the defined scale. the usage of texture isn't enabled
     *
     */
    public Geometry loadTerrain( String name, GM_Surface ring, double scale )
                         throws IOException {
        return loadTerrain( name, ring, scale, false );
    }

    /** loads a part, not neccessary a rectangle, of a terrain identified by its
     * name with the defined scale. the usage of texture is set by the submitted
     * boolean parameter
     *
     */
    public Geometry loadTerrain( String name, GM_Surface ring, double scale, boolean enableTexture )
                         throws IOException {
        Debug.debugMethodBegin( this, "loadTerrain" );

        GM_Envelope env = ring.getEnvelope();
        float xmin = (float)env.getMin().getX();
        float xmax = (float)env.getMax().getX();
        float ymin = (float)env.getMin().getY();
        float ymax = (float)env.getMax().getY();

        CS_CoordinateSystem crs = ring.getCoordinateSystem();
        StringBuffer sb = new StringBuffer( url );
        sb.append( "&Layer=" + name );
        sb.append( "&SRS=" + crs.getName().replace( ' ', ':' ) );
        sb.append( "&BBOX=" + xmin + "," + ymin + "," + xmax + "," + ymax );
        sb.append( "&Width=" + width );
        sb.append( "&Height=" + height );
        sb.append( "&Format=" + format );
        sb.append( "&Service=WCS&version=0.7.0" );
        URL u = new URL( sb.toString() );
        BufferedInputStream bis = new BufferedInputStream( u.openStream() );
        ObjectInputStream ois = new ObjectInputStream( bis );
        float[][] mat = null;

        try {
            mat = (float[][])ois.readObject();
        } catch ( Exception e ) {
            throw new IOException( "Invalid result class exception" );
        }
//{jdk.home}{/}bin{/}javac
//
        ois.close();
        bis.close();

        Geometry geom = null;

        if ( mat.length > 0 ) {
            Converter converter = new Converter();
            geom = converter.convertToArray( mat, enableTexture, ring, (float)scale );
        } else {
            geom = new PointArray( 1, GeometryArray.COORDINATES );
        }

        Debug.debugMethodEnd();
        return geom;
    }
}