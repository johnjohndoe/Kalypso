/*----------------    FILE HEADER  ------------------------------------------
 
This file is part of deegree.
Copyright (C) 2001 by:
EXSE, Department of Geography, University of Bonn
http://www.giub.uni-bonn.de/exse/
lat/lon Fitzke/Fretter/Poth GbR
http://www.lat-lon.de
 
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.
 
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.
 
You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
Contact:
 
Andreas Poth
lat/lon Fitzke/Fretter/Poth GbR
Meckenheimer Allee 176
53115 Bonn
Germany
E-Mail: poth@lat-lon.de
 
Jens Fitzke
Department of Geography
University of Bonn
Meckenheimer Allee 166
53115 Bonn
Germany
E-Mail: jens.fitzke@uni-bonn.de
 
 
 ---------------------------------------------------------------------------*/

package org.deegree_impl.services.wts;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import javax.media.j3d.Appearance;
import javax.media.j3d.Material;
import javax.media.j3d.Texture;
import javax.media.j3d.TextureAttributes;
import javax.media.jai.JAI;
import javax.vecmath.Color3f;

import org.deegree.graphics.sld.StyledLayerDescriptor;
import org.deegree.model.geometry.GM_Envelope;
import org.deegree.model.geometry.GM_Surface;
import org.deegree.services.wfs.filterencoding.Filter;
import org.deegree.services.wts.TextureLoader;
import org.deegree_impl.model.geometry.GeometryFactory;
import org.deegree_impl.tools.Debug;
import org.opengis.cs.CS_CoordinateSystem;

import com.sun.media.jai.codec.MemoryCacheSeekableStream;


/**
 * class for loading terrain and/or object texturs from a Web Coverage Service
 * <p>----------------------------------------------------------------------</p>
 * @author  Andreas Poth
 * @version 1.1.2003
 */
public class WCSTextureLoader implements TextureLoader {
    
    private Material material       = null;
    private String url              = null;
    private int width               = 128;
    private int height              = 128;
    private String format           = "jpg";
    private GeometryFactory factory = null;
    
    /** 
     * Creates a new instance of <tt>WCSTextureLoader</tt>. 
     * @param url URL of the WCS
     */
    public WCSTextureLoader(String baseUrl, int width, int height, String format) {
        this.url = baseUrl;
        this.width = width;
        this.height = height;
        this.format = format;
        factory = new GeometryFactory();
        
        Color3f white = new Color3f(0.5f, 0.5f, 0.5f );
        material = new Material();        
        
        // The Material object defines the appearance of an object under illumination. 
        // If the Material object in an Appearance object is null, lighting is 
        // disabled for all nodes that use that Appearance object.         
        material.setAmbientColor(white);
        material.setDiffuseColor(white);
        material.setSpecularColor(white);
        material.setShininess(1f);
        material.setLightingEnable(true);
    }
    
    /** 
     * Creates a new instance of <tt>WCSTextureLoader</tt>. 
     * @param url URL of the WCS
     */
    public WCSTextureLoader(String baseUrl, int width, int height, String format, Material material) {        
        this.url = baseUrl;
        this.width = width;
        this.height = height;
        this.format = format;
        factory = new GeometryFactory();
        this.material = material;
    }
    
    private BufferedImage getTexture(String url) throws IOException {
        
        Debug.debugMethodBegin( this,  "getTexture" );
        BufferedImage img = null;
        try {
            // connect WCS
            URL u = new URL( url );
            InputStream is = u.openStream();
            // create seekable stream to read the bytes from the into a 
            // BufferedImage using JAI            
            MemoryCacheSeekableStream mss = new MemoryCacheSeekableStream( is );
            img = JAI.create( "stream", mss ).getAsBufferedImage();
            mss.close();
            is.close();
            
        } catch(MalformedURLException e) {
            throw new IOException( e.toString() );            
        }
        
        Debug.debugMethodEnd();
        return img;
    }
        
    
    /** returns the Textures (<tt>Texture</tt>s) are identified by the submitted
     * filter expression. 
     *
     */
    public Appearance[] loadTexturesA(String name, Filter filter) throws IOException {        
        return null;
    }    
    
    /** returns the Textures (<tt>Appearance</tt>s) thats x/y coordinates are contained
     * within the submitted <tt>GM_Surface</tt>. For constructing the WCS request 
     * the <tt>CS_CoordinateSystem</tt> of the submitted <tt>GM_Surface</tt>
     * will be used. If no filter geometry is submitted 'EPSG:4326' will be used
     * as default.
     * @param name requested layer (id)
     * @param ring limiting geometry (filter)
     */
    public Appearance[] loadTexturesA(String name, GM_Surface ring) throws IOException {
        
        Debug.debugMethodBegin( this,  "loadTextures(String, GM_Surface)" );
        
        GM_Envelope env = ring.getEnvelope();
        String crs = "EPSG:4326";
        if ( ring != null ) {
            CS_CoordinateSystem cs = ring.getCoordinateSystem();
            crs = cs.getName().replace(' ', ':');
        }
        StringBuffer sb = new StringBuffer( "?request=GetCoverage&version=0.7&" );
        sb.append( "Layer=" + name + "&" );
        sb.append( "SRS=" + crs + "&" );
        sb.append( "BBOX=" + env.getMin().getX() + "," + env.getMin().getY() + "," );
        sb.append( env.getMax().getX() + "," + env.getMax().getY() + "&" );
        sb.append(  "&Width=" + width );
        sb.append(  "&Height=" + height );
        sb.append(  "&Format=" + format );        
        
        BufferedImage img = getTexture( url + sb );
        Texture texture = new com.sun.j3d.utils.image.TextureLoader( img ).getTexture();
        
        // The Appearance object defines all rendering state that can be set as a 
        // component object of a Shape3D node. 
        Appearance app = new Appearance();
        app.setTexture( texture );
        app.setMaterial( material );        
        //ALLOW_TEXTURE_WRITE: Specifies that this Appearance object allows 
        // writing its texture component information.
        app.setCapability( Appearance.ALLOW_TEXTURE_WRITE );
        //TextureAttributes object defines attributes that apply to texture mapping.
        TextureAttributes texAttr = new TextureAttributes();
        //MODULATE: Modulate the object color with the texture color.
        texAttr.setTextureMode(TextureAttributes.MODULATE);
        app.setTextureAttributes(texAttr);              
        
        Debug.debugMethodEnd();
        return new Appearance[] { app };
        
    }
    
    /** returns the Textures (<tt>Appearance</tt>s) are identified by the submitted
     * <tt>StyledLayerDescriptor</tt>
     *
     */
    public Appearance[] loadTexturesA(StyledLayerDescriptor sld) throws IOException {
        return null;
    }    
    
    /** returns the Textures (<tt>Texture</tt>s) are identified by the submitted
     * filter expression. 
     *
     */
    public BufferedImage[] loadTextures(String name, Filter filter) throws IOException {                
        
        return null;
    }
    
    /** returns the Textures (<tt>Texture</tt>s) thats x/y coordinates are contained
     * within the submitted <tt>GM_Surface</tt>. 
     *
     */
    public BufferedImage[] loadTextures(String name, GM_Surface ring) throws IOException {
        Debug.debugMethodBegin( this,  "loadTextures(String, GM_Surface)" );
        
        BufferedImage[] bi = new BufferedImage[1];
        
        GM_Envelope env = ring.getEnvelope();
        String crs = "EPSG:4326";
        if ( ring != null ) {
            CS_CoordinateSystem cs = ring.getCoordinateSystem();
            crs = cs.getName().replace(' ', ':');
        }
        StringBuffer sb = new StringBuffer( "?request=GetCoverage&version=0.7&" );
        sb.append( "Layer=" + name + "&" );
        sb.append( "SRS=" + crs + "&" );
        sb.append( "BBOX=" + env.getMin().getX() + "," + env.getMin().getY() + "," );
        sb.append( env.getMax().getX() + "," + env.getMax().getY() + "&" );
        sb.append(  "&Width=" + width );
        sb.append(  "&Height=" + height );
        sb.append(  "&Format=" + format );        
        
        bi[0] = getTexture( url + sb );
        
        Debug.debugMethodEnd();
        return bi; 
    }
    
    /** returns the Textures (<tt>Texture</tt>s) are identified by the submitted
     * <tt>StyledLayerDescriptor</tt>
     *
     */
    public BufferedImage[] loadTextures(StyledLayerDescriptor sld) throws IOException {
        return null;
    }    
}
