Obtained from: http://jocache.sourceforge.net/
License: LGPL (see http://jocache.sourceforge.net/lesser.html)