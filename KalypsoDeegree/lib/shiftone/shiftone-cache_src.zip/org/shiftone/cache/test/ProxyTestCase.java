package org.shiftone.cache.test;



import junit.framework.TestCase;

import org.shiftone.cache.Cache;
import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.CacheProxy;
import org.shiftone.cache.policy.single.SingleCacheFactory;

import java.util.ArrayList;
import java.util.List;


public class ProxyTestCase extends TestCase
{

    public void testProxy() throws Exception
    {

        List         list    = new ArrayList();
        CacheFactory factory = new SingleCacheFactory();
        Cache        cache   = factory.newInstance("proxyTest", 1000, 1);
        List         plist   = (List) CacheProxy.newProxyInstance(list, List.class, cache);

        System.out.println(plist.size());
        System.out.println(plist.add("test1"));
        System.out.println(plist.add("test2"));
        System.out.println(plist.add("test1"));
        System.out.println(plist.size());
        System.out.println(plist.size());
        System.out.println(plist.size());
    }
}
