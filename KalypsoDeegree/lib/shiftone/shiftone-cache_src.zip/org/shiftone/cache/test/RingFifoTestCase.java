package org.shiftone.cache.test;



import junit.framework.TestCase;

import org.shiftone.cache.util.RingFifo;


/**
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 * @version $Revision: 1.5 $
 */
public class RingFifoTestCase extends TestCase
{

    public void testSimple()
    {

        RingFifo fifo = new RingFifo(5);

        assertEquals(",,,,", fifo.dump());
        fifo.enqueue("A");
        assertEquals("A", fifo.peek());
        assertEquals("A,,,,", fifo.dump());
        fifo.enqueue("B");
        assertEquals("A,B,,,", fifo.dump());
        fifo.enqueue("C");
        assertEquals("A,B,C,,", fifo.dump());
        fifo.enqueue("D");
        assertEquals("A,B,C,D,", fifo.dump());
        fifo.enqueue("E");
        assertEquals("A,B,C,D,E", fifo.dump());
        fifo.enqueue("F");
        assertEquals("F,B,C,D,E", fifo.dump());
        fifo.enqueue("G");
        assertEquals("C", fifo.dequeue());
        assertEquals("D", fifo.dequeue());
        assertEquals("E", fifo.dequeue());
        assertEquals("F", fifo.dequeue());
        assertEquals("G", fifo.dequeue());
        assertNull(fifo.dequeue());
    }
}
