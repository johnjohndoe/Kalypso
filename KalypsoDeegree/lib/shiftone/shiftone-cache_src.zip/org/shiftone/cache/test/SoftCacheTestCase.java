package org.shiftone.cache.test;



import junit.framework.TestCase;

import org.shiftone.cache.Cache;
import org.shiftone.cache.adaptor.MapCache;
import org.shiftone.cache.decorator.soft.SoftCache;

import java.lang.ref.Reference;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;


public class SoftCacheTestCase extends TestCase
{

    public void testSimple() throws Exception
    {

        Cache cache1 = new MapCache(new Hashtable());
        Cache cache2 = new SoftCache(cache1);

        cache2.addObject("key", "value");
        assertEquals("value", cache2.getObject("key"));
    }


    public void testReference() throws Exception
    {

        Object    inObject = createBigObject();
        Object    outObject;
        MapCache  mapCache;
        SoftCache softCache;

        mapCache  = new MapCache(new Hashtable());
        softCache = new SoftCache(mapCache);

        softCache.addObject("key", inObject);

        outObject = mapCache.getObject("key");

        assertTrue("outObject instanceof Reference", outObject instanceof Reference);
        assertTrue("cache2.getObject('key') == inObject", softCache.getObject("key") == inObject);

        outObject = null;
        inObject  = null;

        for (int i = 0; i < 10; i++)
        {
            Runtime.getRuntime().gc();
            Runtime.getRuntime().runFinalization();
            Runtime.getRuntime().gc();
            softCache.addObject(new Integer(i), createBigObject());

            //softCache.removeExpiredElements();
            Thread.sleep(500);
        }
    }


    public Object createBigObject()
    {

        List list = new ArrayList();

        for (int i = 0; i < 500000; i++)
        {
            list.add(Integer.toOctalString(i));
        }

        return list;
    }
}
