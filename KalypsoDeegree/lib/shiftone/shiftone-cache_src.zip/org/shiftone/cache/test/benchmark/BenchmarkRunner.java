package org.shiftone.cache.test.benchmark;



import com.opensymphony.oscache.base.algorithm.FIFOCache;
import com.opensymphony.oscache.base.algorithm.LRUCache;

import org.shiftone.cache.Cache;
import org.shiftone.cache.adaptor.*;
import org.shiftone.cache.policy.fifo.FifoCacheFactory;
import org.shiftone.cache.policy.lfu.LfuCacheFactory;
import org.shiftone.cache.policy.lru.LruCacheFactory;
import org.shiftone.cache.policy.zero.ZeroCacheFactory;
import org.shiftone.cache.policy.single.SingleCacheFactory;

import java.io.PrintStream;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Random;


/**
 * @version $Revision: 1.15 $
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 */
public class BenchmarkRunner
{

    private static final int      TIMEOUT_MS       = 60 * 60 * 1000;    // 1 hour
    private static final int      MILLION          = 1000000;
    private static final int      KEY_COUNT        = MILLION;
    private static final Object[] SEQUENCIAL_KEYS  = new Object[KEY_COUNT];
    private static final Object[] PSUDORANDOM_KEYS = new Object[KEY_COUNT];
    private Benchmark[]           benchmarks;
    private Cache[]               caches;

    public BenchmarkRunner() throws Exception
    {

        Random random = new Random(0);

        for (int i = 0; i < SEQUENCIAL_KEYS.length; i++)
        {
            SEQUENCIAL_KEYS[i]  = new Integer(i);
            PSUDORANDOM_KEYS[i] = new Integer(random.nextInt());
        }

        Benchmark sequencialAdd    = new AddBenchmark("S-Add", SEQUENCIAL_KEYS);
        Benchmark randomGet        = new GetBenchmark("R-Get", PSUDORANDOM_KEYS);
        Benchmark sequencialGet    = new GetBenchmark("S-Get", SEQUENCIAL_KEYS);
        Benchmark sequencialRemove = new RemoveBenchmark("S-Rem", SEQUENCIAL_KEYS);

        benchmarks = new Benchmark[]
        {
            sequencialAdd, sequencialAdd, sequencialAdd,                              //
            sequencialGet, sequencialGet, sequencialGet,                              //
            randomGet, randomGet, randomGet,                                          //
            sequencialRemove, sequencialRemove, sequencialRemove
        };
        caches     = new Cache[]
        {
            new MapCache(new HashMap(KEY_COUNT)),                                     //
            new MapCache(new Hashtable(KEY_COUNT)),                                   //
            new MapCache(new FIFOCache(KEY_COUNT)),                                   //
            new MapCache(new LRUCache(KEY_COUNT)),                                    //
            new SwarmCache(KEY_COUNT),                                                //
            new JcsCache(),                                                           //
            new EHCacheCache("test"),                                                 //
            new ZeroCacheFactory().newInstance("zero", TIMEOUT_MS, KEY_COUNT),        //
            new SingleCacheFactory().newInstance("single", TIMEOUT_MS, KEY_COUNT),    //
            new FifoCacheFactory().newInstance("fifo", TIMEOUT_MS, KEY_COUNT),        //
            new LruCacheFactory().newInstance("lru", TIMEOUT_MS, KEY_COUNT),          //
            new LfuCacheFactory().newInstance("lfu", TIMEOUT_MS, KEY_COUNT),          //
            OroCache.createFIFO(KEY_COUNT),                                           //
            OroCache.createFIFO2(KEY_COUNT),                                          //
            OroCache.createLRU(KEY_COUNT),                                            //
            OroCache.createRandom(KEY_COUNT)                                          //
        };
    }


    private final long now()
    {
        return System.currentTimeMillis();
    }


    public void run(PrintStream tsv)
    {

        for (int i = 0; i < benchmarks.length; i++)
        {
            tsv.print("\t" + benchmarks[i]);
        }

        tsv.println();

        for (int i = 0; i < caches.length; i++)
        {
            run(caches[i], tsv);
        }
    }


    public void run(Cache cache, PrintStream tsv)
    {

        long start;

        tsv.print(cache);
        tsv.print('\t');

        // -----------------------------------------
        for (int i = 0; i < benchmarks.length; i++)
        {
            start = now();

            benchmarks[i].run(cache);
            tsv.print(now() - start);
            tsv.print('\t');
        }

        tsv.println();
        cache.clear();
        Runtime.getRuntime().gc();
        Runtime.getRuntime().runFinalization();
    }


    //    new BenchmarkRunner(new MapCache(new LinkedHashMap())),
    public static void main(String[] args) throws Exception
    {

        PrintStream     tsv    = System.out;
        BenchmarkRunner runner = new BenchmarkRunner();

        runner.run(tsv);
    }
}
