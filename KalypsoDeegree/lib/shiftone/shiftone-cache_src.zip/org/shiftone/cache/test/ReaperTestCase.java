package org.shiftone.cache.test;



import junit.framework.TestCase;

import org.shiftone.cache.Cache;
import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.policy.fifo.FifoCacheFactory;
import org.shiftone.cache.util.Log;

import java.util.ArrayList;
import java.util.List;


/**
 * @version $Revision: 1.3 $
 * @author $Author: jeffdrost $
 */
public class ReaperTestCase extends TestCase
{

    private static final Log LOG = new Log(ReaperTestCase.class);

    public void testSoft() throws Exception
    {

        CacheFactory factory = new FifoCacheFactory();
        Cache        cache   = factory.newInstance("test", 10000, 10000);

        LOG.info("cache = " + cache);
        cache.addObject("test", "test");
        Thread.sleep(5000);

        cache = null;

        Thread.sleep(5000);

        Object o = createBigObject();

        Runtime.getRuntime().gc();
        Runtime.getRuntime().runFinalization();
        Thread.sleep(5000);
    }


    Object createBigObject()
    {

        List list = new ArrayList();

        for (int i = 0; i < 10000; i++)
        {
            list.add(new byte[1024]);
        }

        return list;
    }
}
