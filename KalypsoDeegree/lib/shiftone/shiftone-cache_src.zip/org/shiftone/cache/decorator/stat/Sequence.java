package org.shiftone.cache.decorator.stat;



/**
 * @version $Revision: 1.1 $
 * @author $Author: jeffdrost $
 */
public class Sequence
{

    private long value = 0;

    public synchronized void increment()
    {
        value++;
    }


    public synchronized long getValue()
    {
        return value;
    }


    public String toString()
    {
        return String.valueOf(value);
    }
}
