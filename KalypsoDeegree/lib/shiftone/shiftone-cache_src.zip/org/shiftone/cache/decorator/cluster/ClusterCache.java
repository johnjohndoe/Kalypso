package org.shiftone.cache.decorator.cluster;



import org.shiftone.cache.Cache;
import org.shiftone.cache.util.Log;


/**
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 * @version $Revision: 1.8 $
 */
public class ClusterCache implements Cache
{

    private final Log                 LOG = new Log(ClusterCache.class);
    private final ClusterCacheFactory factory;
    private final Cache               cache;
    private final String              name;

    public ClusterCache(String name, Cache cache, ClusterCacheFactory factory)
    {

        this.factory = factory;
        this.cache   = cache;
        this.name    = name;
    }


    public void addObject(Object userKey, Object cacheObject)
    {

        //  remove(userKey);
        cache.addObject(userKey, cacheObject);
    }


    public Object getObject(Object key)
    {
        return cache.getObject(key);
    }


    public int size()
    {
        return cache.size();
    }


    public void remove(Object key)
    {
        cache.remove(key);
        factory.sendRemoveNotification(name, key);
    }


    public void clear()
    {
        cache.clear();
        factory.sendClearNotification(name);
    }


    //-----------------------------------------------------------
    public Cache getCache()
    {
        return cache;
    }


    public String getName()
    {
        return name;
    }


    //-----------------------------------------------------------
    public final String toString()
    {
        return "ClusterCache->" + cache;
    }
}
