package org.shiftone.cache.decorator.cluster;



import org.jgroups.Address;
import org.jgroups.blocks.NotificationBus;
import org.shiftone.cache.util.Log;

import java.io.Serializable;


/**
 * @version $Revision: 1.2 $
 * @author $Author: jeffdrost $
 */
public class ClusterConsumer implements NotificationBus.Consumer
{

    private static final Log          LOG = new Log(ClusterConsumer.class);
    private final ClusterBus          bus;
    private final ClusterCacheFactory clusterCacheFactory;
    private int                       members = 0;

    public ClusterConsumer(ClusterBus bus)
    {
        this.bus                 = bus;
        this.clusterCacheFactory = bus.getClusterCacheFactory();
    }


    public void handleNotification(Serializable serializable)
    {

        if (serializable instanceof Notification)
        {
            clusterCacheFactory.handleNotification((Notification) serializable);
        }
    }


    public Serializable getCache()
    {
        return null;
    }


    public synchronized void memberJoined(Address address)
    {

        LOG.info("memberJoined " + address);

        members++;

        updateAlone();
    }


    public synchronized void memberLeft(Address address)
    {

        LOG.info("memberJoined " + address);

        members--;

        updateAlone();
    }


    private void updateAlone()
    {
        bus.setAloneInCluster(members == 1);
    }
}
