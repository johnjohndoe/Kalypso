package org.shiftone.cache.decorator.cluster;



import org.jgroups.blocks.NotificationBus;
import org.shiftone.cache.util.Log;


/**
 * @version $Revision: 1.2 $
 * @author $Author: jeffdrost $
 */
public class ClusterBus
{

    private static final Log          LOG = new Log(ClusterBus.class);
    private final ClusterCacheFactory clusterCacheFactory;
    private NotificationBus           bus;
    private boolean                   aloneInCluster = true;

    public ClusterBus(ClusterCacheFactory clusterCacheFactory) throws Exception
    {

        this.clusterCacheFactory = clusterCacheFactory;
        this.bus                 = new NotificationBus(clusterCacheFactory.getBusName(), clusterCacheFactory.getChannelProperties());

        bus.setConsumer(new ClusterConsumer(this));
        bus.start();
    }


    public void sendNotification(Notification notification)
    {

        if (isAloneInCluster() == false)
        {
            bus.sendNotification(notification);
        }
    }


    public boolean isAloneInCluster()
    {
        return aloneInCluster;
    }


    public void setAloneInCluster(boolean aloneInCluster)
    {
        this.aloneInCluster = aloneInCluster;
    }


    public ClusterCacheFactory getClusterCacheFactory()
    {
        return clusterCacheFactory;
    }
}
