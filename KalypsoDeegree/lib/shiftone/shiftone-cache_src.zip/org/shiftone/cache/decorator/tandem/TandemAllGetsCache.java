package org.shiftone.cache.decorator.tandem;



import org.shiftone.cache.util.Log;
import org.shiftone.cache.Cache;


/**
 * Overides getObject to ALWAYSE delegate all gets to all caches.
 * This ensures that any stats that are kept by the caches are in sync.
 * @version $Revision: 1.1 $
 * @author $Author: jeffdrost $
 */
public class TandemAllGetsCache extends TandemCache
{

    private static final Log LOG = new Log(TandemAllGetsCache.class);

    public TandemAllGetsCache(Cache[] caches)
    {
        super(caches);
    }


    public Object getObject(Object key)
    {

        Object result = null;
        Object object = null;

        for (int i = 0; i < caches.length; i++)
        {
            object = caches[i].getObject(key);

            if (object != null)
            {
                result = object;
            }
        }

        return result;
    }
}
