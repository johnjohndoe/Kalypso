package org.shiftone.cache.decorator.tandem;



import org.shiftone.cache.util.Log;
import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.Cache;


/**
 * Creates a single cache that delegates to a pair of different caches.
 * @version $Revision: 1.1 $
 * @author $Author: jeffdrost $
 */
public class TandemCacheFactory implements CacheFactory
{

    private static final Log LOG     = new Log(TandemCacheFactory.class);
    private boolean          allGets = true;
    private CacheFactory     delegateA;
    private CacheFactory     delegateB;

    public Cache newInstance(String cacheName, long timeoutMilliSeconds, int maxSize)
    {

        Cache   cacheA = delegateA.newInstance(cacheName, timeoutMilliSeconds, maxSize);
        Cache   cacheB = delegateB.newInstance(cacheName, timeoutMilliSeconds, maxSize);
        Cache[] caches = { cacheA, cacheB };

        return (allGets)
               ? new TandemAllGetsCache(caches)
               : new TandemCache(caches);
    }


    public boolean isAllGets()
    {
        return allGets;
    }


    public void setAllGets(boolean allGets)
    {
        this.allGets = allGets;
    }


    public CacheFactory getDelegateA()
    {
        return delegateA;
    }


    public void setDelegateA(CacheFactory delegateA)
    {
        this.delegateA = delegateA;
    }


    public CacheFactory getDelegateB()
    {
        return delegateB;
    }


    public void setDelegateB(CacheFactory delegateB)
    {
        this.delegateB = delegateB;
    }
}
