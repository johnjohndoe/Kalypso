package org.shiftone.cache.decorator.cluster;



import org.shiftone.cache.Cache;
import org.shiftone.cache.CacheException;
import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.util.Log;
import org.shiftone.cache.util.WeakMap;

import java.util.Random;


/**
 * @version $Revision: 1.12 $
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 */
public class ClusterCacheFactory implements CacheFactory
{

    private static final Log    LOG                = new Log(ClusterCacheFactory.class);
    private static final Random random             = new Random();
    public static final String  DEFAULT_BUS_NAME   = "shiftone-cache";
    private WeakMap             registeredCacheMap = new WeakMap();
    private final long          instanceId         = random.nextLong();
    private ClusterBus          bus;
    private CacheFactory        delegate          = null;                // configured
    private String              channelProperties = "";                  // configured
    private String              busName           = DEFAULT_BUS_NAME;    // configured

    private void init() throws CacheException
    {

        // if the bus has not been initialized, do so now
        if (bus == null)
        {
            try
            {
                bus = new ClusterBus(this);
            }
            catch (Exception e)
            {
                throw new CacheException("error initializing JGroups NotificationBus", e);
            }
        }
    }


    public Cache newInstance(String cacheName, long timeoutMilliSeconds, int maxSize)
    {

        Cache        delegateCache;
        ClusterCache clusterCache;

        try
        {
            init();

            clusterCache = getRegisteredCache(cacheName);

            // if another cache of the same name has been registered
            // then return it.  The down side of this is that the second
            // version time the cache is returned, the timeout and max size
            // has no effect on the returned cache.
            // Also, this class does not extends AbstractDecoratorCacheFactory
            // because it needs to decide if the delegate cache should be
            // created.
            if (clusterCache == null)
            {
                delegateCache = delegate.newInstance(cacheName, timeoutMilliSeconds, maxSize);
                clusterCache  = new ClusterCache(cacheName, delegateCache, this);

                registerCache(cacheName, clusterCache);
            }
            else
            {
                LOG.info("returning existing cache : " + cacheName);
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException("unable to create cluster decorator");
        }

        return clusterCache;
    }


    private synchronized void registerCache(String cacheName, ClusterCache clusterCache)
    {
        registeredCacheMap.put(cacheName, clusterCache);
    }


    private synchronized ClusterCache getRegisteredCache(String cacheName)
    {
        return (ClusterCache) registeredCacheMap.get(cacheName);
    }


    public String getBusName()
    {
        return busName;
    }


    public void setBusName(String busName)
    {
        this.busName = busName;
    }


    public String getChannelProperties()
    {
        return channelProperties;
    }


    public void setChannelProperties(String channelProperties)
    {
        this.channelProperties = channelProperties;
    }


    public void setDelegate(CacheFactory delegate)
    {
        this.delegate = delegate;
    }


    public String toString()
    {
        return "ClusterCacheFactory[" + busName + "]->" + delegate;
    }


    //-----------------------------------------------------------
    public void sendRemoveNotification(String cacheName, Object key)
    {
        bus.sendNotification(new RemoveNotification(instanceId, cacheName, key));
    }


    public void sendClearNotification(String cacheName)
    {
        bus.sendNotification(new ClearNotification(instanceId, cacheName));
    }


    public void handleNotification(Notification notification)
    {

        ClusterCache clusterCache;

        // don't process self notification
        if (notification.getSenderInstanceId() != instanceId)
        {
            clusterCache = getRegisteredCache(notification.getCacheName());

            // if this factory doesn't have this cache, it isn't
            // really possible to execute a notification on it
            if (clusterCache != null)
            {
                LOG.debug("execute : " + notification);
                notification.execute(clusterCache.getCache());
            }
        }
    }
}
