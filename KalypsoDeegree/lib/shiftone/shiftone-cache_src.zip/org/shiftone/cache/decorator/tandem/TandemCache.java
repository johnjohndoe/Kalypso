package org.shiftone.cache.decorator.tandem;



import org.shiftone.cache.util.Log;
import org.shiftone.cache.Cache;


/**
 * This cache will stop asking cache's for values once one of them
 * returns a non null response.
 * @version $Revision: 1.1 $
 * @author $Author: jeffdrost $
 */
public class TandemCache implements Cache
{

    private static final Log LOG = new Log(TandemCache.class);
    protected final Cache[]  caches;

    public TandemCache(Cache[] caches)
    {
        this.caches = caches;
    }


    public void addObject(Object userKey, Object cacheObject)
    {

        for (int i = 0; i < caches.length; i++)
        {
            caches[i].addObject(userKey, cacheObject);
        }
    }


    public Object getObject(Object key)
    {

        Object object = null;

        for (int i = 0; i < caches.length; i++)
        {
            object = caches[i].getObject(key);

            if (object != null)
            {
                return object;
            }
        }

        return null;
    }


    public int size()
    {

        int max = 0;

        for (int i = 0; i < caches.length; i++)
        {
            max = Math.max(max, caches[i].size());
        }

        return max;
    }


    public void remove(Object key)
    {

        for (int i = 0; i < caches.length; i++)
        {
            caches[i].remove(key);
        }
    }


    public void clear()
    {

        for (int i = 0; i < caches.length; i++)
        {
            caches[i].clear();
        }
    }
}
