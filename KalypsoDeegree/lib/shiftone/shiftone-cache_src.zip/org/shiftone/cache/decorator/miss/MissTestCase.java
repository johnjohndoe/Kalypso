package org.shiftone.cache.decorator.miss;



import junit.framework.TestCase;
import org.shiftone.cache.Cache;
import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.policy.fifo.FifoCacheFactory;
import org.shiftone.cache.util.Log;


/**
 * @version $Revision: 1.3 $
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 */
public class MissTestCase extends TestCase
{

    private static final Log LOG = new Log(MissTestCase.class);
    private Cache            theTestCache;

    public MissHandlingCache createCache()
    {

        CacheFactory             cacheFactory     = new FifoCacheFactory();
        MissHandlingCacheFactory missCacheFactory = new MissHandlingCacheFactory();

        missCacheFactory.setDelegate(cacheFactory);
        missCacheFactory.setMissHandlerClass(TestMissHandler.class);

        return (MissHandlingCache) missCacheFactory.newInstance("test", 10000, 10000);
    }


    public void testSimple() throws Exception
    {

        Cache cache = createCache();

        cache.getObject("A");
        cache.getObject("A");
        cache.getObject("A");
        cache.getObject("A");
        cache.getObject("A");
        cache.getObject("A");
    }


    public void testGetLock() throws Exception
    {

        MissHandlingCache cache = createCache();
        Object            lock1 = cache.getLock("A");
        Object            lock2 = cache.getLock("A");

        assertTrue(lock1 == lock2);
        cache.unlockKey("A");
        cache.unlockKey("A");

        Object lock3 = cache.getLock("A");

        assertFalse(lock1 == lock3);
    }


    public void testThreads() throws Exception
    {

        this.theTestCache = createCache();

        Thread[] threads = new Thread[100];

        for (int i = 0; i < threads.length; i++)
        {
            threads[i] = new Thread(new GetterThread());

            threads[i].start();
        }

        for (int i = 0; i < threads.length; i++)
        {
            LOG.info("waiting for joing " + i + " ...");
            threads[i].join();
        }

        this.theTestCache = null;
    }


    private class GetterThread implements Runnable
    {

        public void run()
        {
            theTestCache.getObject("X");
        }
    }
}
