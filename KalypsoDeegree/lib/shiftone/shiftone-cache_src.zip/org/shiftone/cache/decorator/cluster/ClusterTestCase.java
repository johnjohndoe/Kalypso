package org.shiftone.cache.decorator.cluster;



import junit.framework.TestCase;
import org.shiftone.cache.Cache;
import org.shiftone.cache.CacheConfiguration;
import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.util.Log;


/**
 * @version $Revision: 1.4 $
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 */
public class ClusterTestCase extends TestCase
{

    private static final Log LOG = new Log(ClusterTestCase.class);

    public void testCluster() throws Exception
    {

        CacheConfiguration config   = new CacheConfiguration();
        CacheFactory       factoryA = config.getCacheFactory("clusterA");
        CacheFactory       factoryB = config.getCacheFactory("clusterB");
        Cache              oneA     = factoryA.newInstance("one", 1000, 1000);
        Cache              oneB     = factoryB.newInstance("one", 1000, 1000);

        for (int i = 0; i < 1000; i++)
        {
            oneA.addObject("key" + i, "value");
            oneB.addObject("key" + i, "value");
        }

        for (int i = 0; i < 1000; i++)
        {
            oneA.remove("key" + i);
        }

        LOG.info("sleeping...");
        Thread.sleep(2000);
    }
}
