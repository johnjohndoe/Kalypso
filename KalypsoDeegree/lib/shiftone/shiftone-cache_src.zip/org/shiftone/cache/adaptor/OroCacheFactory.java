package org.shiftone.cache.adaptor;



import org.shiftone.cache.Cache;
import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.policy.zero.ZeroCacheFactory;
import org.shiftone.cache.util.Log;


/**
 * Factory for ORO cache policys.
 *
 * @version $Revision: 1.1 $
 * @author $Author: jeffdrost $
 */
public class OroCacheFactory implements CacheFactory
{

    private static final Log LOG              = new Log(OroCacheFactory.class);
    public static String     ALGORITHM_FIFO   = "FIFO";
    public static String     ALGORITHM_FIFO2  = "FIFO2";
    public static String     ALGORITHM_LRU    = "LRU";
    public static String     ALGORITHM_RANDOM = "RANDOM";
    private String           algorithm        = ALGORITHM_LRU;

    public Cache newInstance(String cacheName, long timeoutMilliSeconds, int maxSize)
    {

        if (ALGORITHM_FIFO.equalsIgnoreCase(algorithm))
        {
            return OroCache.createFIFO(maxSize);
        }
        else if (ALGORITHM_FIFO2.equalsIgnoreCase(algorithm))
        {
            return OroCache.createFIFO2(maxSize);
        }
        else if (ALGORITHM_LRU.equalsIgnoreCase(algorithm))
        {
            return OroCache.createLRU(maxSize);
        }
        else if (ALGORITHM_RANDOM.equalsIgnoreCase(algorithm))
        {
            return OroCache.createRandom(maxSize);
        }
        else
        {
            LOG.info("unknown ORO cache algorithm : " + algorithm);

            return ZeroCacheFactory.NULL_CACHE;
        }
    }


    public String getAlgorithm()
    {
        return algorithm;
    }


    /**
     *  FIFO, FIFO2, LRU, RANDOM
     */
    public void setAlgorithm(String algorithm)
    {
        this.algorithm = algorithm;
    }
}
