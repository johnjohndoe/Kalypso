package org.shiftone.cache.adaptor;



import org.shiftone.cache.Cache;


/**
 * Makes a ORO cache look like a shiftone cache.
 * <p>
 * <b>Notes</b>
 * <li>No support for remove
 * <li>No support for clear
 * <li>No support for node expiration
 * <li>Cache initially allocates array of size "capacity"
 *
 * @version $Revision: 1.5 $
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 */
public class OroCache implements Cache
{

    private final org.apache.oro.util.Cache cache;

    public static Cache createFIFO(int capacity)
    {
        return new OroCache(new org.apache.oro.util.CacheFIFO(capacity));
    }


    public static Cache createFIFO2(int capacity)
    {
        return new OroCache(new org.apache.oro.util.CacheFIFO2(capacity));
    }


    public static Cache createLRU(int capacity)
    {
        return new OroCache(new org.apache.oro.util.CacheLRU(capacity));
    }


    public static Cache createRandom(int capacity)
    {
        return new OroCache(new org.apache.oro.util.CacheRandom(capacity));
    }


    public OroCache(org.apache.oro.util.Cache cache)
    {
        this.cache = cache;
    }


    public void addObject(Object userKey, Object cacheObject)
    {
        cache.addElement(userKey, cacheObject);
    }


    public Object getObject(Object key)
    {
        return cache.getElement(key);
    }


    public int size()
    {
        return cache.size();
    }


    /**
     * NOOP
     */
    public void remove(Object key) {}


    /**
     * NOOP
     */
    public void clear() {}


    public String toString()
    {
        return "OroCache[" + cache.getClass().getName() + ":" + cache.capacity() + "]";
    }
}
