package org.shiftone.cache.adaptor;



import net.sf.swarmcache.LRUCache;
import net.sf.swarmcache.ObjectCache;
import org.shiftone.cache.Cache;

import java.io.Serializable;


/**
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 * @version $Revision: 1.6 $
 */
public class SwarmCache implements Cache
{

    private final ObjectCache cache;

    public SwarmCache(int size)
    {

        LRUCache lruCache = new LRUCache();

        lruCache.setSize(size);

        this.cache = lruCache;
    }


    public SwarmCache(ObjectCache cache)
    {
        this.cache = cache;
    }


    public void addObject(Object userKey, Object cacheObject)
    {
        cache.put((Serializable) userKey, cacheObject);
    }


    public Object getObject(Object key)
    {
        return cache.get((Serializable) key);
    }


    /**
     * NOOP
     */
    public int size()
    {
        return -1;
    }


    public void remove(Object key)
    {
        cache.clear((Serializable) key);
    }


    public void clear()
    {
        cache.clearAll();
    }


    public String toString()
    {
        return "SwarmCache[" + cache.getClass().getName() + "]";
    }
}
