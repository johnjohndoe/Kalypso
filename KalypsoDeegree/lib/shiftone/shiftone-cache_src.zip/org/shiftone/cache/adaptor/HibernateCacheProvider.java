package org.shiftone.cache.adaptor;



import net.sf.hibernate.cache.Cache;
import net.sf.hibernate.cache.CacheException;
import net.sf.hibernate.cache.CacheProvider;
import net.sf.hibernate.cache.Timestamper;
import org.shiftone.cache.CacheConfiguration;
import org.shiftone.cache.ConfigurationException;
import org.shiftone.cache.util.Log;

import java.util.Properties;


/**
 * @version $Revision: 1.7 $
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 */
public class HibernateCacheProvider implements CacheProvider
{

    private static final Log   LOG = new Log(HibernateCacheProvider.class);
    private CacheConfiguration config;

    public HibernateCacheProvider() throws ConfigurationException
    {
        config = new CacheConfiguration();
    }


    public final Cache buildCache(String regionName, Properties properties) throws CacheException
    {

        org.shiftone.cache.Cache cache = config.createConfiguredCacheSafely(regionName);

        LOG.info("buildCache : " + cache);

        return new HibernateCache(cache);
    }


    public final long nextTimestamp()
    {
        return Timestamper.next();
    }
}
