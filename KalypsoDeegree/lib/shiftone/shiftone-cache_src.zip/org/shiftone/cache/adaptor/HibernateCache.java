package org.shiftone.cache.adaptor;



import net.sf.hibernate.cache.CacheException;
import net.sf.hibernate.cache.Timestamper;


/**
 * Makes a shiftone cache look like a hibernate cache.
 *
 * @version $Revision: 1.2 $
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 */
public class HibernateCache implements net.sf.hibernate.cache.Cache
{

    private final org.shiftone.cache.Cache cache;

    public HibernateCache(org.shiftone.cache.Cache cache)
    {
        this.cache = cache;
    }


    public final Object get(Object key) throws CacheException
    {
        return cache.getObject(key);
    }


    public final void put(Object key, Object value) throws CacheException
    {
        cache.addObject(key, value);
    }


    public final void remove(Object key) throws CacheException
    {
        cache.remove(key);
    }


    public final void clear() throws CacheException
    {
        cache.clear();
    }


    public final void destroy() throws CacheException
    {
        cache.clear();
    }


    /**
     * NOOP
     */
    public final void lock(Object o) throws CacheException {}


    /**
     * NOOP
     */
    public final void unlock(Object o) throws CacheException {}


    public final long nextTimestamp()
    {
        return Timestamper.next();
    }


    public final int getTimeout()
    {
        return 1;
    }
}
