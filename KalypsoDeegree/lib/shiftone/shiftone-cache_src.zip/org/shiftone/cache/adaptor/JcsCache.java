package org.shiftone.cache.adaptor;



import org.apache.commons.lang.exception.NestableRuntimeException;
import org.apache.jcs.JCS;
import org.apache.jcs.access.CacheAccess;
import org.apache.jcs.access.exception.CacheException;
import org.apache.jcs.engine.behavior.ICompositeCacheAttributes;
import org.shiftone.cache.Cache;


/**
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 * @version $Revision: 1.9 $
 */
public class JcsCache implements Cache
{

    private final CacheAccess cache;

    public JcsCache()
    {
        this("default");
    }

    public JcsCache(CacheAccess access)
    {
        this.cache = access;
    }

    public JcsCache(String name)
    {

        try
        {
            cache = JCS.getInstance(name);
        }
        catch (CacheException e)
        {
            throw new NestableRuntimeException("new JcsCache : " + name, e);
        }
    }


    public void addObject(Object userKey, Object cacheObject)
    {

        try
        {
            cache.put(userKey, cacheObject);
        }
        catch (CacheException e)
        {
            throw new NestableRuntimeException("addObject", e);
        }
    }


    public Object getObject(Object key)
    {
        return cache.get(key);
    }


    /**
     * NOOP
     */
    public int size()
    {
        return -1;
    }


    public void remove(Object key)
    {

        try
        {
            cache.remove(key);
        }
        catch (CacheException e)
        {
            throw new NestableRuntimeException("remove", e);
        }
    }


    public void clear()
    {

        try
        {
            cache.remove();
        }
        catch (CacheException e)
        {
            throw new NestableRuntimeException("remove", e);
        }
    }


    public String toString()
    {

        ICompositeCacheAttributes attributes = cache.getCacheAttributes();

        return "JCS[" + attributes.getCacheName()         //
               + ":" + attributes.getMemoryCacheName()    //
               + ":" + attributes.getMaxObjects() + "]";
    }
}
