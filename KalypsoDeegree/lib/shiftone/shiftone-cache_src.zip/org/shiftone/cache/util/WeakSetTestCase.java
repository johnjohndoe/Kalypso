package org.shiftone.cache.util;



import junit.framework.TestCase;


/**
 * @version $Revision: 1.2 $
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 */
public class WeakSetTestCase extends TestCase
{

    private static final Log LOG = new Log(WeakSetTestCase.class);

    public void testSet() throws Exception
    {

        WeakSet set = new WeakSet();

        for (int i = 0; i < 10000; i++)
        {
            set.add("this is a test " + (i * 3));
            Thread.sleep(10);
        }
    }
}
