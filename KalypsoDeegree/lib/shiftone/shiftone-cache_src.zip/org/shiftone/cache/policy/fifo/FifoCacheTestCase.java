package org.shiftone.cache.policy.fifo;



import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.util.TestCaseBase;


/**
 * Class FifoCacheTestCase
 *
 *
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 * @version $Revision: 1.2 $
 */
public class FifoCacheTestCase extends TestCaseBase
{

    public FifoCacheTestCase(String name)
    {
        super(name);
    }


    /**
     * Method getCacheFactory
     */
    public CacheFactory getCacheFactory()
    {
        return new FifoCacheFactory();
    }


    /**
     * Method testPut
     */
    public void testFifo()
    {

        FifoCache cache = new FifoCache("fifo", 5000, 10);

        cache.addObject("A", "A");    //1
        cache.addObject("B", "B");    //2
        cache.addObject("C", "C");    //3
        cache.addObject("D", "D");    //4
        cache.addObject("E", "E");    //5
        cache.addObject("F", "F");    //6
        cache.addObject("G", "G");    //7
        cache.addObject("H", "H");    //8
        cache.addObject("I", "I");    //9
        cache.addObject("J", "J");    //10
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());

        // getObject should have no effect
        assertNotNull(cache.getObject("A"));
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("B"));
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("C"));
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("D"));
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("E"));
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());

        // addObject should bump out elements
        cache.addObject("K", "K");    //11
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        cache.addObject("L", "L");    //12
        assertEquals("LKJIHGFEDC", cache.dumpFifoKeys());
        cache.addObject("M", "M");    //13
        assertEquals("MLKJIHGFED", cache.dumpFifoKeys());
        cache.addObject("N", "N");    //14
        assertEquals("NMLKJIHGFE", cache.dumpFifoKeys());
        cache.addObject("O", "O");    //15
        assertEquals("ONMLKJIHGF", cache.dumpFifoKeys());
    }
}
