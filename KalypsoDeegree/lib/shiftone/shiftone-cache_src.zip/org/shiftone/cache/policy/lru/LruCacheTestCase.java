package org.shiftone.cache.policy.lru;



import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.util.TestCaseBase;


/**
 * Class LruCacheTestCase
 *
 *
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 * @version $Revision: 1.2 $
 */
public class LruCacheTestCase extends TestCaseBase
{

    public LruCacheTestCase(String name)
    {
        super(name);
    }


    /**
     * Method getCacheFactory
     */
    public CacheFactory getCacheFactory()
    {
        return new LruCacheFactory();
    }


    /**
     * Method testLru5
     */
    public void testLru5()
    {

        LruCache cache = new LruCache("lru", 5000, 5);

        cache.addObject("A", new Integer(123456789));
        cache.addObject("B", "123456789");
        cache.addObject("C", new Long(123456789));
        cache.addObject("D", Boolean.TRUE);
        cache.addObject("E", new Float(1.2345));
        assertEquals("EDCBA", cache.dumpFifoKeys());
        assertEquals("EDCBA", cache.dumpLruKeys());
        assertNotNull(cache.getObject("C"));
        assertEquals("EDCBA", cache.dumpFifoKeys());
        assertEquals("CEDBA", cache.dumpLruKeys());
        cache.addObject("F", new Object());
        assertEquals("FEDCB", cache.dumpFifoKeys());
        assertEquals("FCEDB", cache.dumpLruKeys());
    }


    /**
     * Method testReValue
     */
    public void testLru10()
    {

        LruCache cache = new LruCache("lru", 5000, 10);

        cache.addObject("A", "A");    //1
        assertEquals("A", cache.dumpLruKeys());
        assertEquals("A", cache.dumpFifoKeys());
        cache.addObject("B", "B");    //2
        assertEquals("BA", cache.dumpLruKeys());
        assertEquals("BA", cache.dumpFifoKeys());
        cache.addObject("C", "C");    //3
        assertEquals("CBA", cache.dumpLruKeys());
        assertEquals("CBA", cache.dumpFifoKeys());
        cache.addObject("D", "D");    //4
        assertEquals("DCBA", cache.dumpLruKeys());
        assertEquals("DCBA", cache.dumpFifoKeys());
        cache.addObject("E", "E");    //5
        assertEquals("EDCBA", cache.dumpLruKeys());
        assertEquals("EDCBA", cache.dumpFifoKeys());
        cache.addObject("F", "F");    //6
        assertEquals("FEDCBA", cache.dumpLruKeys());
        assertEquals("FEDCBA", cache.dumpFifoKeys());
        cache.addObject("G", "G");    //7
        assertEquals("GFEDCBA", cache.dumpLruKeys());
        assertEquals("GFEDCBA", cache.dumpFifoKeys());
        cache.addObject("H", "H");    //8
        assertEquals("HGFEDCBA", cache.dumpLruKeys());
        assertEquals("HGFEDCBA", cache.dumpFifoKeys());
        cache.addObject("I", "I");    //9
        assertEquals("IHGFEDCBA", cache.dumpLruKeys());
        assertEquals("IHGFEDCBA", cache.dumpFifoKeys());
        cache.addObject("J", "J");    //10
        assertEquals("JIHGFEDCBA", cache.dumpLruKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());

        // this should bump out A
        cache.addObject("K", "K");    //11
        assertEquals("KJIHGFEDCB", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());

        // observe the effect of getObject
        assertNotNull(cache.getObject("E"));
        assertEquals("EKJIHGFDCB", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("G"));
        assertEquals("GEKJIHFDCB", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("C"));
        assertEquals("CGEKJIHFDB", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("E"));
        assertEquals("ECGKJIHFDB", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("J"));
        assertEquals("JECGKIHFDB", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("J"));
        assertEquals("JECGKIHFDB", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("E"));
        assertEquals("EJCGKIHFDB", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("B"));
        assertEquals("BEJCGKIHFD", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("F"));
        assertEquals("FBEJCGKIHD", cache.dumpLruKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
    }
}
