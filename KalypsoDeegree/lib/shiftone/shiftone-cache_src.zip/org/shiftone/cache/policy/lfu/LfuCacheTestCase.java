package org.shiftone.cache.policy.lfu;



import org.shiftone.cache.CacheFactory;
import org.shiftone.cache.util.TestCaseBase;


/**
 * Class LfuCacheTestCase
 *
 *
 * @author <a href="mailto:jeff@shiftone.org">Jeff Drost</a>
 * @version $Revision: 1.2 $
 */
public class LfuCacheTestCase extends TestCaseBase
{

    public LfuCacheTestCase(String name)
    {
        super(name);
    }


    /**
     * Method getCacheFactory
     */
    public CacheFactory getCacheFactory()
    {
        return new LfuCacheFactory();
    }


    /**
     * Method testOne
     */
    public void testLfu10()
    {

        LfuCache cache = new LfuCache("lfu", 5000, 10);

        cache.addObject("A", "A");    //1
        assertEquals("A", cache.dumpLfuKeys());
        assertEquals("A", cache.dumpFifoKeys());
        cache.addObject("B", "B");    //2
        assertEquals("BA", cache.dumpLfuKeys());
        assertEquals("BA", cache.dumpFifoKeys());
        cache.addObject("C", "C");    //3
        assertEquals("CBA", cache.dumpLfuKeys());
        assertEquals("CBA", cache.dumpFifoKeys());
        cache.addObject("D", "D");    //4
        assertEquals("DCBA", cache.dumpLfuKeys());
        assertEquals("DCBA", cache.dumpFifoKeys());
        cache.addObject("E", "E");    //5
        assertEquals("EDCBA", cache.dumpLfuKeys());
        assertEquals("EDCBA", cache.dumpFifoKeys());
        cache.addObject("F", "F");    //6
        assertEquals("FEDCBA", cache.dumpLfuKeys());
        assertEquals("FEDCBA", cache.dumpFifoKeys());
        cache.addObject("G", "G");    //7
        assertEquals("GFEDCBA", cache.dumpLfuKeys());
        assertEquals("GFEDCBA", cache.dumpFifoKeys());
        cache.addObject("H", "H");    //8
        assertEquals("HGFEDCBA", cache.dumpLfuKeys());
        assertEquals("HGFEDCBA", cache.dumpFifoKeys());
        cache.addObject("I", "I");    //9
        assertEquals("IHGFEDCBA", cache.dumpLfuKeys());
        assertEquals("IHGFEDCBA", cache.dumpFifoKeys());
        cache.addObject("J", "J");    //10
        assertEquals("JIHGFEDCBA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());

        // observe the effect of getObject
        assertNotNull(cache.getObject("E"));
        assertEquals("EJIHGFDCBA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("H"));
        assertEquals("HEJIGFDCBA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("H"));
        assertEquals("HEJIGFDCBA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("B"));
        assertEquals("HBEJIGFDCA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("G"));
        assertEquals("HGBEJIFDCA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("G"));
        assertEquals("GHBEJIFDCA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("G"));
        assertEquals("GHBEJIFDCA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("E"));
        assertEquals("GEHBJIFDCA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("B"));
        assertEquals("GBEHJIFDCA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("I"));
        assertEquals("GBEHIJFDCA", cache.dumpLfuKeys());
        assertEquals("JIHGFEDCBA", cache.dumpFifoKeys());

        // observe the effect of adding more nodes
        cache.addObject("K", "K");
        assertEquals("GBEHIKJFDC", cache.dumpLfuKeys());
        assertEquals("KJIHGFEDCB", cache.dumpFifoKeys());
        cache.addObject("L", "L");
        assertEquals("GBEHILKJFD", cache.dumpLfuKeys());
        assertEquals("LKJIHGFEDB", cache.dumpFifoKeys());
        cache.addObject("M", "M");
        assertEquals("GBEHIMLKJF", cache.dumpLfuKeys());
        assertEquals("MLKJIHGFEB", cache.dumpFifoKeys());
        cache.addObject("N", "N");
        assertEquals("GBEHINMLKJ", cache.dumpLfuKeys());
        assertEquals("NMLKJIHGEB", cache.dumpFifoKeys());
        cache.addObject("O", "O");
        assertEquals("GBEHIONMLK", cache.dumpLfuKeys());
        assertEquals("ONMLKIHGEB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("O"));
        assertEquals("GBEHOINMLK", cache.dumpLfuKeys());
        assertEquals("ONMLKIHGEB", cache.dumpFifoKeys());
        cache.addObject("P", "P");
        assertEquals("GBEHOIPNML", cache.dumpLfuKeys());
        assertEquals("PONMLIHGEB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("P"));
        assertEquals("GBEHPOINML", cache.dumpLfuKeys());
        assertEquals("PONMLIHGEB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("P"));
        assertEquals("GPBEHOINML", cache.dumpLfuKeys());
        assertEquals("PONMLIHGEB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("P"));
        assertEquals("PGBEHOINML", cache.dumpLfuKeys());
        assertEquals("PONMLIHGEB", cache.dumpFifoKeys());
        assertNotNull(cache.getObject("P"));
        assertEquals("PGBEHOINML", cache.dumpLfuKeys());
        assertEquals("PONMLIHGEB", cache.dumpFifoKeys());
        cache.addObject("Q", "Q");
        assertEquals("PGBEHOIQNM", cache.dumpLfuKeys());
        assertEquals("QPONMIHGEB", cache.dumpFifoKeys());
    }
}
