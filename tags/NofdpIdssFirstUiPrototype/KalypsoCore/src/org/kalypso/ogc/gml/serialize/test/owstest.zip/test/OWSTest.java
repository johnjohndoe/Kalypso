package org.kalypso.ogc.gml.serialize.test;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import junit.framework.TestCase;

import org.apache.commons.io.IOUtils;
import org.deegree.services.OGCWebServiceEvent;
import org.deegree.services.wfs.capabilities.WFSCapabilities;
import org.deegree.services.wfs.filterencoding.Filter;
import org.deegree.services.wfs.protocol.WFSGetFeatureRequest;
import org.deegree.services.wfs.protocol.WFSQuery;
import org.deegree_impl.services.OGCWebServiceEvent_Impl;
import org.deegree_impl.services.wfs.RemoteWFService;
import org.deegree_impl.services.wfs.capabilities.WFSCapabilitiesFactory;
import org.deegree_impl.services.wfs.filterencoding.ComplexFilter;
import org.deegree_impl.services.wfs.filterencoding.OperationDefines;
import org.deegree_impl.services.wfs.protocol.WFSGetFeatureRequest_Impl;
import org.deegree_impl.services.wfs.protocol.WFSProtocolFactory;
import org.deegree_impl.tools.Debug;
import org.kalypso.ogc.gml.serialize.GmlSerializer;
import org.kalypso.ogc.gml.typehandler.DiagramTypeHandler;
import org.kalypso.ogc.sensor.deegree.ObservationLinkHandler;
import org.kalypsodeegree.gml.GMLFeature;
import org.kalypsodeegree.model.feature.Feature;
import org.kalypsodeegree.model.feature.FeatureType;
import org.kalypsodeegree.model.feature.GMLWorkspace;
import org.kalypsodeegree_impl.extension.ITypeRegistry;
import org.kalypsodeegree_impl.extension.TypeRegistrySingleton;
import org.kalypsodeegree_impl.gml.GMLDocument_Impl;
import org.kalypsodeegree_impl.gml.schema.GMLSchema;
import org.kalypsodeegree_impl.gml.schema.GMLSchemaCache;
import org.kalypsodeegree_impl.model.cs.ConvenienceCSFactory;
import org.kalypsodeegree_impl.model.feature.FeatureFactory;
import org.kalypsodeegree_impl.model.feature.GMLWorkspace_Impl;
import org.opengis.cs.CS_CoordinateSystem;
import org.w3c.dom.Document;

public class OWSTest extends TestCase
{

  final String wfsURL = "http://134.28.87.71:8080/deegreewms/wfs";

  final String wmsURL = "http://134.28.87.71:8080/deegreewms/wms";

  final String resGetCap = "d://temp//GetCapabilitiesResponse.xml";

  final String resDescFT = "d://temp//DescribeFTResponse.xml";

  final String resGetFeature = "d://temp//GetFeatureResponse.xml";

  final String featureTypeName = "ueberschwemmung10";

  boolean gmlTest = false;

  boolean getCapaTest = true;

  private boolean descFtTest = false;

  private boolean getFeatTest = false;

  private boolean gmlSchemaTest = false;

  private boolean buildFeatureRequest = false;

  private boolean gmlSerializerTest = false;

  private boolean xsltTransformGetFeature = false;

  private int counter = 0;

  private final String VERSION = "1.0.0";

  private final String HANDEL = String.valueOf( System.currentTimeMillis() );

  private final String FORMAT = "GML2";

  public void testHandler() throws Exception
  {

    if( getCapaTest == true )
      getCapabilitiesTest();
    if( descFtTest == true )
      describeFeatureTypeTest();
    if( getFeatTest == true )
      getFeatureTest();
    if( gmlTest == true )
    {
      CS_CoordinateSystem cs1 = ConvenienceCSFactory.getInstance().getOGCCSByName( "EPSG:31469" );
      CS_CoordinateSystem cs2 = ConvenienceCSFactory.getInstance().getOGCCSByName( "EPSG:4326" );
      System.out.println("cs1: "  + cs1.getName() + "\tcs2: " + cs2.getName());
      
      InputStream is = getClass().getResourceAsStream( "resources/GetFeatureResponse.gml" );
      URL url = new URL(
          "http://134.28.87.71:8080/deegreewms/wfs?SERVICE=WFS&VERSION=1.0.0&REQUEST=DescribeFeatureType&typeName=ueberschwemmung10" );
      // InputStream is =
      // getClass().getResourceAsStream("resources/modell.gml");
      // URL url = getClass().getResource("resources/namodell.xsd");
      gmlSerializerTest( is, url );
    }
    if( gmlSchemaTest == true )
    {
      // URL url = getClass().getResource("resources/namodell.xsd");
      // URL url = getClass().getResource("resources/feature.xsd");
      URL url = getClass().getResource( "resources/DescribeFTResponse.xsd" );
      gmlSchemaTest( url );
    }
    if( buildFeatureRequest )
    {
      buildGetFeatureRequest();
    }
    if( gmlSerializerTest )
    {
      gmlSerializerTest( getClass().getResourceAsStream( "resources/featureRequest.xml" ),
          getClass().getResource( "resources/DescribeFTResponse.xsd" ) );
    }
    if( xsltTransformGetFeature )
    {
      InputStream is = getClass().getResourceAsStream( "resources/GetFeatureResponse.xml" );
      URL xsltURL = getClass().getResource( "resources/transform.xsl" );
      URL schemaURL = getClass().getResource( "resources/DescribeFTResponse.xsd" );
      StringBuffer sb = new StringBuffer();
      int index = 0;
      while( ( index = is.read() ) >= 0 )
      {
        sb.append( (char)index );
      }
      xsltTransformGetFeature( sb.toString(), xsltURL, schemaURL );
    }
  }

  private void gmlSchemaTest( URL url )
  {
    try
    {

      final ITypeRegistry registry = TypeRegistrySingleton.getTypeRegistry();
      registry.registerTypeHandler( new ObservationLinkHandler() );
      registry.registerTypeHandler( new DiagramTypeHandler() );

      final GMLSchema schema = GMLSchemaCache.getSchema( url );
      if( schema == null )
        throw new Exception( "Schema konnte nicht gefunden werden." );

      // create feature and workspace gml
      final FeatureType[] types = schema.getFeatureTypes();
      System.out.println( "no. of Errors: " + counter );

    }
    catch( Exception e )
    {
      e.printStackTrace();
      System.out.println( "no. of Errors: " + counter );
    }

  }// gmlSchemaTest

  public void getCapabilitiesTest()
  {
    try
    {

      final URL urlGetCap = new URL( wfsURL + "?"
          + "SERVICE=WFS&VERSION=1.0.0&REQUEST=GetCapabilities" );
      final URLConnection conGetCap = urlGetCap.openConnection();
      conGetCap.addRequestProperty( "SERVICE", "WFS" );
      conGetCap.addRequestProperty( "VERSION", "1.0.0" );
      conGetCap.addRequestProperty( "REQUEST", "GetCapabilities" );
      InputStream isGetCap = conGetCap.getInputStream();

      //      if( isGetCap.available() > 0 )
      //      {
              WFSCapabilities caps = WFSCapabilitiesFactory.createCapabilities( new
       InputStreamReader(
                  isGetCap ) );
      //      }
      File capResponse = new File( resGetCap );
      if( capResponse.exists() )
        capResponse.delete();

      FileWriter fileWriterGetCap = new FileWriter( capResponse, true );
      int index = 0;
      while( ( index = isGetCap.read() ) >= 0 )
      {
        fileWriterGetCap.write( (char)index );
      }
      fileWriterGetCap.close();
      System.out.println( "no. of Errors: " + counter );
    }
    catch( Exception e )
    {
      e.printStackTrace();
      counter++;
      System.out.println( "no. of Errors: " + counter );
    }
  }// testGetCapabilites

  public void describeFeatureTypeTest()
  {
    try
    {

      final URL urlDescribeFT = new URL( wfsURL + "?"
          + "SERVICE=WFS&VERSION=1.0.0&REQUEST=DescribeFeatureType&typeName=" + featureTypeName );
      final URLConnection conDesFT = urlDescribeFT.openConnection();
      conDesFT.addRequestProperty( "SERVICE", "WFS" );
      conDesFT.addRequestProperty( "VERSION", "1.0.0" );
      conDesFT.addRequestProperty( "REQUEST", "DescribeFeatureType" );
      conDesFT.addRequestProperty( "typeName", featureTypeName );
      InputStream isDesFT = conDesFT.getInputStream();

      File descFTResponse = new File( resDescFT );
      if( descFTResponse.exists() )
        descFTResponse.delete();

      FileWriter fileWriterDescFT = new FileWriter( descFTResponse, true );
      int index = 0;
      while( ( index = isDesFT.read() ) >= 0 )
      {
        fileWriterDescFT.write( (char)index );
      }
      fileWriterDescFT.close();
      System.out.println( "no. of Errors: " + counter );
    }
    catch( Exception e )
    {
      e.printStackTrace();
      counter++;
      System.out.println( "no. of Errors: " + counter );
    }
  }// testDescribeFeatureType

  public void getFeatureTest()
  {
    try
    {

      URL url = new URL( wfsURL );

      StringBuffer sb = new StringBuffer();
      sb.append( "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n" );
      sb.append( "<GetFeature outputFormat=\"GML2\" xmlns:gml=\"http://www.opengis.net/gml\">\n" );
      sb.append( "<Query typeName=\"" + featureTypeName + "\">\n" );
      sb.append( "<Filter>\n" );
      sb.append( "</Filter>\n" );
      sb.append( "</Query>" );
      sb.append( "</GetFeature>" );

      URLConnection conGetFeature = url.openConnection();
      conGetFeature.setDoOutput( true );
      conGetFeature.setDoInput( true );

      // write request to the server
      PrintStream psGetFeature = new PrintStream( conGetFeature.getOutputStream() );
      psGetFeature.print( sb.toString() );
      psGetFeature.close();

      File featureResponse = new File( resGetFeature );
      if( featureResponse.exists() )
        featureResponse.delete();

      InputStream isGetFeature = conGetFeature.getInputStream();

      FileWriter fileWriterGetFeature = new FileWriter( featureResponse );
      int i = 0;
      while( ( i = isGetFeature.read() ) >= 0 )
      {
        fileWriterGetFeature.write( (char)i );
      }
      fileWriterGetFeature.close();

      System.out.println( "no. of Errors: " + counter );

    }
    catch( Exception e )
    {
      e.printStackTrace();
      counter++;
      System.out.println( "no. of Errors: " + counter );
    }
  }// testGetFeature

  public void gmlSerializerTest( InputStream is, URL schemaURL )
  {
    try
    {

      final ITypeRegistry registry = TypeRegistrySingleton.getTypeRegistry();
      registry.registerTypeHandler( new ObservationLinkHandler() );
      registry.registerTypeHandler( new DiagramTypeHandler() );

      if( is != null && is.available() > 0 )
      {
        GMLWorkspace workspace = GmlSerializer.createGMLWorkspace( is, schemaURL );
        Writer writer = new StringWriter();
        GmlSerializer.serializeWorkspace( writer, workspace );
        IOUtils.closeQuietly( writer );
        System.out.println( writer.toString() );
      }

      System.out.println( "no. of Errors: " + counter );
    }
    catch( Exception e )
    {
      e.printStackTrace();
      counter++;
      System.out.println( "no. of Errors: " + counter );
    }
  }// testGMLSerializer

  public void buildGetFeatureRequest() throws Exception
  {
    try
    {
      URL url = new URL( wfsURL );
      URLConnection conGetFeature = url.openConnection();
      conGetFeature.setDoOutput( true );
      conGetFeature.setDoInput( true );
      OGCWebServiceEvent event1 = getOGCWebEvent();
      // write request to the server
      PrintStream psGetFeature = new PrintStream( conGetFeature.getOutputStream() );
      psGetFeature.print( event1.getRequest() );
      psGetFeature.close();

      InputStreamReader isr = new InputStreamReader( conGetFeature.getInputStream() );

      System.out.println( "stop" );
    }
    catch( Exception e )
    {
      e.printStackTrace();
    }

    try
    {
      final URL urlGetCap = new URL( wfsURL + "?"
          + "SERVICE=WFS&VERSION=1.0.0&REQUEST=GetCapabilities" );

      final URLConnection conGetCap = urlGetCap.openConnection();
      conGetCap.addRequestProperty( "SERVICE", "WFS" );
      conGetCap.addRequestProperty( "VERSION", "1.0.0" );
      conGetCap.addRequestProperty( "REQUEST", "GetCapabilities" );
      InputStream isGetCap = conGetCap.getInputStream();
      Reader reader = new InputStreamReader( isGetCap );

      WFSCapabilities caps = WFSCapabilitiesFactory.createCapabilities( reader );

      OGCWebServiceEvent event = getOGCWebEvent();

      RemoteWFService service = new RemoteWFService( caps );
      service.doService( event );

    }
    catch( Exception e )
    {
      e.printStackTrace();
    }

  }

  private OGCWebServiceEvent getOGCWebEvent() throws Exception
  {
    WFSQuery[] query =
    {
      WFSProtocolFactory.createQuery( null, HANDEL, VERSION, featureTypeName, null )
    };
    Filter filter = new ComplexFilter( OperationDefines.AND );
    System.out.println( filter.toXML() );
    WFSGetFeatureRequest getfeatureRequest = WFSProtocolFactory.createWFSGetFeatureRequest(
        VERSION, featureTypeName + HANDEL, null, null, FORMAT, HANDEL, filter, 1000, 0, query );
    System.out.println( ( (WFSGetFeatureRequest_Impl)getfeatureRequest ).exportAsXML() );

    return new OGCWebServiceEvent_Impl( this, getfeatureRequest, "wfsReqest" );
  }

  /**
   * transforms the response to a GetRecord/Feature request using a predefined
   * xslt-stylesheet
   */
  private Document xsltTransformGetFeature( String gml, URL xsltURL, URL schemaURL )
  {
    Debug.debugMethodBegin( this, "xsltTransformGetFeature" );

    Document document = null;

    try
    {
      document = org.deegree.xml.XMLTools.parse( new StringReader( gml ) );

      // Use the static TransformerFactory.newInstance() method to instantiate
      // a TransformerFactory. The javax.xml.transform.TransformerFactory
      // system property setting determines the actual class to instantiate --
      // org.apache.xalan.transformer.TransformerImpl.
      TransformerFactory tFactory = TransformerFactory.newInstance();

      // Use the TransformerFactory to instantiate a Transformer that will work
      // with
      // the stylesheet you specify. This method call also processes the
      // stylesheet
      // into a compiled Templates object.
      URL url = xsltURL;
      Transformer transformer = tFactory.newTransformer( new StreamSource( url.openStream() ) );

      // Use the Transformer to apply the associated Templates object to an XML
      // document
      // (foo.xml) and write the output to a file (foo.out).
      StringWriter sw = new StringWriter();
      transformer.transform( new DOMSource( document ), new StreamResult( sw ) );

      document = org.deegree.xml.XMLTools.parse( new StringReader( sw.toString() ) );

      // load gml
      final GMLDocument_Impl gmlDoc = new GMLDocument_Impl( document );

      final GMLFeature gmlFeature = gmlDoc.getRootFeature();

      // load schema
      final GMLSchema schema = GMLSchemaCache.getSchema( schemaURL );

      // create feature and workspace gml
      final FeatureType[] types = schema.getFeatureTypes();
      final Feature feature = FeatureFactory.createFeature( gmlFeature, types );

      // nicht die echte URL der schemaLocation, sondern dass, was im gml steht!
      final String schemaLocationName = gmlDoc.getSchemaLocationName();
      URL context = new URL( "http://www.context.de" );
      GMLWorkspace_Impl workspace = new GMLWorkspace_Impl( types, feature, context,
          schemaLocationName, schema.getTargetNS(), schema.getNamespaceMap() );
      FileWriter writer = new FileWriter( "d://workspaceAfterTransformation.xml" );
      GmlSerializer.serializeWorkspace( writer, workspace );
      System.out.println( "stop" );
    }
    catch( Exception e )
    {
      Debug.debugException( e, "an error/fault body for the soap message will be created" );
      //TODO exception
    }

    Debug.debugMethodEnd();
    return document;
  }

}// OWSTest
