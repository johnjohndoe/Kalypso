


/*
 * The JTS Topology Suite is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.operation.buffer;

/**
 * LineFilter implements a filter that removes small loops from the line created
 * by BufferLineBuilder
 *
 * @version 1.3
 */
import java.util.*;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.util.*;

import com.vividsolutions.jts.graph.*;

public class LoopFilter {

  private static final Coordinate[] arrayTypeCoordinate = new Coordinate[0];

  private int maxPointsInLoop = 10;           // maximum number of points in a loop
  private double maxLoopExtent = 10.0;    // the maximum X and Y extents of a loop

  private List newPts = new ArrayList();

  public LoopFilter() {
  }

  public Coordinate[] filter(Coordinate[] inputPts)
  {
    newPts.clear();
    int i = 0;
    while (i < inputPts.length) {
      addPoint(inputPts[i]);
      int loopSize = checkForLoop(inputPts, i);
      // skip loop if one was found
      i++;
      if (loopSize > 0) {
Assert.isTrue(inputPts[i - 1].equals(inputPts[i - 1 + loopSize]), "non-loop found in LoopFilter");
        i += loopSize;
      }
    }
    return (Coordinate[]) newPts.toArray(arrayTypeCoordinate);
  }

  private void addPoint(Coordinate p)
  {
    // don't add duplicate points
    if (newPts.size() >= 1 && newPts.get(newPts.size() - 1).equals(p))
      return;
    newPts.add(p);
  }
  /**
   * Find a small loop starting at this point, if one exists.
   * If found, return the index of the last point of the loop.
   * If none exists, return 0
   */
  private int checkForLoop(Coordinate[] pts, int startIndex)
  {
    Coordinate startPt = pts[startIndex];
    Envelope env = new Envelope();
    env.expandToInclude(startPt);
    int endIndex = startIndex;
    for (int j = 1; j <= maxPointsInLoop; j++) {
      endIndex = startIndex + j;
      if (endIndex >= pts.length) break;

      env.expandToInclude(pts[endIndex]);
      if (pts[endIndex].equals(startPt)) {
        if (env.getHeight() < maxLoopExtent && env.getWidth() < maxLoopExtent) {
          return j;
        }
      }
    }
    return 0;
  }

}
