

/*
 * The JTS Topology Suite is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.geom;

import java.io.Serializable;

import com.vividsolutions.jts.util.Assert;
/**
 *  Converts a coordinate to and from a "precise" coordinate; that is, one whose
 *  precision is known exactly. In other words, specifies the grid of allowable
 *  points for all <code>Geometry</code>s. <P>
 *
 *  Vertices are assumed to be precise in JTS. That is, the coordinates of
 *  vertices are assumed to be rounded to the defined precision model. Input
 *  routines will be responsible for rounding coordinates to the precision model
 *  before creating JTS structures. Non-constructive internal operations will
 *  assume that coordinates are rounded to the precision model. <P>
 *
 *  JTS methods do not handle inputs with different precision models. <P>
 *
 *  The Precision Model is be specified by a scale factor.
 *  The scale factor specifies the grid which numbers are rounded to.
 *  World coordinates are mapped to JTS coordinates according to the following
 *  equations:
 *  <UL>
 *    <LI> jtsPt.x = round( (inputPt.x * scale ) / scale
 *    <LI> jtsPt.y = round( (inputPt.y * scale ) / scale
 *  </UL>
 *  Coordinates are be represented as double-precision values.
 * Since Java uses the IEEE-394 floating point standard, this
 *  provides 53 bits of precision. (Thus the maximum precisely representable
 *  integer is 9,007,199,254,740,992).
 *
 *@version 1.3
 */
public class PrecisionModel implements Serializable, Comparable
{
  /**
   * The types of Precision Model which could be implemented.
   * (Note that JTS does not necessarily support all of these.)
   */
   /**
    * Fixed Precision implies that coordinates have a fixed number of decimal places
    */
  public final static int FIXED     = 1;
  /**
   * Floating precision corresponds to the usual notion of floating-point representation.
   */
  public final static int FLOATING  = 2;

  /**
   *  The maximum precise value representable in a double. Since IEE754
   *  double-precision numbers allow 53 bits of mantissa, the value is equal to
   *  2^53 - 1.
   */
  public final static double maximumPreciseValue = 9007199254740992.0;

  /**
   * The type of PrecisionModel this represents.
   */
  private int modelType = 0;
  /**
   * Amount by which to multiply a coordinate after subtracting the offset,
   * to obtain a precise coordinate.
   * If scale is 0, this PrecisionModel represents a floating precision model.
   * Coordinates are left with the implicit precision of the
   * floating-point representation.
   */
  private double scale;
  /**
   *  Amount by which to subtract the x-coordinate before multiplying by the
   *  scale, to obtain a precise coordinate.  NO LONGER USED.
   */
  private double offsetX;
  /**
   *  Amount by which to subtract the y-coordinate before multiplying by the
   *  scale, to obtain a precise coordinate.  NO LONGER USED.
   */
  private double offsetY;

  /**
   *  Creates a <code>PrecisionModel</code> that specifies Floating precision.
   *
   */
  public PrecisionModel() {
    // default is floating precision
    modelType = FLOATING;
  }

  /**
   *  Creates a <code>PrecisionModel</code> that specifies Fixed precision.
   *  Fixed-precision coordinates are represented as precise internal coordinates,
   *  which are rounded to the grid defined by the scale factor.
   *
   *@param  scale    amount by which to multiply a coordinate after subtracting
   *      the offset, to obtain a precise coordinate
   *@param  offsetX  not used.
   *@param  offsetY  not used.
   *
   * @deprecated
   */
  public PrecisionModel(double scale, double offsetX, double offsetY) {
    modelType = FIXED;
    setScale(scale);
    this.offsetX = offsetX;
    this.offsetY = offsetY;
  }
  /**
   *  Creates a <code>PrecisionModel</code> that specifies Fixed precision.
   *  Fixed-precision coordinates are represented as precise internal coordinates,
   *  which are rounded to the grid defined by the scale factor.
   *
   *@param  scale    amount by which to multiply a coordinate after subtracting
   *      the offset, to obtain a precise coordinate
   */
  public PrecisionModel(double scale) {
    modelType = FIXED;
    setScale(scale);
    this.offsetX = 0;
    this.offsetY = 0;
  }
  /**
   *  Copy constructor to create a new <code>PrecisionModel</code>
   *  from an existing one.
   */
  public PrecisionModel(PrecisionModel pm) {
    modelType = pm.modelType;
    scale = pm.scale;
    offsetX = pm.offsetX;
    offsetY = pm.offsetY;
  }


  public boolean isFloating()
  {
    return modelType == FLOATING;
  }
  /**
   *  Returns the multiplying factor used to obtain a precise coordinate.
   * This method is private because PrecisionModel is intended to
   * be an immutable (value) type.
   *
   *@return    the amount by which to multiply a coordinate after subtracting
   *      the offset
   */
  public double getScale() {
    return scale;
  }

  /**
   *  Sets the multiplying factor used to obtain a precise coordinate.
   * This method is private because PrecisionModel is intended to
   * be an immutable (value) type.
   *
   */
  private void setScale(double scale)
  {
    this.scale = Math.abs(scale);
  }
  /**
   *  Returns the x-offset used to obtain a precise coordinate.
   *
   *@return    the amount by which to subtract the x-coordinate before
   *      multiplying by the scale
   */
  public double getOffsetX() {
    return offsetX;
  }

  /**
   *  Returns the y-offset used to obtain a precise coordinate.
   *
   *@return    the amount by which to subtract the y-coordinate before
   *      multiplying by the scale
   */
  public double getOffsetY() {
    return offsetY;
  }

  /**
   *  Sets <code>internal</code> to the precise representation of <code>external</code>.
   *
   * @param external the original coordinate
   * @param internal the coordinate whose values will be changed to the
   *                 precise representation of <code>external</code>
   * @deprecated
   */
  public void toInternal (Coordinate external, Coordinate internal) {
    if (isFloating()) {
      internal.x = external.x;
      internal.y = external.y;
    }
    else {
      internal.x = makePrecise(external.x);
      internal.y = makePrecise(external.y);
    }
    internal.z = external.z;
  }

  /**
   *  Returns the precise representation of <code>external</code>.
   *
   *@param  external  the original coordinate
   *@return           the coordinate whose values will be changed to the precise
   *      representation of <code>external</code>
   * @deprecated
   */
  public Coordinate toInternal(Coordinate external) {
    Coordinate internal = new Coordinate();
    toInternal(external, internal);
    return internal;
  }

  /**
   *  Returns the external representation of <code>internal</code>.
   *
   *@param  internal  the original coordinate
   *@return           the coordinate whose values will be changed to the
   *      external representation of <code>internal</code>
   * @deprecated
   */
  public Coordinate toExternal(Coordinate internal) {
    Coordinate external = new Coordinate();
    toExternal(internal, external);
    return external;
  }

  /**
   *  Sets <code>external</code> to the external representation of <code>internal</code>
   *  .
   *
   *@param  internal  the original coordinate
   *@param  external  the coordinate whose values will be changed to the
   *      external representation of <code>internal</code>
   * @deprecated
   */
  public void toExternal(Coordinate internal, Coordinate external) {
      external.x = internal.x;
      external.y = internal.y;
  }

  /**
   * Rounds an numeric value to the PrecisionModel grid.
   */
  public double makePrecise(double val)
  {
    return Math.rint(val * scale) / scale;
  }

  /**
   * Rounds a Coordinate to the PrecisionModel grid.
   */
  public void makePrecise(Coordinate coord)
  {
    if (modelType == FLOATING) return;
    coord.x = makePrecise(coord.x);
    coord.y = makePrecise(coord.y);
  }

  public String toString()
  {
    String description;
    if (isFloating()) {
      description = "Floating";
    }
    else {
      description = "Fixed ( Scale = " + getScale();
      //description += "   Offset: X = " + getOffsetX();
      //description += ", Y = " + getOffsetY();
      description += " )";
    }
    return description;
  }
  public boolean equals(Object other) {
    if (! (other instanceof PrecisionModel)) {
      return false;
    }
    PrecisionModel otherPrecisionModel = (PrecisionModel) other;
    return modelType == otherPrecisionModel.modelType
        && offsetX == otherPrecisionModel.offsetX
        && offsetY == otherPrecisionModel.offsetY
        && scale == otherPrecisionModel.scale;
  }
  /**
   *  Compares this {@link PrecisionModel} object with the specified object for order.
   * A PrecisionModel is greater than another if it provides greater precision.
   *
   *@param  o  the <code>PrecisionModel</code> with which this <code>PrecisionModel</code>
   *      is being compared
   *@return    a negative integer, zero, or a positive integer as this <code>PrecisionModel</code>
   *      is less than, equal to, or greater than the specified <code>PrecisionModel</code>
   */
  public int compareTo(Object o) {
    PrecisionModel other = (PrecisionModel) o;

    if (modelType == FLOATING && other.modelType == FLOATING) return 0;
    if (modelType == FLOATING && other.modelType != FLOATING) return 1;
    if (modelType != FLOATING && other.modelType == FLOATING) return -1;
    if (modelType == FIXED && other.modelType == FIXED) {
      if (scale > other.scale)
        return 1;
      else if (scale < other.scale)
        return -1;
      else
        return 0;
    }
    Assert.shouldNeverReachHere("Unknown Precision Model type encountered");
    return 0;
  }
}


