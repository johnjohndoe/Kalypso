


/*
 * The JTS Topology Suite is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.operation.relate;

/**
 * @version 1.3
 */

import com.vividsolutions.jts.graph.*;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.operation.GeometryGraphOperation;
import java.util.*;

/**
 * Implements the relate() operation on {@link Geometry}s.
 * <p>
 * </b>
 * WARNING: The current implementation of this class will compute a result for
 * GeometryCollections.  However, the semantics of this operation are
 * not well-defined and the value returned may not represent
 * an appropriate notion of relate.
 * </b>
 */
public class RelateOp
  extends GeometryGraphOperation
{
  private static List toList(Geometry geom)
  {
    List geomList = new ArrayList();
    return addToList(geom, geomList);
  }

  private static List addToList(Geometry geom, List geomList)
  {
    if (isBaseGeometryCollection(geom)) {
      GeometryCollection gc = (GeometryCollection) geom;
      for (int i = 0; i < gc.getNumGeometries(); i++) {
        addToList(gc.getGeometryN(i), geomList);
      }
    }
    else
      geomList.add(geom);
    return geomList;
  }

  private static boolean isBaseGeometryCollection(Geometry geom)
  {
    return geom.getClass() == GeometryCollection.class;
  }

  public static IntersectionMatrix relate(Geometry a, Geometry b)
  {
    if (isBaseGeometryCollection(a) || isBaseGeometryCollection(b)) {
      return relateGC(toList(a), toList(b));
    }
    else {
      RelateOp relOp = new RelateOp(a, b);
      IntersectionMatrix im = relOp.getIntersectionMatrix();
      return im;
    }
  }

  /**
   * Implements relate on GeometryCollections as the sum of
   * the Intersection matrices for the components of the
   * collection(s).
   * This may or may not be appropriate semantics for this operation.
   * @param a a List of Geometries, none of which are a basic GeometryCollection
   * @param b a List of Geometries, none of which are a basic GeometryCollection
   * @return the matrix representing the topological relationship of the geometries
   */
  private static IntersectionMatrix relateGC(List a, List b)
  {
    IntersectionMatrix finalIM = new IntersectionMatrix();
    for (Iterator i = a.iterator(); i.hasNext(); ) {
      Geometry aGeom = (Geometry) i.next();
      for (Iterator j = b.iterator(); j.hasNext(); ) {
        Geometry bGeom = (Geometry) j.next();
        RelateOp relOp = new RelateOp(aGeom, bGeom);
        IntersectionMatrix im = relOp.getIntersectionMatrix();
        finalIM.add(im);
      }
    }
    return finalIM;
  }

  private RelateComputer relate;

  public RelateOp(Geometry g0, Geometry g1) {
    super(g0, g1);
    relate = new RelateComputer(arg);
  }

  public IntersectionMatrix getIntersectionMatrix()
  {
    return relate.computeIM();
  }

}
