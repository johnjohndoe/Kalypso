

/*
 * The JTS Topology Suite is a collection of Java classes that
 * implement the fundamental operations required to validate a given
 * geo-spatial data set to a known topological specification.
 *
 * Copyright (C) 2001 Vivid Solutions
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * For more information, contact:
 *
 *     Vivid Solutions
 *     Suite #1A
 *     2328 Government Street
 *     Victoria BC  V8T 5G5
 *     Canada
 *
 *     (250)385-6040
 *     www.vividsolutions.com
 */
package com.vividsolutions.jts.operation.buffer;

/**
 * @version 1.3
 */

import java.util.*;
import com.vividsolutions.jts.geom.*;


import com.vividsolutions.jts.graph.*;
import com.vividsolutions.jts.graph.index.SegmentIntersector;
import com.vividsolutions.jts.operation.overlay.*;

import com.vividsolutions.jts.operation.GeometryGraphOperation;

public class BufferOp
  extends GeometryGraphOperation
{
  public static Geometry bufferOp(Geometry g, double distance)
  {
    BufferOp gBuf = new BufferOp(g);
    Geometry geomBuf = gBuf.getResultGeometry(distance);
    return geomBuf;
  }

  public static Geometry bufferOp(Geometry g, double distance, int quadrantSegments)
  {
    BufferOp gBuf = new BufferOp(g);
    Geometry geomBuf = gBuf.getResultGeometry(distance, quadrantSegments);
    return geomBuf;
  }
  /**
   * Compute the change in depth as an edge is crossed from R to L
   */
  private static int depthDelta(Label label)
  {
    int lLoc = label.getLocation(0, Position.LEFT);
    int rLoc = label.getLocation(0, Position.RIGHT);
    if (lLoc == Location.INTERIOR && rLoc == Location.EXTERIOR)
      return 1;
    else if (lLoc == Location.EXTERIOR && rLoc == Location.INTERIOR)
      return -1;
    return 0;
  }
  private GeometryFactory geomFact;
  private Geometry resultGeom;
  private PlanarGraph graph;
  private EdgeList edgeList     = new EdgeList();

  public BufferOp(Geometry g0) {
    super(g0);
    graph = new PlanarGraph(new OverlayNodeFactory());
    geomFact = new GeometryFactory( g0.getPrecisionModel(),
                                        g0.getSRID() );
  }

  public Geometry getResultGeometry(double distance)
  {
    computeBuffer(distance, BufferLineBuilder.DEFAULT_QUADRANT_SEGMENTS);
    return resultGeom;
  }

  public Geometry getResultGeometry(double distance, int quadrantSegments)
  {
    computeBuffer(distance, quadrantSegments);
    return resultGeom;
  }

  private void computeBuffer(double distance, int quadrantSegments)
  {
    BufferEdgeBuilder bufEdgeBuilder = new BufferEdgeBuilder(cga, li, distance, resultPrecisionModel, quadrantSegments);
    List bufferEdgeList = bufEdgeBuilder.getEdges(getArgGeometry(0));

// DEBUGGING ONLY
//WKTWriter wktWriter = new WKTWriter();
//Debug.println("Rings: " + wktWriter.write(toLineStrings(bufferEdgeList.iterator())));

    List nodedEdges = nodeEdges(bufferEdgeList);
    //TESTING - node again to ensure edges are noded completely
    /*
    List nodedEdges2 = nodeEdges(nodedEdges);
    List nodedEdges3 = nodeEdges(nodedEdges2);
    List nodedEdges4 = nodeEdges(nodedEdges3);
    List nodedEdges5 = nodeEdges(nodedEdges4);
    List nodedEdges6 = nodeEdges(nodedEdges5);
  */
    for (Iterator i = nodedEdges.iterator(); i.hasNext(); ) {
      Edge e = (Edge) i.next();
      insertEdge(e);
    }
    replaceCollapsedEdges();

// DEBUGGING ONLY
//Debug.println("Noded: " + wktWriter.write(toLineStrings(edgeList.iterator())));

    graph.addEdges(edgeList);

    List subgraphList = createSubgraphs();
    PolygonBuilder polyBuilder = new PolygonBuilder(geomFact, cga);
    buildSubgraphs(subgraphList, polyBuilder);
    List resultPolyList = polyBuilder.getPolygons();

    resultGeom = computeGeometry(resultPolyList);
    //computeBufferLine(graph);
  }
  /**
   * Use a GeometryGraph to node the created edges,
   * and create split edges between the nodes
   */
  private List nodeEdges(List edges)
  {
    // intersect edges again to ensure they are noded correctly
    GeometryGraph graph = new GeometryGraph(0, geomFact.getPrecisionModel(), 0);
    for (Iterator i = edges.iterator(); i.hasNext(); ) {
      Edge e = (Edge) i.next();
      graph.addEdge(e);
    }
    SegmentIntersector si = graph.computeSelfNodes(li, false);
/*
if (si.hasProperIntersection())
Debug.println("proper intersection found");
else
Debug.println("no proper intersection found");
*/
    List newEdges = new ArrayList();
    graph.computeSplitEdges(newEdges);
    return newEdges;
  }
  /**
   * Inserted edges are checked identical edge already exists.
   * If so, the edge is not inserted, but its label is merged
   * with the existing edge.
   */
  protected void insertEdge(Edge e)
  {
//Debug.println(e);
    int foundIndex = edgeList.findEdgeIndex(e);
    // If an identical edge already exists, simply update its label
    if (foundIndex >= 0) {
      Edge existingEdge = (Edge) edgeList.get(foundIndex);
      Label existingLabel = existingEdge.getLabel();

      Label labelToMerge = e.getLabel();
      // check if new edge is in reverse direction to existing edge
      // if so, must flip the label before merging it
      if (! existingEdge.isPointwiseEqual(e)) {
        labelToMerge = new Label(e.getLabel());
        labelToMerge.flip();
      }
      existingLabel.merge(labelToMerge);

      // compute new depth delta of sum of edges
      int mergeDelta = depthDelta(labelToMerge);
      int existingDelta = existingEdge.getDepthDelta();
      int newDelta = existingDelta + mergeDelta;
      existingEdge.setDepthDelta(newDelta);

      checkDimensionalCollapse(labelToMerge, existingLabel);
//Debug.print("new edge "); Debug.println(e);
//Debug.print("existing "); Debug.println(existingEdge);

    }
    else {   // no matching existing edge was found
      // add this new edge to the list of edges in this graph
      //e.setName(name + edges.size());
      edgeList.add(e);
      e.setDepthDelta(depthDelta(e.getLabel()));
    }
  }
  /**
   * If either of the GeometryLocations for the existing label is
   * exactly opposite to the one in the labelToMerge,
   * this indicates a dimensional collapse has happened.
   * In this case, convert the label for that Geometry to a Line label
   */
  private void checkDimensionalCollapse(Label labelToMerge, Label existingLabel)
  {
    if (existingLabel.isArea() && labelToMerge.isArea()) {
      for (int i = 0; i < 2; i++) {
        if (! labelToMerge.isNull(i)
            &&  labelToMerge.getLocation(i, Position.LEFT)  == existingLabel.getLocation(i, Position.RIGHT)
            &&  labelToMerge.getLocation(i, Position.RIGHT) == existingLabel.getLocation(i, Position.LEFT) )
        {
          existingLabel.toLine(i);
        }
      }
    }
  }
  /**
   * If collapsed edges are found, replace them with a new edge which is a L edge
   */
  private void replaceCollapsedEdges()
  {
    List newEdges = new ArrayList();
    for (Iterator it = edgeList.iterator(); it.hasNext(); ) {
      Edge e = (Edge) it.next();
      if (e.isCollapsed()) {
//Debug.print(e);
        it.remove();

        newEdges.add(e.getCollapsedEdge());
      }
    }
    edgeList.addAll(newEdges);
  }

  private List createSubgraphs()
  {
    List subgraphList = new ArrayList();
    for (Iterator i = graph.getNodes().iterator(); i.hasNext(); ) {
      Node node = (Node) i.next();
      if (! node.isVisited()) {
        BufferSubgraph subgraph = new BufferSubgraph(cga);
        subgraph.create(node);
        subgraphList.add(subgraph);
      }
    }
    /**
     * Sort the subgraphs in descending order of their rightmost coordinate.
     * This ensures that when the Polygons for the subgraphs are built,
     * subgraphs for shells will have been built before the subgraphs for
     * any holes they contain.
     */
    Collections.sort(subgraphList, Collections.reverseOrder());
    return subgraphList;
  }

  private void buildSubgraphs(List subgraphList, PolygonBuilder polyBuilder)
  {
    for (Iterator i = subgraphList.iterator(); i.hasNext(); ) {
      BufferSubgraph subgraph = (BufferSubgraph) i.next();
      Coordinate p = subgraph.getRightmostCoordinate();
      int outsideDepth = 0;
      if (polyBuilder.containsPoint(p))
        outsideDepth = 1;
      subgraph.computeDepth(outsideDepth);
      subgraph.findResultEdges();

      polyBuilder.add(subgraph.getDirectedEdges(), subgraph.getNodes());
    }
  }

  private Geometry computeGeometry(List resultPolyList)
  {
    return geomFact.buildGeometry(resultPolyList);
  }

  /**
   * toLineStrings converts a list of Edges to LineStrings.
   */
  private Geometry toLineStrings(Iterator edges)
  {
    List geomList = new ArrayList();
    while  (edges.hasNext()) {
      Edge e = (Edge) edges.next();
      Coordinate[] pts = e.getCoordinates();
      LineString line = geomFact.createLineString(pts);
      geomList.add(line);
    }
    Geometry geom = geomFact.buildGeometry(geomList);
    return geom;
  }



}
