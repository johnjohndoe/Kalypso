//$HeadURL: $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.crs.exceptions;

import org.deegree.crs.coordinatesystems.CoordinateSystem;

/**
 * The <code>TransformationException</code> class can be thrown if a transformation exception occurs. For example
 * in the process of creating a transformation step.
 * 
 * @author <a href="mailto:bezema@lat-lon.de">Rutger Bezema</a>
 * 
 * @author last edited by: $Author:$
 * 
 * @version $Revision:$, $Date:$
 * 
 */

public class TransformationException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1475176551325426832L;

    /**
     * 
     */
    public TransformationException() {
        // nottin
    }

    /**
     * @param message
     */
    public TransformationException( String message ) {
        super( message );
    }

    /**
     * @param cause
     */
    public TransformationException( Throwable cause ) {
        super( cause );
    }

    /**
     * @param message
     * @param cause
     */
    public TransformationException( String message, Throwable cause ) {
        super( message, cause );
    }

    /**
     * @param sourceCS
     *            from which crs
     * @param targetCS
     *            to which crs
     * @param cause
     *            for the exception.
     */
    public TransformationException( CoordinateSystem sourceCS, CoordinateSystem targetCS, String cause ) {
        super( new StringBuilder( "Can't transform from: " ).append( sourceCS.getIdentifier() )
                                                            .append( " into " )
                                                            .append( targetCS.getIdentifier() )
                                                            .append( " because: " )
                                                            .append( cause )
                                                            .toString() );
    }

}
