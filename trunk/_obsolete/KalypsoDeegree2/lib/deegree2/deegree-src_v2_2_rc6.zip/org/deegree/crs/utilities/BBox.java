//$HeadURL: $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.crs.utilities;

import javax.vecmath.Point2d;
import javax.vecmath.Point3d;

/**
 * The <code>BBox</code> class TODO add documentation here
 * 
 * @author <a href="mailto:bezema@lat-lon.de">Rutger Bezema</a>
 * 
 * @author last edited by: $Author:$
 * 
 * @version $Revision:$, $Date:$
 * 
 */

public class BBox {

    private double[] min = null;

    private double[] max = null;

    private int dimension;

    /**
     * @param min
     *            the minimum of tis bbox
     * @param max
     *            the maximum of this bbox
     */
    public BBox( Point3d min, Point3d max ) {
        this.min = new double[] { min.x, min.y, min.z };
        this.max = new double[] { max.x, max.y, max.z };
        dimension = 3;
    }

    /**
     * @param min
     *            the minimum of tis bbox
     * @param max
     *            the maximum of this bbox
     */
    public BBox( Point2d min, Point2d max ) {
        this.min = new double[] { min.x, min.y };
        this.max = new double[] { max.x, max.y };
        dimension = 2;
    }

    /**
     * @return the distance between the min.x and the max.x
     */
    public double getWidth() {
        return max[0] - min[0];
    }

    /**
     * @return the distance between the min.y and the max.y
     */
    public double getHeight() {
        return max[1] - min[1];
    }

    /**
     * @return the distance between the min.z and the max.z (if any) else Double.NAN
     */
    public double getDepth() {
        if ( min.length == 2 ) {
            return Double.NaN;
        }
        return max[2] - min[2];
    }

    /**
     * @param dimension
     *            to get the length for
     * @return the length of given dimension.
     */
    public double getLength( int dimension ) {
        return max[dimension] - min[dimension];
    }

    /**
     * @return the max.
     */
    public final double[] getMax() {
        return max;
    }

    /**
     * @return the min.
     */
    public final double[] getMin() {
        return min;
    }

    /**
     * @param dimension
     *            to return the minimum value for.
     * @return the minimal ordinate along the specified dimension.
     */
    public double getMinimum( final int dimension ) {
        return min[dimension];
    }

    /**
     * @param dimension
     *            to return the minimum value for.
     * 
     * @return the maximal ordinate along the specified dimension.
     */
    public double getMaximum( final int dimension ) {
        return max[dimension];
    }

    /**
     * @return the dimension of this bbox.
     */
    public int getDimension() {
        return dimension;
    }

}
