//$HeadURL: svn+ssh://rbezema@svn.wald.intevation.org/deegree/base/trunk/src/org/deegree/model/csct/ct/MatrixTransform.java $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/
package org.deegree.crs.transformations;

// Geometry
import java.util.ArrayList;
import java.util.List;

import javax.vecmath.GMatrix;
import javax.vecmath.Matrix3d;
import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;

import org.deegree.crs.coordinatesystems.CoordinateSystem;
import org.deegree.crs.projections.ProjectionUtils;
import org.deegree.crs.utilities.Matrix;

/**
 * 
 * The <code>MatrixTransform</code> class allows transformations using matrices. Although technically n &times; m
 * matrices are possible, at the moment only 2 &times; 2, 3 &times; 3 and 4 &times; 4 matrices are supported.
 * 
 * @author <a href="mailto:bezema@lat-lon.de">Rutger Bezema</a>
 * 
 * @author last edited by: $Author:$
 * 
 * @version $Revision:$, $Date:$
 * 
 */
public class MatrixTransform extends CRSTransformation {
    /**
     * Serial number for interoperability with different versions.
     */
    private static final long serialVersionUID = -2104496465933824935L;

    /**
     * the number of rows.
     */
    private final int numRow;

    /**
     * the number of columns.
     */
    private final int numCol;

    private GMatrix matrix = null;

    private GMatrix invertMatrix = null;

    private Matrix3d matrix3D = null;

    private Matrix3d invertMatrix3D = null;

    private Matrix4d matrix4D = null;

    private Matrix4d invertMatrix4D = null;

    /**
     * Set super values and numRow,numCol.
     * 
     * @param source
     * @param target
     * @param identifier
     * @param name
     * @param numRow
     * @param numCol
     */
    private MatrixTransform( CoordinateSystem source, CoordinateSystem target, String identifier, String name,
                             int numRow, int numCol ) {
        super( source, target, identifier, name, null, null, null );
        this.numCol = numCol;
        this.numRow = numRow;
    }

    /**
     * Construct a transform.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     * @param identifier
     * @param name
     *            of the transformation
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, final GMatrix matrix, String identifier,
                            String name ) {
        this( source, target, identifier, name, matrix.getNumRow(), matrix.getNumCol() );
        this.matrix = new GMatrix( matrix );
        invertMatrix = new GMatrix( matrix );
        invertMatrix.invert();
    }

    /**
     * Construct a transform with name set to 'Matrix-Transform'.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     * @param identifier
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, final GMatrix matrix, String identifier ) {
        this( source, target, matrix, identifier, "Matrix-Transform" );
    }

    /**
     * Construct a transform with id set to {@link CRSTransformation#createFromTo(String, String)} and name to
     * 'Matrix-Transform'.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, final GMatrix matrix ) {
        this( source, target, matrix, createFromTo( source.getIdentifier(), target.getIdentifier() ) );
    }

    /**
     * Construct a 3d transform.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     * @param identifier
     * @param name
     *            of the transformation
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, final Matrix3d matrix, String identifier,
                            String name ) {
        this( source, target, identifier, name, 3, 3 );
        this.matrix3D = new Matrix3d( matrix );
        invertMatrix3D = new Matrix3d();
        invertMatrix3D.invert( matrix3D );
    }

    /**
     * Construct a 3d transform with name set to 'Matrix-Transform'.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     * @param identifier
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, final Matrix3d matrix, String identifier ) {
        this( source, target, matrix, identifier, "Matrix-Transform" );
    }

    /**
     * Construct a 3d transform with id set to {@link CRSTransformation#createFromTo(String, String)} and name to
     * 'Matrix-Transform'.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, Matrix3d matrix ) {
        this( source, target, matrix, createFromTo( source.getIdentifier(), target.getIdentifier() ) );
    }

    /**
     * Construct a 4d transform.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     * @param identifier
     * @param name
     *            of this transform
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, Matrix4d matrix, String identifier,
                            String name ) {
        this( source, target, identifier, name, 4, 4 );
        matrix4D = new Matrix4d( matrix );
        invertMatrix4D = new Matrix4d();
        invertMatrix4D.invert( matrix4D );
    }

    /**
     * Construct a 4d transform with name set to 'Matrix-Transform'.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     * @param identifier
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, Matrix4d matrix, String identifier ) {
        this( source, target, matrix, identifier, "Matrix-Transform" );
    }

    /**
     * Construct a 4d transform with id set to {@link CRSTransformation#createFromTo(String, String)} and name to
     * 'Matrix-Transform'.
     * 
     * @param source
     *            the source coordinate system
     * @param target
     *            the target coordinate system.
     * 
     * @param matrix
     */
    public MatrixTransform( CoordinateSystem source, CoordinateSystem target, Matrix4d matrix ) {
        this( source, target, matrix, createFromTo( source.getIdentifier(), target.getIdentifier() ) );
    }

    @Override
    public List<Point3d> doTransform( List<Point3d> srcPts ) {
        if ( isIdentity() ) {
            return srcPts;
        }
        // System.out.println( "The matrix is a: " + ( ( matrix3D != null ) ? "Matrix3D"
        // : ( ( matrix4D != null ) ? "Matrix4D"
        // : "customMatrix" ) )
        // + " with following values:\n"
        // + ( ( matrix3D != null ) ? matrix3D : ( ( matrix4D != null ) ? matrix4D : matrix ) ) );
        List<Point3d> results = new ArrayList<Point3d>( srcPts );
        if ( isInverseTransform() ) {
            // System.out.println( "A inverse matrix transform with incoming points: " + srcPts );
            if ( matrix3D != null ) {
                transform( invertMatrix3D, results );
            } else if ( matrix4D != null ) {
                transform( invertMatrix4D, results );
            } else {
                transform( invertMatrix, results );
            }
        } else {
            // System.out.println( "A matrix transform with incoming points: " + srcPts );
            if ( matrix3D != null ) {
                transform( matrix3D, results );
            } else if ( matrix4D != null ) {
                transform( matrix4D, results );
            } else {
                transform( matrix, results );
            }
        }
        return results;
    }

    /**
     * @return the dimension of input points.
     */
    public int getDimSource() {
        return numCol - 1;
    }

    /**
     * @return the dimension of output points.
     */
    public int getDimTarget() {
        return numRow - 1;
    }

    /**
     * @return true if this transformation holds an identiy matrix (e.g. doesn't transform at all).
     */
    @Override
    public boolean isIdentity() {
        if ( numRow != numCol ) {
            return false;
        }
        for ( int row = 0; row < numRow; row++ )
            for ( int col = 0; col < numCol; col++ ) {
                double value = ( matrix3D != null ) ? matrix3D.getElement( row, col )
                                                   : ( ( matrix4D != null ) ? matrix4D.getElement( row, col )
                                                                           : matrix.getElement( row, col ) );
                if ( Math.abs( value - ( col == row ? 1 : 0 ) ) > ProjectionUtils.EPS11 ) {
                    return false;
                }
            }
        return true;
        // return true;
    }

    @Override
    public boolean equals( final Object object ) {
        if ( object == this ) {
            return true; // Slight optimization
        }
        if ( object != null && super.equals( object ) ) {
            return matrix.equals( ( (MatrixTransform) object ).matrix );
        }
        return false;
    }

    /**
     * Transforms an array of floating point coordinates by this matrix. Point coordinates must have a dimension equals
     * to <code>{@link Matrix#getNumCol()}-1</code>. For example, for square matrix of size 4&times;4, coordinate
     * points are three-dimensional and stored in the arrays starting at the specified offset (<code>srcOff</code>)
     * in the order <code>[x<sub>0</sub>, y<sub>0</sub>, z<sub>0</sub>,
     *        x<sub>1</sub>, y<sub>1</sub>, z<sub>1</sub>...,
     *        x<sub>n</sub>, y<sub>n</sub>, z<sub>n</sub>]</code>.
     * 
     * The transformed points <code>(x',y',z')</code> are computed as below (note that this computation is similar to
     * {@link PerspectiveTransform}):
     * 
     * <blockquote> <code>
     * <pre>
     *    [ u ]     [ m&lt;sub&gt;00&lt;/sub&gt;  m&lt;sub&gt;01&lt;/sub&gt;  m&lt;sub&gt;02&lt;/sub&gt;  m&lt;sub&gt;03&lt;/sub&gt; ] [ x ]
     *    [ v ]  =  [ m&lt;sub&gt;10&lt;/sub&gt;  m&lt;sub&gt;11&lt;/sub&gt;  m&lt;sub&gt;12&lt;/sub&gt;  m&lt;sub&gt;13&lt;/sub&gt; ] [ y ]
     *    [ w ]     [ m&lt;sub&gt;20&lt;/sub&gt;  m&lt;sub&gt;21&lt;/sub&gt;  m&lt;sub&gt;22&lt;/sub&gt;  m&lt;sub&gt;23&lt;/sub&gt; ] [ z ]
     *    [ t ]     [ m&lt;sub&gt;30&lt;/sub&gt;  m&lt;sub&gt;31&lt;/sub&gt;  m&lt;sub&gt;32&lt;/sub&gt;  m&lt;sub&gt;33&lt;/sub&gt; ] [ 1 ]
     *                         
     *     x' = u/t
     *     y' = v/t
     *     w' = w/t
     * </pre>
     * </code> </blockquote>
     * 
     * @param srcPts
     *            The array containing the source point coordinates.
     */
    private void transform( GMatrix gm, List<Point3d> srcPts ) {
        throw new UnsupportedOperationException( "not yet implemented" );
        // final int inputDimension = numCol - 1; // The last value will be assumed equals to 1.
        // final int outputDimension = numRow - 1;
        // final double[] buffer = new double[numRow];
        // while ( --numPts >= 0 ) {
        // int mix = 0;
        // for ( int j = 0; j < numRow; j++ ) {
        // // double sum = elt[mix + inputDimension];
        // // for ( int i = 0; i < inputDimension; i++ ) {
        // // sum += srcPts[srcOff + i] * elt[mix++];
        // // }
        // // buffer[j] = sum;
        // mix++;
        // }
        // final double w = buffer[outputDimension];
        // for ( int j = 0; j < outputDimension; j++ ) {
        // // 'w' is equals to 1 if the transform is affine.
        // dstPts[dstOff++] = buffer[j] / w;
        // }
        // srcOff += inputDimension;
        // }

    }

    /**
     * Use the given GMatrix to transform the given points inplace.
     * 
     * @param m4d
     *            the matrix to use (e.g. the inverse matrix or the forward matrix.
     * @param srcPts
     *            The array containing the source point coordinates.
     */
    private void transform( Matrix4d m4d, List<Point3d> srcPts ) {
        for ( Point3d p : srcPts ) {
            m4d.transform( p );
        }
    }

    /**
     * Use the given GMatrix to transform the given points inplace.
     * 
     * @param m4d
     *            the matrix to use (e.g. the inverse matrix or the forward matrix.
     * @param srcPts
     *            The array containing the source point coordinates.
     */
    private void transform( Matrix3d m3d, List<Point3d> srcPts ) {
        for ( Point3d p : srcPts ) {
            m3d.transform( p );
        }
    }

    /**
     * @return the matrix.
     */
    public final GMatrix getMatrix() {
        if ( matrix != null ) {
            return isInverse ? invertMatrix : matrix;
        }
        GMatrix result = new GMatrix( numRow, numCol );
        if ( matrix3D != null ) {
            if ( isInverse ) {
                result.set( invertMatrix3D );
            } else {
                result.set( matrix3D );
            }
        }
        if ( matrix4D != null ) {
            if ( isInverse ) {
                result.set( invertMatrix4D );
            } else {
                result.set( matrix4D );
            }
        }
        return result;
    }

}
