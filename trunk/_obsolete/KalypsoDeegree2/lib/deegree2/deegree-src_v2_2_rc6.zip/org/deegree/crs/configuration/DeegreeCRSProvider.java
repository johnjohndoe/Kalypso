//$HeadURL: $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.crs.configuration;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.vecmath.Point2d;

import org.deegree.crs.Identifiable;
import org.deegree.crs.components.Axis;
import org.deegree.crs.components.Ellipsoid;
import org.deegree.crs.components.GeodeticDatum;
import org.deegree.crs.components.PrimeMeridian;
import org.deegree.crs.components.Unit;
import org.deegree.crs.coordinatesystems.CoordinateSystem;
import org.deegree.crs.coordinatesystems.GeocentricCRS;
import org.deegree.crs.coordinatesystems.GeographicCRS;
import org.deegree.crs.coordinatesystems.ProjectedCRS;
import org.deegree.crs.exceptions.CRSConfigurationException;
import org.deegree.crs.projections.Projection;
import org.deegree.crs.projections.ProjectionUtils;
import org.deegree.crs.projections.azimuthal.LambertAzimuthalEqualArea;
import org.deegree.crs.projections.azimuthal.StereographicAzimuthal;
import org.deegree.crs.projections.conic.LambertConformalConic;
import org.deegree.crs.projections.cylindric.TransverseMercator;
import org.deegree.crs.transformations.WGS84ConversionInfo;
import org.deegree.datatypes.QualifiedName;
import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.framework.xml.NamespaceContext;
import org.deegree.framework.xml.XMLFragment;
import org.deegree.framework.xml.XMLParsingException;
import org.deegree.framework.xml.XMLTools;
import org.deegree.i18n.Messages;
import org.deegree.ogcbase.CommonNamespaces;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

/**
 * The <code>DeegreeCRSProvider</code> reads the deegree crs-config (based on it's own xml-schema) and creates the
 * CRS's (and their datums, conversion info's, ellipsoids and projections) if requested.
 * <p>
 * Attention, although urn's are case-sensitive, the deegreeCRSProvider is not. All incoming id's are toLowerCased!
 * </p>
 * 
 * @author <a href="mailto:bezema@lat-lon.de">Rutger Bezema</a>
 * 
 * @author last edited by: $Author:$
 * 
 * @version $Revision:$, $Date:$
 * 
 */

public class DeegreeCRSProvider implements CRSProvider {

    private static ILogger LOG = LoggerFactory.getLogger( DeegreeCRSProvider.class );

    /**
     * The standard configuration file, points to deegree-crs-configuration.xml.
     */
    private static final String STANDARD_CONFIG = "deegree-crs-configuration.xml";

    /**
     * The mamespaces used in deegree.
     */
    private static NamespaceContext nsContext = CommonNamespaces.getNamespaceContext();

    /**
     * The prefix to use.
     */
    private final static String PRE = CommonNamespaces.CRS_PREFIX + ":";

    /**
     * The namespace to use.
     */
    private final static String CRS_URI = CommonNamespaces.CRSNS.toASCIIString();

    /**
     * The EPSG-Database defines only 48 different ellipsoids, set to 60, will --probably-- result in no collisions.
     */
    private final Map<String, Ellipsoid> ellipsoids = new HashMap<String, Ellipsoid>( 60 );

    /**
     * The EPSG-Database defines over 400 different Geodetic Datums, set to 450, will --probably-- result in no
     * collisions.
     */
    private final Map<String, GeodeticDatum> datums = new HashMap<String, GeodeticDatum>( 450 );

    /**
     * The EPSG-Database defines over 1100 different CoordinateTransformations, set to 1200, will --probably-- result in
     * no collisions.
     */
    private final Map<String, WGS84ConversionInfo> conversionInfos = new HashMap<String, WGS84ConversionInfo>( 1200 );

    /**
     * Theoretically infinite prime meridians could be defined, let's set it to a more practical number of 42.
     */
    private final Map<String, PrimeMeridian> primeMeridians = new HashMap<String, PrimeMeridian>( 42 );

    /**
     * The EPSG-Database defines over 2960 different ProjectedCRS's, set to 3500, will --probably-- result in no
     * collisions.
     */
    private final Map<String, Projection> projections = new HashMap<String, Projection>( 3500 );

    /**
     * The EPSG-Database defines over 2960 different ProjectedCRS's, set to 3500, will --probably-- result in no
     * collisions.
     */
    private final Map<String, ProjectedCRS> projectedCRSs = new HashMap<String, ProjectedCRS>( 3500 );

    /**
     * The EPSG-Database defines over 490 different GeographicCRS's (geodetic), set to 600, will --probably-- result in
     * no collisions.
     */
    private final Map<String, GeographicCRS> geographicCRSs = new HashMap<String, GeographicCRS>( 600 );

    /**
     * The EPSG-Database doesn't define GeocentricCRS's, set to 30, will --probably-- result in no collisions.
     */
    private final Map<String, GeocentricCRS> geocentricCRSs = new HashMap<String, GeocentricCRS>( 30 );

    private final List<GeographicCRS> cachedGeoCRSs = new ArrayList<GeographicCRS>( 3000 );

    private final Map<String, String> doubleGeos = new HashMap<String, String>( 3000 );

    private final List<GeodeticDatum> cachedDatums = new ArrayList<GeodeticDatum>( 3000 );

    private final Map<String, String> doubleDatums = new HashMap<String, String>( 3000 );

    private final List<WGS84ConversionInfo> cachedToWGS = new ArrayList<WGS84ConversionInfo>( 3000 );

    private final Map<String, String> doubleToWGS = new HashMap<String, String>( 3000 );

    private final List<Ellipsoid> cachedEllipsoids = new ArrayList<Ellipsoid>( 3000 );

    private final Map<String, String> doubleEllipsoids = new HashMap<String, String>( 3000 );

    private final List<PrimeMeridian> cachedMeridans = new ArrayList<PrimeMeridian>( 3000 );

    private final Map<String, String> doubleMeridians = new HashMap<String, String>( 3000 );

    private final List<Projection> cachedProjections = new ArrayList<Projection>( 3000 );

    private final Map<String, String> doubleProjections = new HashMap<String, String>( 3000 );

    /**
     * The root element of the deegree - crs - configuration.
     */
    private Element rootElement;

    private boolean checkForDoubleDefinition = false;

    /**
     * Empty constructor may only be used for exporting, other usage will result in undefined behavior.
     */
    public DeegreeCRSProvider() {
        Document doc = XMLTools.create();
        rootElement = doc.createElementNS( CommonNamespaces.CRSNS.toASCIIString(), PRE + "definitions" );
        rootElement = (Element) doc.importNode( rootElement, false );
        rootElement = (Element) doc.appendChild( rootElement );
    }

    /**
     * @param f
     *            to load coordinate system definitions from if null, the standard configuration file will be used, by
     *            searching '/' first and if unsuccessful in org.deegree.crs.configuration.
     * @throws CRSConfigurationException
     *             if the give file or the default-crs-configuration.xml file could not be loaded.
     */
    public DeegreeCRSProvider( File f ) throws CRSConfigurationException {
        InputStream is = null;
        if ( f == null ) {
            LOG.logDebug( "No configuration file given, trying to load standard-crs-configurtiion.xml" );
            is = DeegreeCRSProvider.class.getResourceAsStream( "/" + STANDARD_CONFIG );
            if ( is == null ) {
                is = DeegreeCRSProvider.class.getResourceAsStream( STANDARD_CONFIG );
            }
            if ( is == null ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_NO_DEFAULT_CONFIG_FOUND" ) );
            }
        } else {
            LOG.logDebug( "Trying to load configuration from file: " + f.getAbsoluteFile() );
            try {
                is = new FileInputStream( f );
            } catch ( FileNotFoundException e ) {
                throw new CRSConfigurationException( e );
            }
        }
        if ( is == null ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_NO_CONFIG_FOUND" ) );
        }
        Reader read = new BufferedReader( new InputStreamReader( is ) );
        try {
            XMLFragment configDocument = new XMLFragment( read, XMLFragment.DEFAULT_URL );
            rootElement = configDocument.getRootElement();
        } catch ( MalformedURLException e ) {
            throw new CRSConfigurationException( e );
        } catch ( IOException e ) {
            throw new CRSConfigurationException( e );
        } catch ( SAXException e ) {
            throw new CRSConfigurationException( e );
        } finally {
            try {
                read.close();
            } catch ( IOException e ) {
                // could not close the stream, just leave it as it is.
            }
        }
    }

    public boolean canExport() {
        return true;
    }

    public synchronized CoordinateSystem getCRSByID( String crsId )
                                                                   throws CRSConfigurationException {
        if ( crsId != null && !"".equals( crsId.trim() ) ) {

            crsId = crsId.toUpperCase().trim();
            LOG.logDebug( "Trying to load crs with id: " + crsId + " from cache." );
            if ( geographicCRSs.containsKey( crsId ) && geographicCRSs.get( crsId ) != null ) {
                return geographicCRSs.get( crsId );
            } else if ( projectedCRSs.containsKey( crsId ) && projectedCRSs.get( crsId ) != null ) {
                return projectedCRSs.get( crsId );
            } else if ( geocentricCRSs.containsKey( crsId ) && geocentricCRSs.get( crsId ) != null ) {
                return geocentricCRSs.get( crsId );
            }
            LOG.logDebug( "No crs with id: " + crsId + " found in cache." );
            if ( rootElement == null ) {
                this.notifyAll();
                return null;
            }
            Element crsElement = getTopElementFromID( crsId );
            if ( crsElement == null ) {
                LOG.logDebug( "The requested crs id: " + crsId
                              + " could not be mapped to a configured CoordinateSystem." );
                this.notifyAll();
                return null;
            }
            String crsType = crsElement.getLocalName();
            if ( crsType == null || "".equals( crsType.trim() ) ) {
                LOG.logDebug( "The requested crs id: " + crsId
                              + " could not be mapped to a configured CoordinateSystem." );
                this.notifyAll();
                return null;
            }
            if ( "geographicCRS".equalsIgnoreCase( crsType ) ) {
                return parseGeographicCRS( crsElement );
            } else if ( "projectedCRS".equalsIgnoreCase( crsType ) ) {
                return parseProjectedCRS( crsElement );
            } else if ( "geocentricCRS".equalsIgnoreCase( crsType ) ) {
                return parseGeocentricCRS( crsElement );
            }
        }
        LOG.logDebug( "The id: " + crsId
                      + " could not be mapped to a valid deegreec-crs, currently projectedCRS, geographicCRS and geocentricCRS are supported." );
        return null;
    }

    public void export( StringBuilder sb, List<CoordinateSystem> crsToExport ) {
        if ( crsToExport != null ) {
            if ( crsToExport.size() != 0 ) {
                LOG.logDebug( "Trying to export: " + crsToExport.size() + " coordinate systems." );
                XMLFragment frag = new XMLFragment( new QualifiedName( "crs", "definitions", CommonNamespaces.CRSNS ) );
                Element root = frag.getRootElement();
                ArrayList<String> exportedIDs = new ArrayList<String>( crsToExport.size() );
                for ( CoordinateSystem crs : crsToExport ) {
                    if ( crs.getType() == CoordinateSystem.GEOCENTRIC_CRS ) {
                        export( (GeocentricCRS) crs, root, exportedIDs );
                    } else if ( crs.getType() == CoordinateSystem.GEOGRAPHIC_CRS ) {
                        export( (GeographicCRS) crs, root, exportedIDs );
                    } else if ( crs.getType() == CoordinateSystem.PROJECTED_CRS ) {
                        export( (ProjectedCRS) crs, root, exportedIDs );
                    }
                }
                root.normalize();
                Document validDoc = createValidDocument( root );
                try {
                    XMLFragment frag2 = new XMLFragment( validDoc, "http://www.deegree.org/crs" );
                    sb.append( frag2.getAsPrettyString() );
                } catch ( MalformedURLException e ) {
                    LOG.logError( "Could not export crs definitions because: " + e.getMessage(), e );
                }
            } else {
                LOG.logWarning( "No coordinate system were given (list.size() == 0)." );
            }
        } else {
            LOG.logError( "No coordinate system were given (list == null)." );
        }
    }

    public List<CoordinateSystem> getAvailableCRSs()
                                                    throws CRSConfigurationException {
        List<CoordinateSystem> allSystems = new ArrayList<CoordinateSystem>( 10000 );
        if ( rootElement != null ) {
            List<Element> allCRSIDs = new ArrayList<Element>( 10000 );

            try {
                allCRSIDs.addAll( XMLTools.getElements( rootElement,
                                                        "//" + PRE + "geographicCRS/" + PRE + "id[1]",
                                                        nsContext ) );
                allCRSIDs.addAll( XMLTools.getElements( rootElement,
                                                        "//" + PRE + "projectedCRS/" + PRE + "id[1]",
                                                        nsContext ) );
                allCRSIDs.addAll( XMLTools.getElements( rootElement,
                                                        "//" + PRE + "geocentricCRS/" + PRE + "id[1]",
                                                        nsContext ) );
            } catch ( XMLParsingException e ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_GET_ALL_ELEMENT_IDS",
                                                                          e.getMessage() ), e );
            }
            for ( Element crsID : allCRSIDs ) {
                if ( crsID != null ) {
                    String id = crsID.getTextContent();
                    if ( id != null && !"".equals( id.trim() ) ) {
                        CoordinateSystem crs = getCRSByID( id );
                        if ( crs != null ) {
                            allSystems.add( crs );
                        }
                    }

                }
            }
            allSystems.addAll( geocentricCRSs.values() );
            allSystems.addAll( geographicCRSs.values() );
            allSystems.addAll( projectedCRSs.values() );
            if ( checkForDoubleDefinition ) {
                if ( !doubleGeos.isEmpty() ) {
                    Set<String> keys = doubleGeos.keySet();
                    LOG.logInfo( "Following geographic crs's could probably be mapped on eachother" );
                    for ( String key : keys ) {
                        LOG.logInfo( key + " : " + doubleGeos.get( key ) );
                    }
                }

                if ( !doubleDatums.isEmpty() ) {
                    Set<String> keys = doubleDatums.keySet();
                    LOG.logInfo( "Following datums could probably be mapped on eachother" );
                    for ( String key : keys ) {
                        LOG.logInfo( key + " : " + doubleDatums.get( key ) );
                    }
                }
                if ( !doubleToWGS.isEmpty() ) {
                    Set<String> keys = doubleToWGS.keySet();
                    LOG.logInfo( "Following wgs conversion infos could probably be mapped on eachother" );
                    for ( String key : keys ) {
                        LOG.logInfo( key + " : " + doubleToWGS.get( key ) );
                    }
                }
                if ( !doubleEllipsoids.isEmpty() ) {
                    Set<String> keys = doubleEllipsoids.keySet();
                    LOG.logInfo( "Following ellipsoids could probably be mapped on eachother" );
                    for ( String key : keys ) {
                        LOG.logInfo( key + " : " + doubleEllipsoids.get( key ) );
                    }
                }
                if ( !doubleMeridians.isEmpty() ) {
                    Set<String> keys = doubleEllipsoids.keySet();
                    LOG.logInfo( "Following prime meridians could probably be mapped on eachother" );
                    for ( String key : keys ) {
                        LOG.logInfo( key + " : " + doubleMeridians.get( key ) );
                    }
                }
                if ( !doubleProjections.isEmpty() ) {
                    Set<String> keys = doubleProjections.keySet();
                    LOG.logInfo( "Following projections could probably be mapped on eachother" );
                    for ( String key : keys ) {
                        LOG.logInfo( key + " : " + doubleProjections.get( key ) );
                    }
                }
            }
        } else {
            LOG.logDebug( "The root element is null, is this correct behaviour?" );
        }
        return allSystems;
    }

    private Document createValidDocument( Element root ) {
        // List<Element> lastInput = new ArrayList<Element>( 100 );
        try {
            List<Element> valid = XMLTools.getElements( root, PRE + "ellipsoid", nsContext );
            valid.addAll( XMLTools.getElements( root, PRE + "geodeticDatum", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "lambertAzimuthalEqualArea", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "lambertConformalConic", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "stereographicAzimuthal", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "transverseMercator", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "projectedCRS", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "geographicCRS", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "geocentricCRS", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "primeMeridian", nsContext ) );
            valid.addAll( XMLTools.getElements( root, PRE + "wgs84Transformation", nsContext ) );
            Document doc = XMLTools.create();
            Element newRoot = doc.createElementNS( CommonNamespaces.CRSNS.toASCIIString(), PRE + "definitions" );
            newRoot = (Element) doc.importNode( newRoot, false );
            newRoot = (Element) doc.appendChild( newRoot );
            for ( int i = 0; i < valid.size(); ++i ) {
                Element el = valid.get( i );
                el = (Element) doc.importNode( el, true );
                newRoot.appendChild( el );
            }
            XMLTools.appendNSBinding( newRoot, CommonNamespaces.XSI_PREFIX, CommonNamespaces.XSINS );
            newRoot.setAttributeNS( CommonNamespaces.XSINS.toASCIIString(),
                                    "xsi:schemaLocation",
                                    "http://www.deegree.org/crs c:/windows/profiles/rutger/EIGE~VO5/eclipse-projekte/coordinate_systems/resources/schema/crsdefinition.xsd" );
            return doc;
        } catch ( XMLParsingException xmle ) {
            xmle.printStackTrace();
        }
        return root.getOwnerDocument();
    }

    /**
     * Export the projected CRS to it's appropriate deegree-crs-definitions form.
     * 
     * @param projectedCRS
     *            to be exported
     * @param rootNode
     *            to export the projected CRS to.
     * @param exportedIds
     *            a list of id's already exported.
     */
    private void export( ProjectedCRS projectedCRS, Element rootNode, List<String> exportedIds ) {
        if ( !exportedIds.contains( projectedCRS.getIdentifier() ) ) {
            Element crsElement = XMLTools.appendElement( rootNode, CommonNamespaces.CRSNS, PRE + "projectedCRS" );
            exportAbstractCRS( projectedCRS, crsElement );
            GeographicCRS underLyingCRS = projectedCRS.getGeographicCRS();
            export( underLyingCRS, rootNode, exportedIds );
            export( projectedCRS.getUnits(), crsElement );
            // Add a reference from the geographicCRS element to the projectedCRS element.
            XMLTools.appendElement( crsElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "usedGeographicCRS",
                                    underLyingCRS.getIdentifier() );

            Projection projection = projectedCRS.getProjection();
            export( projection, rootNode, exportedIds );
            // Add a reference from the projection element to the projectedCRS element.
            XMLTools.appendElement( crsElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "usedProjection",
                                    projection.getIdentifier() );

            // Add the ids to the exportedID list.
            for ( String eID : projectedCRS.getIdentifiers() ) {
                exportedIds.add( eID );
            }
            // finally add the crs node to the rootnode.
            rootNode.appendChild( crsElement );
        }
    }

    /**
     * Export the geocentric/geographic CRS to it's appropriate deegree-crs-definitions form.
     * 
     * @param geographicCRS
     *            to be exported
     * @param rootNode
     *            to export the geographic CRS to.
     * @param exportedIds
     *            a list of id's already exported.
     */
    private void export( GeographicCRS geographicCRS, Element rootNode, List<String> exportedIds ) {
        if ( !exportedIds.contains( geographicCRS.getIdentifier() ) ) {
            Element crsElement = XMLTools.appendElement( rootNode, CommonNamespaces.CRSNS, PRE + "geographicCRS" );
            exportAbstractCRS( geographicCRS, crsElement );

            // export the datum.
            GeodeticDatum datum = geographicCRS.getGeodeticDatum();
            if ( datum != null ) {
                export( datum, rootNode, exportedIds );
                // Add a reference from the datum element to the geographic element.
                XMLTools.appendElement( crsElement, CommonNamespaces.CRSNS, PRE + "usedDatum", datum.getIdentifier() );
            }
            // Add the ids to the exportedID list.
            for ( String eID : geographicCRS.getIdentifiers() ) {
                exportedIds.add( eID );
            }
            // finally add the crs node to the rootnode.
            rootNode.appendChild( crsElement );
        }
    }

    /**
     * Export the projection to it's appropriate deegree-crs-definitions form.
     * 
     * @param projection
     *            to be exported
     * @param rootNode
     *            to export the projection to.
     * @param exportedIds
     *            a list of id's already exported.
     */
    private void export( Projection projection, Element rootNode, List<String> exportedIds ) {
        if ( !exportedIds.contains( projection.getIdentifier() ) ) {
            String elementName = projection.getDeegreeSpecificName();
            Element projectionElement = XMLTools.appendElement( rootNode, CommonNamespaces.CRSNS, PRE + elementName );
            exportIdentifiable( projection, projectionElement );
            Element tmp = XMLTools.appendElement( projectionElement,
                                                  CommonNamespaces.CRSNS,
                                                  PRE + "latitudeOfNaturalOrigin",
                                                  Double.toString( Math.toDegrees( projection.getProjectionLatitude() ) ) );
            tmp.setAttribute( "inDegrees", "true" );
            tmp = XMLTools.appendElement( projectionElement,
                                          CommonNamespaces.CRSNS,
                                          PRE + "longitudeOfNaturalOrigin",
                                          Double.toString( Math.toDegrees( projection.getProjectionLongitude() ) ) );
            tmp.setAttribute( "inDegrees", "true" );

            XMLTools.appendElement( projectionElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "scaleFactor",
                                    Double.toString( projection.getScale() ) );
            XMLTools.appendElement( projectionElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "falseEasting",
                                    Double.toString( projection.getFalseEasting() ) );
            XMLTools.appendElement( projectionElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "falseNorthing",
                                    Double.toString( projection.getFalseNorthing() ) );
            if ( "transverseMercator".equalsIgnoreCase( elementName ) ) {
                XMLTools.appendElement( projectionElement,
                                        CommonNamespaces.CRSNS,
                                        PRE + "northernHemisphere",
                                        Boolean.toString( ( (TransverseMercator) projection ).getHemisphere() ) );
            } else if ( "lambertConformalConic".equalsIgnoreCase( elementName ) ) {
                double paralellLatitude = ( (LambertConformalConic) projection ).getFirstParallelLatitude();
                if ( !Double.isNaN( paralellLatitude ) && Math.abs( paralellLatitude ) > ProjectionUtils.EPS11 ) {
                    paralellLatitude = Math.toDegrees( paralellLatitude );
                    tmp = XMLTools.appendElement( projectionElement,
                                                  CommonNamespaces.CRSNS,
                                                  PRE + "firstParallelLatitude",
                                                  Double.toString( paralellLatitude ) );
                    tmp.setAttribute( "inDegrees", "true" );
                }
                paralellLatitude = ( (LambertConformalConic) projection ).getSecondParallelLatitude();
                if ( !Double.isNaN( paralellLatitude ) && Math.abs( paralellLatitude ) > ProjectionUtils.EPS11 ) {
                    paralellLatitude = Math.toDegrees( paralellLatitude );
                    tmp = XMLTools.appendElement( projectionElement,
                                                  CommonNamespaces.CRSNS,
                                                  PRE + "secondParallelLatitude",
                                                  Double.toString( paralellLatitude ) );
                    tmp.setAttribute( "inDegrees", "true" );
                }
            } else if ( "stereographicAzimuthal".equalsIgnoreCase( elementName ) ) {
                tmp = XMLTools.appendElement( projectionElement,
                                              CommonNamespaces.CRSNS,
                                              PRE + "trueScaleLatitude",
                                              Double.toString( ( (StereographicAzimuthal) projection ).getTrueScaleLatitude() ) );
                tmp.setAttribute( "inDegrees", "true" );
            }
        }
    }

    /**
     * Export the confInvo to it's appropriate deegree-crs-definitions form.
     * 
     * @param confInvo
     *            to be exported
     * @param rootNode
     *            to export the confInvo to.
     * @param exportedIds
     *            a list of id's already exported.
     */
    private void export( WGS84ConversionInfo confInvo, Element rootNode, final List<String> exportedIds ) {
        if ( !exportedIds.contains( confInvo.getIdentifier() ) ) {
            Element convElement = XMLTools.appendElement( rootNode, CommonNamespaces.CRSNS, PRE + "wgs84Transformation" );
            exportIdentifiable( confInvo, convElement );

            XMLTools.appendElement( convElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "xAxisTranslation",
                                    Double.toString( confInvo.dx ) );
            XMLTools.appendElement( convElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "yAxisTranslation",
                                    Double.toString( confInvo.dy ) );
            XMLTools.appendElement( convElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "zAxisTranslation",
                                    Double.toString( confInvo.dz ) );
            XMLTools.appendElement( convElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "xAxisRotation",
                                    Double.toString( confInvo.ex ) );
            XMLTools.appendElement( convElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "yAxisRotation",
                                    Double.toString( confInvo.ey ) );
            XMLTools.appendElement( convElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "zAxisRotation",
                                    Double.toString( confInvo.ez ) );
            XMLTools.appendElement( convElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "scaleDifference",
                                    Double.toString( confInvo.ppm ) );

            // Add the ids to the exportedID list.
            for ( String eID : confInvo.getIdentifiers() ) {
                exportedIds.add( eID );
            }

            // finally add the WGS84-Transformation node to the rootnode.
            rootNode.appendChild( convElement );
        }

    }

    /**
     * Export the PrimeMeridian to it's appropriate deegree-crs-definitions form.
     * 
     * @param pMeridian
     *            to be exported
     * @param rootNode
     *            to export the pMeridian to.
     * @param exportedIds
     *            a list of id's already exported.
     */
    private void export( PrimeMeridian pMeridian, Element rootNode, final List<String> exportedIds ) {
        if ( !exportedIds.contains( pMeridian.getIdentifier() ) ) {
            Element meridianElement = XMLTools.appendElement( rootNode, CommonNamespaces.CRSNS, PRE + "primeMeridian" );
            exportIdentifiable( pMeridian, meridianElement );
            export( pMeridian.getAngularUnit(), meridianElement );
            XMLTools.appendElement( meridianElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "longitude",
                                    Double.toString( pMeridian.getLongitude() ) );

            // Add the ids to the exportedID list.
            for ( String eID : pMeridian.getIdentifiers() ) {
                exportedIds.add( eID );
            }

            // finally add the prime meridian node to the rootnode.
            rootNode.appendChild( meridianElement );
        }
    }

    /**
     * Export the ellipsoid to it's appropriate deegree-crs-definitions form.
     * 
     * @param ellipsoid
     *            to be exported
     * @param rootNode
     *            to export the ellipsoid to.
     * @param exportedIds
     *            a list of id's already exported.
     */
    private void export( Ellipsoid ellipsoid, Element rootNode, final List<String> exportedIds ) {
        if ( !exportedIds.contains( ellipsoid.getIdentifier() ) ) {
            Element ellipsoidElement = XMLTools.appendElement( rootNode, CommonNamespaces.CRSNS, PRE + "ellipsoid" );
            exportIdentifiable( ellipsoid, ellipsoidElement );
            XMLTools.appendElement( ellipsoidElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "semiMajorAxis",
                                    Double.toString( ellipsoid.getSemiMajorAxis() ) );
            XMLTools.appendElement( ellipsoidElement,
                                    CommonNamespaces.CRSNS,
                                    PRE + "inverseFlatting",
                                    Double.toString( ellipsoid.getInverseFlattening() ) );
            export( ellipsoid.getUnits(), ellipsoidElement );

            // Add the ids to the exportedID list.
            for ( String eID : ellipsoid.getIdentifiers() ) {
                exportedIds.add( eID );
            }
            // finally add the ellipsoid node to the rootnode.
            rootNode.appendChild( ellipsoidElement );
        }
    }

    /**
     * Export the datum to it's appropriate deegree-crs-definitions form.
     * 
     * @param datum
     *            to be exported
     * @param rootNode
     *            to export the datum to.
     * @param exportedIds
     *            a list of id's already exported.
     */
    private void export( GeodeticDatum datum, Element rootNode, List<String> exportedIds ) {
        if ( !exportedIds.contains( datum.getIdentifier() ) ) {
            Element datumElement = XMLTools.appendElement( rootNode, CommonNamespaces.CRSNS, PRE + "geodeticDatum" );
            exportIdentifiable( datum, datumElement );
            /**
             * EXPORT the ELLIPSOID
             */
            Ellipsoid ellipsoid = datum.getEllipsoid();
            if ( ellipsoid != null ) {
                export( ellipsoid, rootNode, exportedIds );
                // Add a reference from the ellipsoid element to the datum element.
                XMLTools.appendElement( datumElement,
                                        CommonNamespaces.CRSNS,
                                        PRE + "usedEllipsoid",
                                        ellipsoid.getIdentifier() );
            }

            /**
             * EXPORT the PRIME_MERIDIAN
             */
            PrimeMeridian pMeridian = datum.getPrimeMeridian();
            if ( pMeridian != null ) {
                export( pMeridian, rootNode, exportedIds );
                // Add a reference from the prime meridian element to the datum element.
                XMLTools.appendElement( datumElement,
                                        CommonNamespaces.CRSNS,
                                        PRE + "usedPrimeMeridian",
                                        pMeridian.getIdentifier() );
            }

            /**
             * EXPORT the WGS-84-Conversion INFO
             */
            WGS84ConversionInfo confInvo = datum.getWGS84Conversion();
            if ( confInvo != null ) {
                export( confInvo, rootNode, exportedIds );
                // Add a reference from the prime meridian element to the datum element.
                XMLTools.appendElement( datumElement,
                                        CommonNamespaces.CRSNS,
                                        PRE + "usedWGS84ConversionInfo",
                                        confInvo.getIdentifier() );
            }

            // Add the ids to the exportedID list.
            for ( String eID : datum.getIdentifiers() ) {
                exportedIds.add( eID );
            }
            // finally add the datum node to the rootnode.
            rootNode.appendChild( datumElement );
        }
    }

    /**
     * Export toplevel crs features.
     * 
     * @param crs
     *            to be exported
     * @param crsElement
     *            to export to
     */
    private void exportAbstractCRS( CoordinateSystem crs, Element crsElement ) {
        exportIdentifiable( crs, crsElement );
        Axis[] axis = crs.getAxis();
        StringBuilder axisOrder = new StringBuilder( 200 );
        for ( int i = 0; i < axis.length; ++i ) {
            Axis a = axis[i];
            export( a, crsElement );
            axisOrder.append( a.getName() );
            if ( ( i + 1 ) < axis.length ) {
                axisOrder.append( ", " );
            }
        }
        XMLTools.appendElement( crsElement, CommonNamespaces.CRSNS, PRE + "axisOrder", axisOrder.toString() );

    }

    /**
     * Export the geocentric CRS to it's appropriate deegree-crs-definitions form.
     * 
     * @param geocentricCRS
     *            to be exported
     * @param rootNode
     *            to export the geocentric CRS to.
     * @param exportedIds
     *            a list of id's already exported.
     */
    private void export( GeocentricCRS geocentricCRS, Element rootNode, List<String> exportedIds ) {
        if ( !exportedIds.contains( geocentricCRS.getIdentifier() ) ) {
            Element crsElement = XMLTools.appendElement( rootNode, CommonNamespaces.CRSNS, PRE + "geocentricCRS" );
            exportAbstractCRS( geocentricCRS, crsElement );
            // export the datum.
            GeodeticDatum datum = geocentricCRS.getGeodeticDatum();
            if ( datum != null ) {
                export( datum, rootNode, exportedIds );
                // Add a reference from the datum element to the geocentric element.
                XMLTools.appendElement( crsElement, CommonNamespaces.CRSNS, PRE + "usedDatum", datum.getIdentifier() );
            }
            // Add the ids to the exportedID list.
            for ( String eID : geocentricCRS.getIdentifiers() ) {
                exportedIds.add( eID );
            }
            // finally add the crs node to the rootnode.
            rootNode.appendChild( crsElement );
        }
    }

    /**
     * Creates the basic nodes of the identifiable object.
     * 
     * @param id
     *            object to be exported.
     * @param currentNode
     *            to expand
     */
    private void exportIdentifiable( Identifiable id, Element currentNode ) {
        for ( String i : id.getIdentifiers() ) {
            if ( i != null ) {
                XMLTools.appendElement( currentNode, CommonNamespaces.CRSNS, PRE + "id", i );
            }

        }
        if ( id.getNames() != null && id.getNames().length > 0 ) {
            for ( String i : id.getNames() ) {
                if ( i != null ) {
                    XMLTools.appendElement( currentNode, CommonNamespaces.CRSNS, PRE + "name", i );
                }
            }
        }
        if ( id.getVersions() != null && id.getVersions().length > 0 ) {
            for ( String i : id.getVersions() ) {
                if ( i != null ) {
                    XMLTools.appendElement( currentNode, CommonNamespaces.CRSNS, PRE + "version", i );
                }
            }
        }
        if ( id.getDescriptions() != null && id.getDescriptions().length > 0 ) {
            for ( String i : id.getDescriptions() ) {
                if ( i != null ) {
                    XMLTools.appendElement( currentNode, CommonNamespaces.CRSNS, PRE + "description", i );
                }
            }
        }
        if ( id.getAreasOfUse() != null && id.getAreasOfUse().length > 0 ) {
            for ( String i : id.getAreasOfUse() ) {
                if ( i != null ) {
                    XMLTools.appendElement( currentNode, CommonNamespaces.CRSNS, PRE + "areaOfUse", i );
                }
            }
        }
    }

    /**
     * Export an axis to xml in the crs-definitions schema layout.
     * 
     * @param axis
     *            to be exported.
     * @param currentNode
     *            to export to.
     */
    private void export( Axis axis, Element currentNode ) {
        Document doc = currentNode.getOwnerDocument();
        Element axisElement = doc.createElementNS( CRS_URI, PRE + "Axis" );
        // The name.
        XMLTools.appendElement( axisElement, CommonNamespaces.CRSNS, PRE + "name", axis.getName() );

        // the units.
        Unit units = axis.getUnits();
        export( units, axisElement );

        XMLTools.appendElement( axisElement,
                                CommonNamespaces.CRSNS,
                                PRE + "axisOrientation",
                                axis.getOrientationAsString() );
        currentNode.appendChild( axisElement );
    }

    /**
     * Export a unit to xml in the crs-definitions schema layout. If the given units are radians, the output will be
     * transformed to degrees (because of the export-to-degree policy).
     * 
     * @param units
     *            to be exported.
     * @param currentNode
     *            to export to.
     */
    private void export( Unit units, Element currentNode ) {
        if ( units != null && currentNode != null ) {
            String tmp = units.getName();
            if ( units.equals( Unit.RADIAN ) ) {
                tmp = Unit.DEGREE.getName();
            }
            XMLTools.appendElement( currentNode, CommonNamespaces.CRSNS, PRE + "units", tmp );
        }
    }

    /**
     * @param crsElement
     *            from which the crs is to be created (using cached datums, conversioninfos and projections).
     * 
     * @return a geographic coordinatesystem based on the given xml-element.
     * @throws CRSConfigurationException
     *             if a required element could not be found, or an xmlParsingException occurred.
     */
    private CoordinateSystem parseGeographicCRS( Element crsElement )
                                                                     throws CRSConfigurationException {
        Identifiable id = parseIdentifiable( crsElement );
        Axis[] axis = parseAxisOrder( crsElement );

        // get the datum
        GeodeticDatum usedDatum = parseReferencedGeodeticDatum( crsElement, id.getIdentifier() );
        GeographicCRS result = new GeographicCRS( usedDatum, axis, id );
        for ( String s : id.getIdentifiers() ) {
            LOG.logDebug( "Adding id: " + s + "to geographic crs cache." );
            geographicCRSs.put( s, result );
        }
        if ( checkForDoubleDefinition ) {
            checkForUniqueness( cachedGeoCRSs, doubleGeos, result );
        }
        // remove the child, thus resulting in a smaller dom tree.
        rootElement.removeChild( crsElement );
        return result;
    }

    /**
     * Reads an element from the configuration with xpath *[crs:id='givenID'] and returns the found element.
     * 
     * @param id
     *            to search for
     * @return the element or <code>null</code> if no such element was found.
     */
    private Element getTopElementFromID( String id ) {
        if ( rootElement == null ) {
            LOG.logDebug( "The Root element is null, hence no crs's are available" );
            return null;
        }
        Element crsElement = null;
        // String xPath ="//*[crs:id='EPSG:31466']";
        String xPath = "*[" + PRE + "id='" + id + "']";
        try {
            crsElement = XMLTools.getElement( rootElement, xPath, nsContext );
        } catch ( XMLParsingException e ) {
            LOG.logError( Messages.getMessage( "CRS_CONFIG_NO_RESULT_FOR_ID", id, e.getMessage() ), e );
        }
        LOG.logDebug( "Trying to find elements with xpath: " + xPath
                      + ( ( crsElement == null ) ? " [failed]" : " [success]" ) );
        return crsElement;
    }

    /**
     * @param datumID
     * @return the
     * @throws CRSConfigurationException
     */
    private GeodeticDatum getGeodeticDatumFromID( String datumID )
                                                                  throws CRSConfigurationException {
        if ( datumID != null && !"".equals( datumID.trim() ) ) {
            datumID = datumID.trim();
            if ( datums.containsKey( datumID ) && datums.get( datumID ) != null ) {
                return datums.get( datumID );
            }
            Element datumElement = getTopElementFromID( datumID );
            if ( datumElement == null ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_NO_ELEMENT", "datum", datumID ) );
            }
            // get the identifiable.
            Identifiable id = parseIdentifiable( datumElement );

            // get the ellipsoid.
            Ellipsoid ellipsoid = null;
            try {
                String ellipsID = XMLTools.getRequiredNodeAsString( datumElement, PRE + "usedEllipsoid", nsContext );
                if ( ellipsID != null && !"".equals( ellipsID.trim() ) ) {
                    ellipsoid = getEllipsoidFromID( ellipsID );
                }
            } catch ( XMLParsingException e ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                          "usedEllipsoid",
                                                                          ( ( datumElement == null ) ? "null"
                                                                                                    : datumElement.getLocalName() ),
                                                                          e.getMessage() ),
                                                     e );
            }

            // get the primemeridian if any.
            PrimeMeridian pMeridian = null;
            try {
                String pMeridianID = XMLTools.getNodeAsString( datumElement, PRE + "usedPrimeMeridian", nsContext, null );
                if ( pMeridianID != null && !"".equals( pMeridianID.trim() ) ) {
                    pMeridian = getPrimeMeridianFromID( pMeridianID );
                }
                if ( pMeridian == null ) {
                    pMeridian = PrimeMeridian.GREENWICH;
                }
            } catch ( XMLParsingException e ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                          "usedPrimeMeridian",
                                                                          ( ( datumElement == null ) ? "null"
                                                                                                    : datumElement.getLocalName() ),
                                                                          e.getMessage() ),
                                                     e );
            }

            // get the WGS84 if any.
            WGS84ConversionInfo cInfo = null;
            try {
                String infoID = XMLTools.getNodeAsString( datumElement,
                                                          PRE + "usedWGS84ConversionInfo",
                                                          nsContext,
                                                          null );
                if ( infoID != null && !"".equals( infoID.trim() ) ) {
                    cInfo = getConversionInfoFromID( infoID );
                }
                if ( cInfo == null ) {
                    cInfo = new WGS84ConversionInfo( "Created by DeegreeCRSProvider" );
                }
            } catch ( XMLParsingException e ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                          "wgs84ConversionInfo",
                                                                          ( ( datumElement == null ) ? "null"
                                                                                                    : datumElement.getLocalName() ),
                                                                          e.getMessage() ),
                                                     e );
            }
            if ( ellipsoid == null ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_DATUM_HAS_NO_ELLIPSOID", datumID ) );
            }
            GeodeticDatum result = new GeodeticDatum( ellipsoid,
                                                      pMeridian,
                                                      cInfo,
                                                      id.getIdentifiers(),
                                                      id.getNames(),
                                                      id.getVersions(),
                                                      id.getDescriptions(),
                                                      id.getAreasOfUse() );
            for ( String s : id.getIdentifiers() ) {
                datums.put( s, result );
            }
            if ( checkForDoubleDefinition ) {
                checkForUniqueness( cachedDatums, doubleDatums, result );
            }

            // remove the datum from the xml-tree.
            rootElement.removeChild( datumElement );
            return result;
        }

        return null;
    }

    /**
     * @param meridianID
     *            the id to search for.
     * @return the primeMeridian with given id or <code>null</code>
     * @throws CRSConfigurationException
     *             if the longitude was not set or the units could not be parsed.
     */
    private PrimeMeridian getPrimeMeridianFromID( String meridianID )
                                                                     throws CRSConfigurationException {
        if ( meridianID != null && !"".equals( meridianID.trim() ) ) {
            if ( primeMeridians.containsKey( meridianID ) && primeMeridians.get( meridianID ) != null ) {
                return primeMeridians.get( meridianID );
            }
            Element meridianElement = getTopElementFromID( meridianID );
            if ( meridianElement == null ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_NO_ELEMENT",
                                                                          "primeMeridian",
                                                                          meridianID ) );
            }
            Identifiable id = parseIdentifiable( meridianElement );
            Unit units = parseUnit( meridianElement );
            double longitude = 0;
            try {
                longitude = XMLTools.getRequiredNodeAsDouble( meridianElement, PRE + "longitude", nsContext );
                boolean inDegrees = XMLTools.getNodeAsBoolean( meridianElement,
                                                               PRE + "longitude/@inDegrees",
                                                               nsContext,
                                                               true );
                longitude = ( longitude != 0 && inDegrees ) ? Math.toRadians( longitude ) : longitude;
            } catch ( XMLParsingException e ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                          "longitude",
                                                                          ( ( meridianElement == null ) ? "null"
                                                                                                       : meridianElement.getLocalName() ),
                                                                          e.getMessage() ),
                                                     e );
            }
            PrimeMeridian result = new PrimeMeridian( units,
                                                      longitude,
                                                      id.getIdentifiers(),
                                                      id.getNames(),
                                                      id.getVersions(),
                                                      id.getDescriptions(),
                                                      id.getAreasOfUse() );
            for ( String s : id.getIdentifiers() ) {
                primeMeridians.put( s, result );
            }
            if ( checkForDoubleDefinition ) {
                checkForUniqueness( cachedMeridans, doubleMeridians, result );
            }
            // remove the prime meridian, thus resulting in a smaller xml-tree.
            rootElement.removeChild( meridianElement );
            return result;
        }
        return null;
    }

    /**
     * Tries to find a cached ellipsoid, if not found, the config will be checked.
     * 
     * @param ellipsoidID
     * @return an ellipsoid or <code>null</code> if no ellipsoid with given id was found, or the id was
     *         <code>null</code> or empty.
     * @throws CRSConfigurationException
     *             if something went wrong.
     */
    private Ellipsoid getEllipsoidFromID( String ellipsoidID )
                                                              throws CRSConfigurationException {
        if ( ellipsoidID != null && !"".equals( ellipsoidID.trim() ) ) {
            if ( ellipsoids.containsKey( ellipsoidID ) && ellipsoids.get( ellipsoidID ) != null ) {
                return ellipsoids.get( ellipsoidID );
            }
            Element ellipsoidElement = getTopElementFromID( ellipsoidID );
            if ( ellipsoidElement == null ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_NO_ELEMENT",
                                                                          "ellipsoid",
                                                                          ellipsoidID ) );
            }
            Identifiable id = parseIdentifiable( ellipsoidElement );
            try {
                double semiMajor = XMLTools.getRequiredNodeAsDouble( ellipsoidElement, PRE + "semiMajorAxis", nsContext );

                Unit units = parseUnit( ellipsoidElement );
                double inverseFlattening = XMLTools.getNodeAsDouble( ellipsoidElement,
                                                                     PRE + "inverseFlatting",
                                                                     nsContext,
                                                                     Double.NaN );
                double eccentricity = XMLTools.getNodeAsDouble( ellipsoidElement,
                                                                PRE + "eccentricity",
                                                                nsContext,
                                                                Double.NaN );
                double semiMinorAxis = XMLTools.getNodeAsDouble( ellipsoidElement,
                                                                 PRE + "semiMinorAxis",
                                                                 nsContext,
                                                                 Double.NaN );
                if ( Double.isNaN( inverseFlattening ) && Double.isNaN( eccentricity ) && Double.isNaN( semiMinorAxis ) ) {
                    throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_ELLIPSOID_MISSES_PARAM",
                                                                              ellipsoidID ) );
                }

                Ellipsoid result = null;
                if ( !Double.isNaN( inverseFlattening ) ) {
                    result = new Ellipsoid( semiMajor,
                                            units,
                                            inverseFlattening,
                                            id.getIdentifiers(),
                                            id.getNames(),
                                            id.getVersions(),
                                            id.getDescriptions(),
                                            id.getAreasOfUse() );
                } else if ( !Double.isNaN( eccentricity ) ) {
                    result = new Ellipsoid( semiMajor,
                                            eccentricity,
                                            units,
                                            id.getIdentifiers(),
                                            id.getNames(),
                                            id.getVersions(),
                                            id.getDescriptions(),
                                            id.getAreasOfUse() );
                } else {
                    result = new Ellipsoid( units,
                                            semiMajor,
                                            semiMinorAxis,
                                            id.getIdentifiers(),
                                            id.getNames(),
                                            id.getVersions(),
                                            id.getDescriptions(),
                                            id.getAreasOfUse() );
                }
                for ( String s : id.getIdentifiers() ) {
                    ellipsoids.put( s, result );
                }
                if ( checkForDoubleDefinition ) {
                    checkForUniqueness( cachedEllipsoids, doubleEllipsoids, result );
                }
                // remove the ellipsoid from the xml-tree.
                rootElement.removeChild( ellipsoidElement );
                return result;
            } catch ( XMLParsingException e ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                          "ellipsoid",
                                                                          ( ( ellipsoidElement == null ) ? "null"
                                                                                                        : ellipsoidElement.getLocalName() ),
                                                                          e.getMessage() ),
                                                     e );
            }
        }

        return null;
    }

    /**
     * @param info
     * @return the configured wgs84 conversion info parameters.
     * @throws CRSConfigurationException
     */
    private WGS84ConversionInfo getConversionInfoFromID( String infoID )
                                                                        throws CRSConfigurationException {
        if ( infoID != null && !"".equals( infoID.trim() ) ) {
            if ( conversionInfos.containsKey( infoID ) && conversionInfos.get( infoID ) != null ) {
                return conversionInfos.get( infoID );
            }
            Element cInfoElement = getTopElementFromID( infoID );
            if ( cInfoElement == null ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_NO_ELEMENT",
                                                                          "wgs84ConversionInfo",
                                                                          infoID ) );
            }
            Identifiable identifiable = parseIdentifiable( cInfoElement );
            double xT = 0, yT = 0, zT = 0, xR = 0, yR = 0, zR = 0, scale = 0;
            try {
                xT = XMLTools.getNodeAsDouble( cInfoElement, PRE + "xAxisTranslation", nsContext, 0 );
                yT = XMLTools.getNodeAsDouble( cInfoElement, PRE + "yAxisTranslation", nsContext, 0 );
                zT = XMLTools.getNodeAsDouble( cInfoElement, PRE + "zAxisTranslation", nsContext, 0 );
                xR = XMLTools.getNodeAsDouble( cInfoElement, PRE + "xAxisRotation", nsContext, 0 );
                yR = XMLTools.getNodeAsDouble( cInfoElement, PRE + "yAxisRotation", nsContext, 0 );
                zR = XMLTools.getNodeAsDouble( cInfoElement, PRE + "zAxisRotation", nsContext, 0 );
                scale = XMLTools.getNodeAsDouble( cInfoElement, PRE + "scaleDifference", nsContext, 0 );
            } catch ( XMLParsingException e ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                          "conversionInfo",
                                                                          "definitions",
                                                                          e.getMessage() ), e );
            }
            WGS84ConversionInfo result = new WGS84ConversionInfo( xT, yT, zT, xR, yR, zR, scale, identifiable );
            for ( String id : identifiable.getIdentifiers() ) {
                conversionInfos.put( id, result );
            }
            if ( checkForDoubleDefinition ) {
                checkForUniqueness( cachedToWGS, doubleToWGS, result );
            }
            // remove the child, thus resulting in a smaller xml-tree.
            rootElement.removeChild( cInfoElement );
            return result;

        }
        return null;
    }

    /**
     * @param crsElement
     *            from which the crs is to be created (using chached datums, conversioninfos and projections).
     * @return a projected coordinatesystem based on the given xml-element.
     * @throws CRSConfigurationException
     *             if a required element could not be found, or an xmlParsingException occurred.
     */
    private CoordinateSystem parseProjectedCRS( Element crsElement )
                                                                    throws CRSConfigurationException {
        Identifiable id = parseIdentifiable( crsElement );
        Axis[] axis = parseAxisOrder( crsElement );
        Unit units = parseUnit( crsElement );

        String usedProjection = null;
        String usedGeographicCRS = null;
        try {
            usedProjection = XMLTools.getRequiredNodeAsString( crsElement, PRE + "usedProjection", nsContext );
            usedGeographicCRS = XMLTools.getRequiredNodeAsString( crsElement, PRE + "usedGeographicCRS", nsContext );
        } catch ( XMLParsingException e ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                      "projectiontType or usedGeographicCRS",
                                                                      ( ( crsElement == null ) ? "null"
                                                                                              : crsElement.getLocalName() ),
                                                                      e.getMessage() ),
                                                 e );

        }
        // first create the datum.
        if ( usedGeographicCRS == null || "".equals( usedGeographicCRS.trim() ) ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_REFERENCE_ID_IS_EMPTY",
                                                                      "usedGeographicCRS",
                                                                      id.getIdentifier() ) );
        }
        CoordinateSystem geoCRS = getCRSByID( usedGeographicCRS );
        if ( geoCRS == null || geoCRS.getType() != CoordinateSystem.GEOGRAPHIC_CRS ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PROJECTEDCRS_FALSE_CRSREF",
                                                                      id.getIdentifier(),
                                                                      usedGeographicCRS ) );
        }

        // then the projection.
        if ( usedProjection == null || "".equals( usedProjection.trim() ) ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_REFERENCE_ID_IS_EMPTY",
                                                                      "projectionType",
                                                                      id.getIdentifier() ) );
        }
        Projection projection = getProjectionByID( usedProjection, (GeographicCRS) geoCRS, units );
        if ( projection == null ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PROJECTEDCRS_FALSE_PROJREF",
                                                                      id.getIdentifier(),
                                                                      usedProjection ) );
        }
        ProjectedCRS result = new ProjectedCRS( projection, axis, id );
        for ( String s : id.getIdentifiers() ) {
            LOG.logDebug( "Adding id: " + s + "to projected crs cache." );
            projectedCRSs.put( s, result );
        }
        // remove the child, thus resulting in a smaller xml-tree.
        rootElement.removeChild( crsElement );
        return result;
    }

    /**
     * Find or parses the projection with given id.
     * 
     * @param usedProjection
     * @return the configured projection or <code>null</code> if not defined or found.
     * @throws CRSConfigurationException
     */
    private Projection getProjectionByID( String usedProjection, GeographicCRS underlyingCRS, Unit units )
                                                                                                          throws CRSConfigurationException {
        if ( usedProjection != null && !"".equals( usedProjection.trim() ) ) {
            usedProjection = usedProjection.trim();
            if ( projections.containsKey( usedProjection ) && projections.get( usedProjection ) != null ) {
                return projections.get( usedProjection );
            }
            Element projectionElement = getTopElementFromID( usedProjection );
            if ( projectionElement == null ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_NO_ELEMENT",
                                                                          "projection",
                                                                          usedProjection ) );
            }
            // get the identifiable.
            Identifiable id = parseIdentifiable( projectionElement );
            Projection result = null;

            try {
                double latitudeOfNaturalOrigin = XMLTools.getNodeAsDouble( projectionElement,
                                                                           PRE + "latitudeOfNaturalOrigin",
                                                                           nsContext,
                                                                           0 );
                boolean inDegrees = XMLTools.getNodeAsBoolean( projectionElement,
                                                               PRE + "latitudeOfNaturalOrigin/@inDegrees",
                                                               nsContext,
                                                               true );
                latitudeOfNaturalOrigin = ( latitudeOfNaturalOrigin != 0 && inDegrees ) ? Math.toRadians( latitudeOfNaturalOrigin )
                                                                                       : latitudeOfNaturalOrigin;

                double longitudeOfNaturalOrigin = XMLTools.getNodeAsDouble( projectionElement,
                                                                            PRE + "longitudeOfNaturalOrigin",
                                                                            nsContext,
                                                                            0 );
                inDegrees = XMLTools.getNodeAsBoolean( projectionElement,
                                                       PRE + "longitudeOfNaturalOrigin/@inDegrees",
                                                       nsContext,
                                                       true );
                longitudeOfNaturalOrigin = ( longitudeOfNaturalOrigin != 0 && inDegrees ) ? Math.toRadians( longitudeOfNaturalOrigin )
                                                                                         : longitudeOfNaturalOrigin;

                double scaleFactor = XMLTools.getNodeAsDouble( projectionElement, PRE + "scaleFactor", nsContext, 0 );
                double falseEasting = XMLTools.getNodeAsDouble( projectionElement, PRE + "falseEasting", nsContext, 0 );
                double falseNorthing = XMLTools.getNodeAsDouble( projectionElement, PRE + "falseNorthing", nsContext, 0 );

                String projectionName = projectionElement.getLocalName().trim();
                Point2d naturalOrigin = new Point2d( longitudeOfNaturalOrigin, latitudeOfNaturalOrigin );

                if ( "transverseMercator".equalsIgnoreCase( projectionName ) ) {
                    // change schema to let projection be identifiable. fix method geodetic
                    boolean northernHemi = XMLTools.getNodeAsBoolean( projectionElement,
                                                                      PRE + "northernHemisphere",
                                                                      nsContext,
                                                                      true );
                    result = new TransverseMercator( northernHemi,
                                                     underlyingCRS,
                                                     falseNorthing,
                                                     falseEasting,
                                                     naturalOrigin,
                                                     units,
                                                     scaleFactor,
                                                     id.getIdentifiers(),
                                                     id.getNames(),
                                                     id.getVersions(),
                                                     id.getDescriptions(),
                                                     id.getAreasOfUse() );
                } else if ( "lambertAzimuthalEqualArea".equalsIgnoreCase( projectionName ) ) {
                    result = new LambertAzimuthalEqualArea( underlyingCRS,
                                                            falseNorthing,
                                                            falseEasting,
                                                            naturalOrigin,
                                                            units,
                                                            scaleFactor,
                                                            id.getIdentifiers(),
                                                            id.getNames(),
                                                            id.getVersions(),
                                                            id.getDescriptions(),
                                                            id.getAreasOfUse() );
                } else if ( "lambertConformalConic".equalsIgnoreCase( projectionName ) ) {
                    double firstP = XMLTools.getNodeAsDouble( projectionElement,
                                                              PRE + "firstParallelLatitude",
                                                              nsContext,
                                                              Double.NaN );
                    inDegrees = XMLTools.getNodeAsBoolean( projectionElement,
                                                           PRE + "firstParallelLatitude/@inDegrees",
                                                           nsContext,
                                                           true );
                    firstP = ( !Double.isNaN( firstP ) && inDegrees ) ? Math.toRadians( firstP ) : firstP;

                    double secondP = XMLTools.getNodeAsDouble( projectionElement,
                                                               PRE + "secondParallelLatitude",
                                                               nsContext,
                                                               Double.NaN );
                    inDegrees = XMLTools.getNodeAsBoolean( projectionElement,
                                                           PRE + "secondParallelLatitude/@inDegrees",
                                                           nsContext,
                                                           true );
                    secondP = ( !Double.isNaN( secondP ) && inDegrees ) ? Math.toRadians( secondP ) : secondP;
                    result = new LambertConformalConic( firstP,
                                                        secondP,
                                                        underlyingCRS,
                                                        falseNorthing,
                                                        falseEasting,
                                                        naturalOrigin,
                                                        units,
                                                        scaleFactor,
                                                        id.getIdentifiers(),
                                                        id.getNames(),
                                                        id.getVersions(),
                                                        id.getDescriptions(),
                                                        id.getAreasOfUse() );
                } else if ( "stereographicAzimuthal".equalsIgnoreCase( projectionName ) ) {
                    double trueScaleL = XMLTools.getNodeAsDouble( projectionElement,
                                                                  PRE + "trueScaleLatitude",
                                                                  nsContext,
                                                                  Double.NaN );
                    inDegrees = XMLTools.getNodeAsBoolean( projectionElement,
                                                           PRE + "trueScaleLatitude/@inDegrees",
                                                           nsContext,
                                                           true );
                    trueScaleL = ( !Double.isNaN( trueScaleL ) && inDegrees ) ? Math.toRadians( trueScaleL )
                                                                             : trueScaleL;

                    result = new StereographicAzimuthal( trueScaleL,
                                                         underlyingCRS,
                                                         falseNorthing,
                                                         falseEasting,
                                                         naturalOrigin,
                                                         units,
                                                         scaleFactor,
                                                         id.getIdentifiers(),
                                                         id.getNames(),
                                                         id.getVersions(),
                                                         id.getDescriptions(),
                                                         id.getAreasOfUse() );
                } else {
                    throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PROJECTEDCRS_INVALID_PROJECTION",
                                                                              id.getIdentifier(),
                                                                              usedProjection ) );

                }
                for ( String identifier : id.getIdentifiers() ) {
                    projections.put( identifier, result );
                }
                if ( checkForDoubleDefinition ) {
                    checkForUniqueness(  cachedProjections, doubleProjections, result );
                }
                // remove the child, thus resulting in a smaller xml-tree.
                rootElement.removeChild( projectionElement );
                return result;
            } catch ( XMLParsingException e ) {
                throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                          "projection parameters",
                                                                          ( ( projectionElement == null ) ? "null"
                                                                                                         : projectionElement.getLocalName() ),
                                                                          e.getMessage() ),
                                                     e );

            }
        }

        return null;
    }
    
    /**
     * @param crsElement
     *            from which the crs is to be created (using cached datums, conversioninfos and projections).
     * @return a geocentric coordinatesystem based on the given xml-element.
     * @throws CRSConfigurationException
     *             if a required element could not be found, or an xmlParsingException occurred.
     */
    private CoordinateSystem parseGeocentricCRS( Element crsElement )
                                                                     throws CRSConfigurationException {
        Identifiable id = parseIdentifiable( crsElement );
        Axis[] axis = parseAxisOrder( crsElement );
        GeodeticDatum usedDatum = parseReferencedGeodeticDatum( crsElement, id.getIdentifier() );
        GeocentricCRS result = new GeocentricCRS( usedDatum,
                                                  axis,
                                                  id.getIdentifiers(),
                                                  id.getNames(),
                                                  id.getVersions(),
                                                  id.getDescriptions(),
                                                  id.getAreasOfUse() );
        for ( String identifier : id.getIdentifiers() ) {
            geocentricCRSs.put( identifier, result );
        }
        rootElement.removeChild( crsElement );
        return result;
    }

    /**
     * Parses the required usedDatum element from the given parentElement (probably a crs element).
     * 
     * @param parentElement
     *            to parse the required usedDatum element from.
     * @param parentID
     *            optional for an appropriate error message.
     * @return the Datum.
     * @throws CRSConfigurationException
     *             if a parsing error occurred, the node was not defined or an illegal id reference (not found) was
     *             given.
     */
    private GeodeticDatum parseReferencedGeodeticDatum( Element parentElement, String parentID )
                                                                                                throws CRSConfigurationException {
        String datumID = null;
        try {
            datumID = XMLTools.getRequiredNodeAsString( parentElement, PRE + "usedDatum", nsContext );
        } catch ( XMLParsingException e ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                      "datumID",
                                                                      ( ( parentElement == null ) ? "null"
                                                                                                 : parentElement.getLocalName() ),
                                                                      e.getMessage() ),
                                                 e );
        }
        if ( datumID == null || "".equals( datumID.trim() ) ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_REFERENCE_ID_IS_EMPTY",
                                                                      "usedDatum",
                                                                      parentID ) );
        }
        GeodeticDatum usedDatum = getGeodeticDatumFromID( datumID );
        if ( usedDatum == null ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_USEDDATUM_IS_NULL", datumID, parentID ) );
        }
        return usedDatum;
    }

    /**
     * Parses all elements of the identifiable object.
     * 
     * @param element
     *            the xml-representation of the id-object
     * @return the identifiable object or <code>null</code> if no id was given.
     * @throws CRSConfigurationException
     */
    private Identifiable parseIdentifiable( Element element )
                                                             throws CRSConfigurationException {
        try {
            String[] identifiers = XMLTools.getNodesAsStrings( element, PRE + "id", nsContext );
            if ( identifiers == null || identifiers.length == 0 ) {
                String msg = Messages.getMessage( "CRS_CONFIG_NO_ID", ( ( element == null ) ? "null"
                                                                                           : element.getLocalName() ) );
                throw new CRSConfigurationException( msg );
            }
            for ( int i = 0; i < identifiers.length; ++i ) {
                if ( identifiers[i] != null ) {
                    identifiers[i] = identifiers[i].toUpperCase().trim();
                }
            }
            String[] names = XMLTools.getNodesAsStrings( element, PRE + "name", nsContext );
            String[] versions = XMLTools.getNodesAsStrings( element, PRE + "version", nsContext );
            String[] descriptions = XMLTools.getNodesAsStrings( element, PRE + "description", nsContext );
            String[] areasOfUse = XMLTools.getNodesAsStrings( element, PRE + "areaOfuse", nsContext );
            return new Identifiable( identifiers, names, versions, descriptions, areasOfUse );
        } catch ( XMLParsingException e ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                      "Identifiable",
                                                                      ( ( element == null ) ? "null"
                                                                                           : element.getLocalName() ),
                                                                      e.getMessage() ), e );
        }
    }

    /**
     * Creates an axis array for the given crs element.
     * 
     * @param crsElement
     *            to be parsed
     * @return an Array of axis defining their order.
     * @throws CRSConfigurationException
     *             if a required element could not be found, or an xmlParsingException occurred, or the axisorder uses
     *             names which were not defined in the axis elements.
     */
    private Axis[] parseAxisOrder( Element crsElement )
                                                       throws CRSConfigurationException {
        String axisOrder = null;
        try {
            axisOrder = XMLTools.getRequiredNodeAsString( crsElement, PRE + "axisOrder", nsContext );
        } catch ( XMLParsingException e ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                      "AxisOrder",
                                                                      ( ( crsElement == null ) ? "null"
                                                                                              : crsElement.getLocalName() ),
                                                                      e.getMessage() ),
                                                 e );
        }
        if ( axisOrder == null || "".equals( axisOrder.trim() ) ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                      "AxisOrder",
                                                                      ( ( crsElement == null ) ? "null"
                                                                                              : crsElement.getLocalName() ),
                                                                      " axisOrder element may not be empty" ) );
        }
        axisOrder = axisOrder.trim();
        String[] order = axisOrder.trim().split( "," );
        Axis[] axis = new Axis[order.length];
        String XPATH = PRE + "Axis[" + PRE + "name = '";
        for ( int i = 0; i < order.length; ++i ) {
            String t = order[i];
            if ( t != null && !"".equals( t.trim() ) ) {
                t = t.trim();
                try {
                    Element axisElement = XMLTools.getRequiredElement( crsElement, XPATH + t + "']", nsContext );
                    String axisOrientation = XMLTools.getRequiredNodeAsString( axisElement,
                                                                               PRE + "axisOrientation",
                                                                               nsContext );
                    Unit unit = parseUnit( axisElement );
                    axis[i] = new Axis( unit, t, axisOrientation );
                } catch ( XMLParsingException e ) {
                    throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                              "Axis",
                                                                              ( ( crsElement == null ) ? "null"
                                                                                                      : crsElement.getLocalName() ),
                                                                              e.getMessage() ),
                                                         e );
                }
            }
        }
        return axis;
    }

    /**
     * Parses a unit from the given xml-parent, if the unit is degree, it will be mapped to radians.
     * 
     * @param parent
     *            xml-node to parse the unit from.
     * @return the unit object.
     * @throws CRSConfigurationException
     *             if the unit object could not be created.
     */
    private Unit parseUnit( Element parent )
                                            throws CRSConfigurationException {
        String units = null;
        try {
            units = XMLTools.getNodeAsString( parent, PRE + "units", nsContext, null );
        } catch ( XMLParsingException e ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                      "units",
                                                                      ( ( parent == null ) ? "null"
                                                                                          : parent.getLocalName() ),
                                                                      e.getMessage() ), e );
        }
        if ( Unit.DEGREE.getName().equals( units ) ) {
            units = Unit.RADIAN.getName();
        }
        Unit unit = Unit.createUnitFromString( units );
        if ( unit == null ) {
            throw new CRSConfigurationException( Messages.getMessage( "CRS_CONFIG_PARSE_ERROR",
                                                                      "units",
                                                                      ( ( parent == null ) ? "null"
                                                                                          : parent.getLocalName() ),
                                                                      "unknown unit: " + units ) );
        }
        return unit;
    }
    
    /**
     * @param <T> should be at least of Type Identifiable.
     * @param uniqueList to check against
     * @param mapping to added the id of T to if it is found duplicate.
     * @param toBeChecked to check.
     */
    private <T extends Identifiable> void checkForUniqueness( List<T> uniqueList, Map<String, String> mapping, T toBeChecked){
        if ( uniqueList.contains( toBeChecked ) ) {
            int index = uniqueList.indexOf( toBeChecked );
            LOG.logInfo( "The Identifiable with id: " + toBeChecked.getIdentifier()
                         + " was found to be equal with: "
                         + uniqueList.get( index ).getIdentifier() );
            String key = uniqueList.get( index ).getIdentifier();
            if ( key != null && !"".equals( key.trim() ) ) {
                String value = mapping.get( key );
                //it would be nicest to get the epsg code if any.
                if ( !key.startsWith( "EPSG:" ) && toBeChecked.getIdentifier().startsWith( "EPSG:" ) ) {
                    if ( value == null || "".equals( value ) ) {
                        value = key;
                    } else {
                        value += ", " + key;
                    }
                    mapping.remove( key );
                    key = toBeChecked.getIdentifier();
                } else {
                    if ( value == null || "".equals( value ) ) {
                        value = toBeChecked.getIdentifier();
                    } else {
                        value += ", " + toBeChecked.getIdentifier();
                    }
                }
                mapping.put( key, value );
            }
        } else {
            uniqueList.add( toBeChecked );
        }
    }
}
