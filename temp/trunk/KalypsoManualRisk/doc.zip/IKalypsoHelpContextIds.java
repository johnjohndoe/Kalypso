<?xml version="1.0" encoding="ISO-8859-1"?>


				
				
/**
 * @see KalypsoManual common-eclipse.xsl and KalypsoBuild/publishing/docbook-xsl-1.69.1/eclipse/eclipse-ex.xsl
 *
 */				
public interface IKalypsoHelpContextIds
{
  public static final String PREFIX = "org.kalypso.manual.";
					
				
			
  public static final String KalypsoRiskPreprocessing =PREFIX + "KalypsoRiskPreprocessing";
		
}
				
			