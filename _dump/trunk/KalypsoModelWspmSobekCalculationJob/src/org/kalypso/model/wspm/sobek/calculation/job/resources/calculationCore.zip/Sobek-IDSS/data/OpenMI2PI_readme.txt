Publishes all input exchange items listed in the configuration file as input exchange items
so that output from any OpenMI component can be connected to them in order to export data into PI