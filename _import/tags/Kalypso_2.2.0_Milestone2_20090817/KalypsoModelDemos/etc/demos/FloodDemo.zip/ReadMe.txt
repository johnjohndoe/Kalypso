Dies ist ein einfaches KalypsoFLOOD Beispielprojekt.

Eingangdaten  sind:
- 2 Wasserspiegel korrepsondierend zu den beiden Abflussereignissen des WSPMDemo Beispielprojekts
- H�henmodel f�r den Untersuchungsraum

Die Ergebnisdaten liegen bereits vor.


Testing:
Referenzergebnisse liegen f�r Ereignis 2 vor unter /FloodDemo/Basis/events/Ereignis 2/ReferenzErgebnisse

Nach Berechnung k�nnen diese mit /FloodDemo/Basis/events/Ereignis 2/results ('Compare With-Each Other')