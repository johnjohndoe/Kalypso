/*
 * (c) Copyright 2002 Object Factory Inc.
 * All Rights Reserved.
 */
package org.eclipse.ui.examples.javaeditor.java;

import com.objfac.util.Local;

/**
 * Suppress nattering to console by example code.
 * @author Bob Foster
 */
public class JavaEditorMessages {

	public static String getString(String arg) {
		throw new IllegalStateException(Local.getString(arg));
	}
}
