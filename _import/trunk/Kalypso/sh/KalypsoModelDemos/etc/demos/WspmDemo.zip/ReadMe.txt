Dies ist ein einfaches WSPM Beispielprojekt.

Inhalt:
- ein Strang
- 2 Berechnungsereignisse basierend auf 2 unterschiedlichen Abflusswerten



Testing:
Referenzergebnisse liegen jeweils unter Ergebnisse\Rechnung X\ReferenzErgebnisse

Nach Berechnung können diese mit Ergebnisse\Rechnung X\_aktuell verglichen werden ('Compare With-Each Other')